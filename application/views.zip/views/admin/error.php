	<div id="content" class="col-lg-10 col-sm-10">
		<p style="color:red;font-size:20px;text-align:center;">Setup Already Complete</p>

	</div><!--/#content.col-md-10-->
</div><!--/fluid-row-->
