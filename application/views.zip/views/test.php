

<div id="content" class="col-lg-10 col-sm-10">
	<div class="panel-group">
		<div class="panel panel-default">
			<div class="panel-heading">Information</div>
			<div class="panel-body">
				<div class="form-group">
					<label class="control-label col-sm-2 col-xs-4 custom-label-text">নাম</label>
					<div class="col-sm-4 col-xs-8 custom-info-text"> : আবু বকর ছিদ্দিক রানা  </div>
					<div class="visible-xs clearfix"></div>
					<label class="control-label col-sm-2 col-xs-4 custom-label-text">পিতার নাম</label>
					<div class="col-sm-4 col-xs-8 custom-info-text">:  আবদুল মমিন </div>
				</div>
				<div class="clearfix"></div>
				<div class="form-group">
					<label class="control-label col-sm-2 col-xs-4 custom-label-text">জন্ম নিবন্ধন নং</label>
					<div class="col-sm-4 col-xs-8 custom-info-text">:  আবু বকর ছিদ্দিক রানা  </div>
					<div class="visible-xs clearfix"></div>
					<label class="control-label col-sm-2 col-xs-4 custom-label-text">জাতীয় পরিচয় পত্র</label>
					<div class="col-sm-4 col-xs-8 custom-info-text"> : আবদুল মমিন </div>
				</div>
				<div class="clearfix"></div>
				<div class="form-group">
					<label class="control-label col-sm-2 col-xs-4 custom-label-text">গ্রাম </label>
					<div class="col-sm-4 col-xs-8 custom-info-text">:  আবু বকর ছিদ্দিক রানা  </div>
					<div class="visible-xs clearfix"></div>
					<label class="control-label col-sm-2 col-xs-4 custom-label-text">ওয়ার্ড নং</label>
					<div class="col-sm-4 col-xs-8 custom-info-text">:  আবদুল মমিন </div>
				</div>
				<div class="clearfix"></div><div class="form-group">
					<label class="control-label col-sm-2 col-xs-4 custom-label-text">হোল্ডিং নং</label>
					<div class="col-sm-4 col-xs-8 custom-info-text">:  আবু বকর ছিদ্দিক রানা  </div>
					<div class="visible-xs clearfix"></div>
					<label class="control-label col-sm-2 col-xs-4 custom-label-text">দাগ নং</label>
					<div class="col-sm-4 col-xs-8 custom-info-text">:  আবদুল মমিন </div>
				</div>
				<div class="clearfix"></div>
				<div class="form-group">
					<label class="control-label col-sm-2 col-xs-4 custom-label-text">বসতভিটার ধরন</label>
					<div class="col-sm-4 col-xs-8 custom-info-text"> : আবু বকর ছিদ্দিক রানা  </div>
					<div class="visible-xs clearfix"></div>
					<label class="control-label col-sm-2 col-xs-4 custom-label-text">মোবাইল নং</label>
					<div class="col-sm-4 col-xs-8 custom-info-text">:  আবদুল মমিন </div>
				</div>
			</div>
		</div>
	</div>
</div>