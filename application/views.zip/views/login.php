<?php
echo $content;
?>