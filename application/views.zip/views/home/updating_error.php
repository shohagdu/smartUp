<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<style type="text/css"> 
		h3, h4{
			text-align:center;
			color: red;
		}
	</style>
</head>
<body>
	<h2 style="text-align: center; color: green;">New Version Release!!! Smart UP <sub>3.1</sub></h2>
	<h3>দু:খিত !!!!!  software টি Update করা হচ্ছে  । দয়া করে ১ ঘন্টা অপেক্ষা করুন।</h3>
	<h4>সাময়িক অসুবিধার জন্য আমরা আন্তরিকভাবে দু:খিত। </h4>
</body>
</html>