<?php 
	extract($_GET);
	//print_r($_GET); exit;
	$id=$tid;
	if(trim($id)==""){echo '<p style="color:red;text-align:center;fontsize:15px;">আপনার নাগরিক আবেদনের ট্র্যাকিং নম্বরটি প্রবেশ করুন</p>';exit;}
	$query=$this->db->select('*')->from('personalinfo')->where('trackid',$id)->limit('1')->get();
	$row=$query->row();
	if($this->db->affected_rows()>0){
?>
	<style>
		b{padding-left:8px;font-family:solaimanLipi;}
	</style>

	<span>
		 <?php
			$url=base_url()."home/showNagorickInformation?scode=$tid";
		 //echo file_get_contents($url);
		function curl_get($url, array $get = NULL, array $options = array()) 
			{    
				$defaults = array( 
					CURLOPT_URL => $url. (strpos($url, '?') === FALSE ? '?' : ''). http_build_query($get), 
					CURLOPT_HEADER => 0, 
					CURLOPT_RETURNTRANSFER => TRUE, 
					CURLOPT_TIMEOUT => 10 
				); 
				
				$ch = curl_init(); 
				curl_setopt_array($ch, ($options + $defaults)); 
				if( ! $result = curl_exec($ch)) 
				{ trigger_error(curl_error($ch)); } 
				curl_close($ch); 
				return $result; 
			}
		echo $html =curl_get($url); ?>
	</span>
 <?php } else {?>
	<p style="color:red;font-size:15px;text-align:center; ">আপনার  নাগরিক আবেদনের  নাম্বারটি সঠিক না  <br/>আপনি ইউনিয়ন পরিষদে যোগাযোগ করুন অথবা  <br/>নাগরিকের  জন্য আবেদন করুন। </p>
 <?php } ?>