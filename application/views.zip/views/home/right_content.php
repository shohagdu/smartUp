<!-- all query are here end -->
	<style type="text/css">
		#attend{
			list-style: none !important;
			margin-left: 10%;margin-top: 0px !important;margin-bottom: 0px !important;
		}
		.right-menu span{
			font-size:15px;
			display:block;
			margin-bottom:8px;
		}
		.custom-heading{
			font-size:17px;
		}
	</style>
			<!---This is right content strat-->
			<div class="col-md-3 right_con"><!-- Right Content Start--> 
				<div class="panel panel-primary"><!-- IMPORTANT Link Start-->
					<div class="panel-heading custom-heading" style="background-color:#004884;font-size: 13px;"><i class="fa fa-anchor"></i>&nbsp; ই-সেবা কেন্দ্র, <?php echo $all_data->full_name;?></div>
					<div class="panel-body right-menu">
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="home/nagorikapplication">নাগরিকত্ব সনদের আবেদন ফরম</a>
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="home/tradelicenseapplication">ট্রেড লাইসেন্স সনদের আবেদন ফরম</a>            
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="home/renewapplication">ট্রেড লাইসেন্স নবায়ন ফরম</a>            
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="home/oarishapplication">ওয়ারিশ সনদের আবেদন ফরম</a>
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="home/otherService">অন্যান্য সনদের আবেদন ফরম </a>
						</span>
					</div>
				</div><!-- IMPORTANT Link End-->
				
				<div class="panel panel-primary"><!-- IMPORTANT Link Start-->
					<div class="panel-heading custom-heading" style="background-color:#004884;font-size:16px;"><i class="fa fa-anchor"></i>&nbsp;আবেদন পত্রের অবস্থান যাচাই করুন </div>
					<div class="panel-body right-menu">
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="home/filternagorikapplication">নাগরিকত্ব সনদের আবেদন যাচাই </a>
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="home/filtertradeapplication">ট্রেড লাইসেন্স সনদের আবেদন যাচাই </a>            
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="home/filteroarishapplication">ওয়ারিশ সনদের আবেদন যাচাই </a>
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="home/filterOtherServiceApplication">অন্যান্য সেবাসমূহর আবেদন  যাচাই</a>
						</span>
					</div>
				</div><!-- IMPORTANT Link End-->
				
				<div class="panel panel-primary"><!-- IMPORTANT Link Start-->
					<div class="panel-heading custom-heading" style="background-color:#004884;"><i class="fa fa-anchor"></i>&nbsp;  সনদপত্র যাচাই করুন </div>
					<div class="panel-body right-menu">
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="home/filternagorikcertificate">নাগরিক  সনদপত্র  যাচাই </a>
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="home/filtertradecertificate">ট্রেড লাইসেন্স সনদপত্র  যাচাই </a>            
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="home/filteroarishcertificate">ওয়ারিশ সনদপত্র যাচাই </a>
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="home/filterOtherServiceCertificate">অন্যান্য সেবাসমূহর সনদপত্র যাচাই </a>
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="home/jacaiMamlaNotice">মামলার নোটিশ যাচাই</a>
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="home/verify_holding_tax">হোল্ডিং ট্যাক্স যাচাই</a>
						</span>
					</div>
				</div><!-- IMPORTANT Link start-->
				<div class="panel panel-primary">
					<div class="panel-heading custom-heading" style="background-color:#004884;"><i class="fa fa-anchor"></i>&nbsp;  গুরুত্বপূর্ণ লিঙ্ক সমূহ </div>
					<div class="panel-body right-menu">
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="http://bris.lgd.gov.bd/pub" target="_blank">জন্ম/মৃত্যু নিবন্ধন আবেদন</a>
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="http://180.211.213.82/login" target="_blank">জন্ম নিবন্ধন লগইন</a>
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="http://uiscbd.ning.com" target="_blank">ডিজিটাল সেন্টার ব্লগ </a>
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="http://www.passport.gov.bd/" target="_blank">পাসপোর্টের আবেদন ফরম </a>
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="http://dpe.portal.gov.bd/site/page/256bd7b9-cfa4-4f71-afa6-3b8262f4021f" target="_blank">সমাপনী পরীক্ষার ফলাফল</a>            
						</span>
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="http://dcms.e-service.gov.bd" target="_blank">ম্যানেজমেন্ট সিস্টেম</a>            
						</span>
						
						<span>
							<i class="fa fa-hand-o-right"></i> &nbsp;
							<a href="http://www.educationboardresults.gov.bd/regular/index.php" target="_blank">Ministry of Education</a>
						</span>
					</div>
				</div>
				
				<!-- IMPORTANT Link End-->
				
				<div class="panel panel-primary"><!-- IMPORTANT Link Start-->
					<div class="panel-heading custom-heading" style="background-color:#004884;"><i class="fa fa-archive"></i> &nbsp;  অভিযোগ</div>
					<div class="panel-body right-menu">
						
					</div>
				</div><!-- IMPORTANT Link End-->
			</div><!-- Right Content End--> 
		</div><!--- row end---->
	</div><!-- main Content End-->
