#
# TABLE STRUCTURE FOR: accountlogs
#

DROP TABLE IF EXISTS `accountlogs`;

CREATE TABLE `accountlogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acno` varchar(40) NOT NULL,
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: acinfo
#

DROP TABLE IF EXISTS `acinfo`;

CREATE TABLE `acinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acname` varchar(255) NOT NULL,
  `acno` varchar(40) NOT NULL,
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `acinfo` (`id`, `acname`, `acno`, `balance`, `last_update`) VALUES ('1', 'CASH ACCOUNT', '0000-0000-0000-0000', '19793.20', '2017-12-10 23:57:00');
INSERT INTO `acinfo` (`id`, `acname`, `acno`, `balance`, `last_update`) VALUES ('2', 'চেয়ারম্যান ইউনিয়ন পরিষদ', '2216/0', '8150.00', '2017-05-06 17:44:01');
INSERT INTO `acinfo` (`id`, `acname`, `acno`, `balance`, `last_update`) VALUES ('3', 'জন্ম নিবন্ধন', '2191/1', '0.00', '2016-09-22 14:07:31');
INSERT INTO `acinfo` (`id`, `acname`, `acno`, `balance`, `last_update`) VALUES ('4', 'এলজিএসপি', '1603033008083', '0.00', '2016-09-22 14:07:31');
INSERT INTO `acinfo` (`id`, `acname`, `acno`, `balance`, `last_update`) VALUES ('5', 'ভূমি হস্তান্তর কর ১%', '22751', '0.00', '2016-09-22 14:07:31');
INSERT INTO `acinfo` (`id`, `acname`, `acno`, `balance`, `last_update`) VALUES ('6', 'নিজস্ব তহবিলঃ ক্যাশ', '0001-0001-0001-0001', '0.00', '2016-09-22 14:07:31');
INSERT INTO `acinfo` (`id`, `acname`, `acno`, `balance`, `last_update`) VALUES ('7', 'নিজস্ব তহবিলঃ জন্ম নিবন্ধন', '0002-0002-0002-0002', '0.00', '2016-09-22 14:07:31');
INSERT INTO `acinfo` (`id`, `acname`, `acno`, `balance`, `last_update`) VALUES ('8', 'উন্নয়ন তহবিলঃ এলজিএসপি', '0003-0003-0003-0003', '0.00', '2016-09-22 14:07:31');
INSERT INTO `acinfo` (`id`, `acname`, `acno`, `balance`, `last_update`) VALUES ('9', 'উন্নয়ন তহবিলঃ ভূমি হস্তান্তর কর ১%', '0004-0004-0004-0004', '0.00', '2016-09-22 14:07:31');


#
# TABLE STRUCTURE FOR: acl
#

DROP TABLE IF EXISTS `acl`;

CREATE TABLE `acl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `role_name` varchar(50) NOT NULL,
  `widget` text NOT NULL,
  `ins_date` date NOT NULL,
  `insert_by` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `acl` (`id`, `role_id`, `role_name`, `widget`, `ins_date`, `insert_by`) VALUES ('1', '1', 'Super Admin', 'index,nagorickapplicant,assessmentForm,rateSheet,holdingRateSheet,memberAddForm,nagorickInfo,nagorickGenarate,nagorickapplicant,nagorickInfo,upMap,nagorickBangla,nagorickEnglish,nagorickMoneyReceipt,tradelicenseapplicant,tradelicenseInfo,tradelicenseGenarate,tradelicenseapplicant,tradelicenseInfo,tradelicenseBangla,tradelicenseEnglish,tradelicenseMoneyReceipt,tradelicenseapplicant,warishapplicant,warishInfo,warishGenarate,warishapplicant,warishInfo,warishBangla,warishEnglish,warishMoneyReceipt,dailySubmit,taxCollection,bankTransfers,fundTransfers,allroshid,tradelicenseMoneyReceipt,tradelicense_tab_roshid,tradelicenseMoneyReceipt,bosodbitakor_tab_roshid,bosodbitakorMoneyReceipt,peshajibikor_tab_roshid,peshaMoneyReceipt,dailycollection_tab_roshid,dailyCollectionMoneyReceipt,nagoriksonod_tab_roshid,,warishsonod_tab_roshid,,trade_bosodbitakor_tab_roshid,tradeBosodbitakorMoneyReceipt,dailyCollection,dailyVatCollection,dailyBankDetails,dailyMainLedger,dailySubLedger,employeeList,employeeManage,role,role_list,webSiteUpMemberList,webSiteUpMemberUpdate,webSiteUpMemberDelete,webSiteUpMembterAdd,charimanMessage,newsManage,dynamicSlide,unionPorishad,toolSetting,newAccEntry,mainCtgEntry,SubCtgEntry,ExpCtgEntry,ExpSubCtgEntry,changePassword,adminProfile', '2016-02-10', 'admin');
INSERT INTO `acl` (`id`, `role_id`, `role_name`, `widget`, `ins_date`, `insert_by`) VALUES ('2', '2', 'aa', 'index,nagorickapplicant,nagorickInfo,nagorickGenarate,nagorickapplicant,nagorickInfo,nagorickBangla,nagorickEnglish,nagorickMoneyReceipt,tradelicenseapplicant,tradelicenseInfo,tradelicenseGenarate,tradelicenseapplicant,tradelicenseInfo,tradelicenseBangla,tradelicenseEnglish,tradelicenseMoneyReceipt,tradelicenseapplicant,warishapplicant,warishInfo,warishGenarate,warishapplicant,warishInfo,warishBangla,warishEnglish,warishMoneyReceipt,dailySubmit,taxCollection,bankTransfers,fundTransfers,allroshid,tradelicenseMoneyReceipt,tradelicense_tab_roshid,tradelicenseMoneyReceipt,bosodbitakor_tab_roshid,bosodbitakorMoneyReceipt,peshajibikor_tab_roshid,peshaMoneyReceipt,dailycollection_tab_roshid,dailyCollectionMoneyReceipt,nagoriksonod_tab_roshid,,warishsonod_tab_roshid,,trade_bosodbitakor_tab_roshid,tradeBosodbitakorMoneyReceipt,dailyCollection,dailyVatCollection,dailyBankDetails,dailyMainLedger,dailySubLedger,employeeList,employeeManage,role,role_list,webSiteUpMemberList,webSiteUpMemberUpdate,webSiteUpMemberDelete,webSiteUpMembterAdd,charimanMessage,newsManage,dynamicSlide,upMap,unionPorishad,toolSetting,newAccEntry,mainCtgEntry,SubCtgEntry,ExpCtgEntry,ExpSubCtgEntry,changePassword,adminProfile', '2017-06-11', 'abs_rana');


#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `fullname` varchar(60) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `passDateTime` date NOT NULL,
  `email` varchar(60) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `desig` varchar(60) NOT NULL,
  `pic` varchar(160) NOT NULL,
  `sid` varchar(255) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `trans_pin_code` varchar(8) NOT NULL,
  `verify_mobile` tinyint(1) NOT NULL,
  `verify_email` tinyint(1) NOT NULL,
  `question_id` int(11) NOT NULL,
  `security_setting` enum('1','0') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobile` (`mobile`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `admin` (`id`, `role_id`, `username`, `fullname`, `pass`, `passDateTime`, `email`, `mobile`, `desig`, `pic`, `sid`, `status`, `trans_pin_code`, `verify_mobile`, `verify_email`, `question_id`, `security_setting`) VALUES ('8', '1', 'abs_rana', 'Rana', 'e267cfcd18461ce938067eca67c59f41', '2017-08-21', 'rana.feni.fci@gmail.com', '01825292980', 'DCB Adminitration', 'rana.jpg', '78851a93be448b9f7216e9b8c939e4f0', '1', '', '1', '0', '0', '1');
INSERT INTO `admin` (`id`, `role_id`, `username`, `fullname`, `pass`, `passDateTime`, `email`, `mobile`, `desig`, `pic`, `sid`, `status`, `trans_pin_code`, `verify_mobile`, `verify_email`, `question_id`, `security_setting`) VALUES ('10', '1', 'admin', 'demo', 'asd', '0000-00-00', 'dsf@gmail.com', '01825292981', '', '', '', '1', '', '1', '0', '0', '1');


#
# TABLE STRUCTURE FOR: app_list
#

DROP TABLE IF EXISTS `app_list`;

CREATE TABLE `app_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `app_mac` varchar(30) NOT NULL,
  `app_name` varchar(150) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `registered_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `app_list` (`id`, `app_id`, `app_mac`, `app_name`, `user_name`, `address`, `registered_date`) VALUES ('1', '2150', 'Online Registration', 'Correction_up', 'abs_rana', 'datacenter', '2016-09-24 15:36:50');


#
# TABLE STRUCTURE FOR: app_validation
#

DROP TABLE IF EXISTS `app_validation`;

CREATE TABLE `app_validation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `license_key` varchar(500) NOT NULL,
  `duration` int(11) NOT NULL,
  `pc_user` varchar(80) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `license_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `app_validation` (`id`, `app_id`, `license_key`, `duration`, `pc_user`, `ip`, `license_date`) VALUES ('1', '2150', '97wqiQ48UMndgMNu1HV4qUqZV3VlSjeT2G7CAhj5zvd5jULgXKeWHW7ALq8qpiASyMBMiP/ivdmLCtQ4oxjKmoWcH4kxj7xviNa+JVjwTV2GV+hU8CjVaw+iGdj4iSvq', '770', 'Rana', '::1', '2018-03-23 00:00:00');


#
# TABLE STRUCTURE FOR: buisnestypes
#

DROP TABLE IF EXISTS `buisnestypes`;

CREATE TABLE `buisnestypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: chairman_message
#

DROP TABLE IF EXISTS `chairman_message`;

CREATE TABLE `chairman_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `update_by` varchar(40) NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `chairman_message` (`id`, `title`, `message`, `update_by`, `update_time`) VALUES ('1', '', 'বাংলাদেশ সরকারের ‘ভিশন ২০২১ রূপকল্পে ডিজিটাল বাংলাদেশ গড়ার লক্ষে জনগণের দোরগোড়ায় সেবা এই স্লোগানকে সামনে রেখে গত ১১/১১/২০১০ খ্রিঃ তারিখ প্রধানমন্ত্রীর কার্যালয়ের একসেস টু ইনফরমেশন(এটুআই) প্রকল্পের আওতায় মাননীয় প্রধানমন্ত্রী ইউনিয়ন পরিষদে স্থাপিত তথ্য-প্রযুক্তি ভিত্তিক কেন্দ্র ‘ইউনিয়ন তথ্য ও সেবা কেন্দ্র(ইউআইএসসি)’ উদ্বোধন করেন। সরকারী নির্দেশনা মোতাবেক সিধলা ইউনিয়ন পরিষদ অফিসেও একটি তথ্য ও সেবা কেন্দ্র গড়ে তোলা হয়। ফলে এই তথ্য ও সেবা কেন্দ্র থেকে ইউনিয়নের সাধারণ জনগণ তাদের প্রয়োজনীয় নাগরিক সনদ ছাড়াও বিভিন্ন তথ্য প্রযুক্তি বিষয়ক সেবা গ্রহণ করতে পারছে। এই কেন্দ্রের সেবার পরিধি দিন দিন আরো বৃদ্ধি পাচ্ছে।  পরম করুনাময়ের কাছে তাই অশেষ কৃতজ্ঞতা। গত ২৩/০৬/২০১৪ খ্রিঃ তারিখ প্রধানমন্ত্রীর কার্যালয়ের একসেস টু ইনফরমেশন(এটুআই) প্রকল্পের আওতায় ‘জাতীয় তথ্য বাতায়ন’(National Web Portal) এর শুভ উদ্বোধন করা হয়। যা ডিজিটাল বাংলাদেশ বিনির্মানে একটি যুগান্তকারী পদক্ষেপ। এই তথ্য বাতায়নের অংশ হিসেবে সিধলা  ইউনিয়ন তথ্য বাতায়ন’(Union Web Portal) খোলা হয়েছে। আমাদের নিবেদিত প্রান উদ্যেক্তাগন যাকে দিন দিন সমৃদ্ধ করেছে। এই তথ্য বাতায়নের মাধ্যমে পৃথিবীর যেকোন প্রান্ত থেকে মানুষ এখন  সিধলা ইউনিয়নের ইতিহাস ও ঐতিহ্য, ভৌগলিক অবস্থা, ভাষা ও সংস্কৃতি, শিক্ষা, স্বাস্থ্য, কৃষি, যাতায়াত ব্যবস্থা, উন্নয়নমূলক কর্মকান্ড, সামাজিক সেবামূলক কর্মকান্ড ইত্যাদি বিষয়ক তথ্য জানতে পারবে। বর্তমান তথ্য প্রযুক্তির যুগে বিশ্ব মানুষের কাছে সিধলা ইউনিয়নকে তুলে ধরতে পারছি। আর এটা সম্ভব হয়েছে একমাত্র এই তথ্য বাতায়ন সৃষ্টির মধ্য দিয়েই। এজন্য আমি আমার ইউনিয়নবাসীর পক্ষ থেকে মাননীয় প্রধানমন্ত্রী ও এটুআই প্রকল্পের সাথে সংশ্লিষ্ট সকলেক আন্তরিক ধন্যবাদ জানাচ্ছি। সাথে সাথে এটাও ব্যক্ত করছি যে, জাতীয় কল্যাণ ও আমার ইউনিয়নের জন্য কল্যাণকর সরকারের এই ধরণের মহান কার্যক্রমে আমি ও আমার ইউনিয়নবাসী সর্বাত্নক সহযোগীতা করব। ', 'zia', '2017-03-21 18:37:14');


#
# TABLE STRUCTURE FOR: cmd
#

DROP TABLE IF EXISTS `cmd`;

CREATE TABLE `cmd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `cmd` (`id`, `title`) VALUES ('1', 'ব্যক্তি মালিকানাধীন');
INSERT INTO `cmd` (`id`, `title`) VALUES ('2', 'যৌথ মালিকানা');
INSERT INTO `cmd` (`id`, `title`) VALUES ('3', 'কোম্পানী');


#
# TABLE STRUCTURE FOR: credit_voucher
#

DROP TABLE IF EXISTS `credit_voucher`;

CREATE TABLE `credit_voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vno` bigint(20) NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8;

INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('1', '1', '2017-03-15 15:36:59');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('2', '2', '2017-03-15 15:58:57');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('3', '3', '2017-03-15 15:59:32');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('4', '4', '2017-03-15 16:00:57');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('5', '5', '2017-03-15 19:43:25');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('6', '6', '2017-03-15 19:49:15');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('7', '7', '2017-03-15 19:49:31');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('8', '8', '2017-03-15 19:52:08');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('9', '1', '2017-03-15 21:14:20');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('10', '9', '2017-03-20 14:02:43');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('11', '10', '2017-04-08 16:32:49');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('12', '11', '2017-04-08 16:34:24');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('13', '12', '2017-04-09 12:30:43');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('14', '13', '2017-04-12 21:07:24');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('15', '14', '2017-04-12 21:10:56');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('16', '15', '2017-04-12 21:10:56');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('17', '16', '2017-04-12 21:13:43');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('18', '17', '2017-04-13 13:42:52');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('19', '18', '2017-04-13 20:31:58');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('20', '19', '2017-04-13 22:20:02');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('21', '20', '2017-04-13 22:23:20');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('22', '21', '2017-04-13 22:28:17');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('23', '22', '2017-04-14 14:34:56');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('24', '23', '2017-04-14 14:35:51');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('25', '24', '2017-04-14 14:37:35');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('26', '25', '2017-04-14 15:24:43');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('27', '26', '2017-04-14 15:28:15');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('28', '27', '2017-04-14 15:31:10');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('29', '28', '2017-04-14 15:34:18');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('31', '29', '2017-04-14 15:35:23');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('32', '30', '2017-04-14 15:38:54');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('33', '31', '2017-04-14 15:40:42');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('34', '32', '2017-04-14 18:02:36');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('35', '33', '2017-04-14 18:07:04');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('38', '34', '2017-04-14 18:14:15');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('39', '35', '2017-04-14 21:19:33');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('40', '36', '2017-04-18 18:29:26');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('41', '37', '2017-05-01 01:45:07');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('42', '38', '2017-06-08 17:06:16');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('43', '39', '2017-12-02 16:11:59');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('44', '40', '2017-12-10 22:53:21');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('45', '41', '2017-12-10 22:55:37');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('50', '42', '2017-12-10 22:59:01');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('55', '43', '2017-12-10 23:02:27');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('61', '44', '2017-12-10 23:13:04');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('62', '45', '2017-12-10 23:15:26');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('63', '46', '2017-12-10 23:15:27');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('64', '47', '2017-12-10 23:17:48');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('65', '48', '2017-12-10 23:19:48');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('66', '49', '2017-12-10 23:24:38');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('67', '50', '2017-12-10 23:26:41');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('68', '51', '2017-12-10 23:28:29');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('69', '52', '2017-12-10 23:34:19');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('70', '53', '2017-12-10 23:45:01');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('71', '54', '2017-12-10 23:46:37');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('72', '55', '2017-12-10 23:49:31');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('75', '56', '2017-12-10 23:54:33');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('79', '57', '2017-12-10 23:56:58');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('80', '58', '2017-12-10 23:57:00');
INSERT INTO `credit_voucher` (`id`, `vno`, `utime`) VALUES ('81', '59', '2018-01-22 13:08:19');


#
# TABLE STRUCTURE FOR: dailycollection
#

DROP TABLE IF EXISTS `dailycollection`;

CREATE TABLE `dailycollection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `transid` bigint(20) NOT NULL,
  `sub_cat` int(11) NOT NULL,
  `voucherno` bigint(20) NOT NULL,
  `accounts` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `paytype` varchar(50) NOT NULL,
  `slipno` varchar(100) NOT NULL,
  `chno` varchar(100) NOT NULL,
  `bank` varchar(100) NOT NULL,
  `issue` date NOT NULL,
  `pono` varchar(100) NOT NULL,
  `ddno` varchar(100) NOT NULL,
  `ttno` varchar(100) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `des` text NOT NULL,
  `payment_date` date NOT NULL,
  `update_by` varchar(40) NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: dailyexp
#

DROP TABLE IF EXISTS `dailyexp`;

CREATE TABLE `dailyexp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `sub_cat` int(11) NOT NULL,
  `transid` bigint(20) NOT NULL,
  `voucherno` bigint(20) NOT NULL,
  `accounts` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `paytype` varchar(50) NOT NULL,
  `slipno` varchar(100) NOT NULL,
  `chno` varchar(100) NOT NULL,
  `bank` varchar(100) NOT NULL,
  `issue` date NOT NULL,
  `pono` varchar(100) NOT NULL,
  `ddno` varchar(100) NOT NULL,
  `ttno` varchar(100) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `des` text NOT NULL,
  `payment_date` date NOT NULL,
  `update_by` varchar(40) NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: dcb_login_history
#

DROP TABLE IF EXISTS `dcb_login_history`;

CREATE TABLE `dcb_login_history` (
  `history_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `device_browser` text NOT NULL,
  `pc_ip` varchar(30) NOT NULL,
  `mac` varchar(30) NOT NULL,
  `login_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`history_id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;

INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('1', '1', 'Chrome 56.0.2924.87', '::1', 'mac', '2017-03-15 19:34:20', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('2', '1', 'Chrome 56.0.2924.87', '::1', 'mac', '2017-03-16 15:29:04', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('3', '1', 'Chrome 56.0.2924.87', '::1', 'mac', '2017-03-19 18:08:35', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('4', '1', 'Chrome 56.0.2924.87', '::1', 'mac', '2017-03-20 13:28:50', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('5', '1', 'Chrome 56.0.2924.87', '::1', 'mac', '2017-03-21 12:39:21', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('6', '1', 'Chrome 56.0.2924.87', '::1', 'mac', '2017-03-22 16:51:33', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('7', '1', 'Chrome 56.0.2924.87', '::1', 'mac', '2017-03-27 13:16:17', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('8', '1', 'Chrome 56.0.2924.87', '::1', 'mac', '2017-04-01 13:57:18', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('9', '1', 'Chrome 56.0.2924.87', '::1', 'mac', '2017-04-03 12:13:47', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('10', '1', 'Chrome 56.0.2924.87', '::1', 'mac', '2017-04-06 13:17:02', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('11', '1', 'Chrome 56.0.2924.87', '::1', 'mac', '2017-04-08 11:53:48', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('12', '1', 'Chrome 56.0.2924.87', '::1', 'mac', '2017-04-09 12:00:40', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('13', '1', 'Chrome 56.0.2924.87', '::1', 'mac', '2017-04-10 15:23:14', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('14', '1', 'Chrome 56.0.2924.87', '::1', 'mac', '2017-04-11 13:06:32', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('15', '1', 'Chrome 56.0.2924.87', '::1', 'mac', '2017-04-11 19:26:15', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('16', '1', 'Chrome 57.0.2987.133', '::1', 'mac', '2017-04-12 16:10:51', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('17', '1', 'Chrome 57.0.2987.133', '::1', 'mac', '2017-04-12 18:10:14', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('18', '1', 'Chrome 57.0.2987.133', '::1', 'mac', '2017-04-13 12:29:51', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('19', '1', 'Chrome 57.0.2987.133', '103.31.178.26', 'mac', '2017-04-13 20:11:50', '2017-04-13 20:40:44');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('20', '1', 'Chrome 57.0.2987.133', '103.31.178.26', 'mac', '2017-04-13 20:40:53', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('21', '5', 'Chrome 49.0.2623.112', '119.30.32.133', 'mac', '2017-04-13 20:55:54', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('22', '5', 'Chrome 49.0.2623.112', '103.67.159.209', 'mac', '2017-04-14 14:31:38', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('23', '5', 'Chrome 49.0.2623.112', '103.67.159.209', 'mac', '2017-04-14 14:32:08', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('24', '5', 'Chrome 49.0.2623.112', '103.67.159.209', 'mac', '2017-04-14 14:32:21', '2017-04-14 18:17:30');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('25', '1', 'Chrome 49.0.2623.112', '116.58.200.166', 'mac', '2017-04-14 18:18:58', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('26', '1', 'Chrome 49.0.2623.112', '116.58.203.89', 'mac', '2017-04-15 10:29:19', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('27', '1', 'Chrome 49.0.2623.112', '116.58.205.94', 'mac', '2017-04-15 16:29:59', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('28', '1', 'Chrome 49.0.2623.112', '116.58.201.212', 'mac', '2017-04-16 11:28:37', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('29', '1', 'Chrome 57.0.2987.133', '103.31.178.26', 'mac', '2017-04-16 18:48:18', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('30', '1', 'Chrome 49.0.2623.112', '103.67.156.30', 'mac', '2017-04-16 19:17:49', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('31', '1', 'Chrome 57.0.2987.133', '103.31.178.26', 'mac', '2017-04-17 12:35:24', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('32', '1', 'Chrome 57.0.2987.133', '::1', 'mac', '2017-04-18 12:14:15', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('33', '1', 'Chrome 57.0.2987.133', '::1', 'mac', '2017-04-19 15:52:22', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('34', '1', 'Chrome 57.0.2987.133', '::1', 'mac', '2017-04-20 16:14:59', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('35', '1', 'Chrome 57.0.2987.133', '::1', 'mac', '2017-04-22 15:29:58', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('36', '1', 'Chrome 57.0.2987.133', '::1', 'mac', '2017-04-23 15:07:22', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('37', '1', 'Chrome 57.0.2987.133', '::1', 'mac', '2017-04-23 23:29:24', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('38', '1', 'Chrome 57.0.2987.133', '::1', 'mac', '2017-04-24 20:14:50', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('39', '1', 'Chrome 57.0.2987.133', '::1', 'mac', '2017-04-25 12:21:40', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('40', '1', 'Chrome 57.0.2987.133', '::1', 'mac', '2017-04-25 12:29:32', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('41', '1', 'Chrome 57.0.2987.133', '::1', 'mac', '2017-04-27 13:48:35', '2017-04-27 18:23:47');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('42', '6', 'Chrome 57.0.2987.133', '::1', 'mac', '2017-04-27 18:23:56', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('43', '1', 'Chrome 58.0.3029.81', '::1', 'mac', '2017-04-29 16:05:47', '2017-04-29 16:11:29');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('44', '1', 'Chrome 58.0.3029.81', '::1', 'mac', '2017-04-29 16:11:40', '2017-04-29 16:15:41');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('45', '1', 'Chrome 58.0.3029.81', '::1', 'mac', '2017-04-29 16:15:46', '2017-04-29 16:20:10');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('46', '1', 'Chrome 58.0.3029.81', '::1', 'mac', '2017-04-29 16:20:23', '2017-04-29 16:47:09');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('47', '1', 'Chrome 58.0.3029.81', '::1', 'mac', '2017-04-29 16:47:19', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('48', '1', 'Chrome 58.0.3029.81', '::1', 'mac', '2017-04-29 16:49:05', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('49', '1', 'Chrome 58.0.3029.81', '::1', 'mac', '2017-05-01 01:42:57', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('50', '1', 'Chrome 58.0.3029.81', '::1', 'mac', '2017-05-02 13:40:59', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('51', '1', 'Chrome 58.0.3029.81', '::1', 'mac', '2017-05-02 20:39:04', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('52', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-06 13:25:58', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('53', '1', 'Firefox 53.0', '::1', 'mac', '2017-05-06 16:11:09', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('54', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-07 15:03:10', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('55', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-07 15:16:27', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('56', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-07 16:14:09', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('57', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-07 16:16:52', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('58', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-07 16:19:10', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('59', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-07 16:43:24', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('60', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-07 16:48:39', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('61', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-07 18:34:28', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('62', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-07 18:59:08', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('63', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-07 19:18:23', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('64', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-07 19:42:16', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('65', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-09 14:41:19', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('66', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-09 18:11:45', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('67', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-09 21:50:36', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('68', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-10 12:56:41', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('69', '1', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-10 16:42:32', '2017-05-10 19:05:38');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('70', '8', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-10 19:06:29', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('71', '8', 'Chrome 58.0.3029.96', '::1', 'mac', '2017-05-11 13:09:35', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('72', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-05-16 19:35:35', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('73', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-05-18 12:19:04', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('74', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-05-20 18:23:16', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('75', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-05-24 00:37:36', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('76', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-05-24 12:36:38', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('77', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-05-24 14:04:26', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('78', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-05-24 14:25:27', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('79', '8', 'Chrome 58.0.3029.110', '127.0.0.1', 'mac', '2017-05-26 04:01:08', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('80', '8', 'Chrome 58.0.3029.110', '127.0.0.1', 'mac', '2017-05-27 00:17:02', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('81', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-05-30 23:41:38', '2017-05-31 01:05:01');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('82', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-05-31 16:07:53', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('83', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-06-05 13:42:39', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('84', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-06-08 14:58:59', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('85', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-06-08 17:05:38', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('86', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-06-11 00:58:42', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('87', '8', 'Firefox 54.0', '::1', 'mac', '2017-06-11 01:04:23', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('88', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-06-11 13:44:31', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('89', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-06-12 20:19:44', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('90', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-06-13 00:14:14', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('91', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-06-17 02:38:03', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('92', '8', 'Chrome 58.0.3029.110', '::1', 'mac', '2017-06-22 14:53:39', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('93', '8', 'Chrome 59.0.3071.115', '::1', 'mac', '2017-08-08 21:44:42', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('94', '8', 'Chrome 60.0.3112.113', '::1', 'mac', '2017-09-12 18:18:33', '2017-09-12 18:21:21');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('95', '8', 'Chrome 60.0.3112.113', '::1', 'mac', '2017-09-12 18:21:27', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('96', '8', 'Chrome 60.0.3112.113', '::1', 'mac', '2017-09-20 00:57:56', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('97', '8', 'Chrome 61.0.3163.100', '::1', 'mac', '2017-10-04 17:33:56', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('98', '8', 'Chrome 61.0.3163.100', '::1', 'mac', '2017-10-08 15:34:57', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('99', '8', 'Chrome 61.0.3163.100', '::1', 'mac', '2017-10-18 23:24:21', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('100', '8', 'Chrome 61.0.3163.100', '::1', 'mac', '2017-10-22 23:45:44', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('101', '8', 'Chrome 61.0.3163.100', '::1', 'mac', '2017-10-24 00:17:56', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('102', '8', 'Chrome 61.0.3163.100', '::1', 'mac', '2017-10-25 08:38:26', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('103', '8', 'Chrome 61.0.3163.100', '::1', 'mac', '2017-10-25 22:02:09', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('104', '8', 'Chrome 61.0.3163.100', '::1', 'mac', '2017-10-25 22:28:48', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('105', '8', 'Chrome 61.0.3163.100', '::1', 'mac', '2017-10-27 01:08:39', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('106', '8', 'Chrome 62.0.3202.94', '::1', 'mac', '2017-12-02 14:02:03', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('107', '8', 'Chrome 62.0.3202.94', '::1', 'mac', '2017-12-03 23:39:42', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('108', '8', 'Chrome 62.0.3202.94', '::1', 'mac', '2017-12-04 23:51:40', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('109', '8', 'Chrome 62.0.3202.94', '::1', 'mac', '2017-12-10 00:31:43', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('110', '8', 'Chrome 62.0.3202.94', '::1', 'mac', '2017-12-10 22:27:14', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('111', '8', 'Chrome 63.0.3239.84', '::1', 'mac', '2017-12-24 13:37:49', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('112', '8', 'Chrome 63.0.3239.132', '::1', 'mac', '2018-01-22 12:40:43', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('113', '8', 'Chrome 64.0.3282.186', '::1', 'mac', '2018-03-23 23:54:51', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('114', '8', 'Chrome 65.0.3325.181', '::1', 'mac', '2018-03-25 23:27:06', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('115', '8', 'Chrome 65.0.3325.181', '::1', 'mac', '2018-03-26 21:50:07', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('116', '8', 'Chrome 65.0.3325.181', '::1', 'mac', '2018-03-27 00:32:19', '0000-00-00 00:00:00');
INSERT INTO `dcb_login_history` (`history_id`, `user_id`, `device_browser`, `pc_ip`, `mac`, `login_time`, `logout_time`) VALUES ('117', '8', 'Chrome 65.0.3325.181', '::1', 'mac', '2018-03-28 00:56:50', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: dcb_mobile_verfication
#

DROP TABLE IF EXISTS `dcb_mobile_verfication`;

CREATE TABLE `dcb_mobile_verfication` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `code` varchar(6) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '0',
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: dcb_security_question
#

DROP TABLE IF EXISTS `dcb_security_question`;

CREATE TABLE `dcb_security_question` (
  `question_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: dcb_security_setting
#

DROP TABLE IF EXISTS `dcb_security_setting`;

CREATE TABLE `dcb_security_setting` (
  `security_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `two_step_verify` enum('on','off') NOT NULL DEFAULT 'off',
  `security_question_verify` enum('on','off') NOT NULL DEFAULT 'off',
  `trans_pin_code` enum('on','off') NOT NULL DEFAULT 'off',
  `mobile_verify` enum('on','off') NOT NULL DEFAULT 'off',
  `email_verify` enum('on','off') NOT NULL DEFAULT 'off',
  `send_sms_verify` enum('on','off') NOT NULL DEFAULT 'off',
  `random_picture_verify` enum('on','off') NOT NULL DEFAULT 'off',
  `password_complexity` enum('on','off') NOT NULL DEFAULT 'off',
  `pass_change_45_days` enum('on','off') NOT NULL DEFAULT 'off',
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`security_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: dcb_sms
#

DROP TABLE IF EXISTS `dcb_sms`;

CREATE TABLE `dcb_sms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(40) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `api_key` text NOT NULL,
  `api_url` text NOT NULL,
  `credit` decimal(10,2) NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `dcb_sms` (`id`, `username`, `pass`, `api_key`, `api_url`, `credit`, `entry_date`) VALUES ('1', 'asfdasdf', 'dfasdfs', 'dfsadfds', 'dfsadfs', '12.00', '2017-06-17 04:49:57');


#
# TABLE STRUCTURE FOR: dcb_sms_notification
#

DROP TABLE IF EXISTS `dcb_sms_notification`;

CREATE TABLE `dcb_sms_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wedgets` text NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `dcb_sms_notification` (`id`, `wedgets`, `entry_date`) VALUES ('1', 'nagorik_app_on,nagorik_sonod_on,tradelicense_app_on,tradelicense_sonod_on,tradelicense_renew_On,oarish_app_on,oarish_sonod_on', '2017-04-14 18:26:03');


#
# TABLE STRUCTURE FOR: dcb_sms_setting
#

DROP TABLE IF EXISTS `dcb_sms_setting`;

CREATE TABLE `dcb_sms_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sms_type` tinyint(2) NOT NULL,
  `msg` text NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: dcb_sq_ans
#

DROP TABLE IF EXISTS `dcb_sq_ans`;

CREATE TABLE `dcb_sq_ans` (
  `ans_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `ans` text NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ans_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: debit_voucher
#

DROP TABLE IF EXISTS `debit_voucher`;

CREATE TABLE `debit_voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vno` bigint(20) NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `debit_voucher` (`id`, `vno`, `utime`) VALUES ('1', '1', '2017-04-01 13:59:40');
INSERT INTO `debit_voucher` (`id`, `vno`, `utime`) VALUES ('2', '2', '2017-05-06 17:44:01');


#
# TABLE STRUCTURE FOR: exphead
#

DROP TABLE IF EXISTS `exphead`;

CREATE TABLE `exphead` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fund` tinyint(3) NOT NULL,
  `title` varchar(255) NOT NULL,
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO `exphead` (`id`, `fund`, `title`, `balance`) VALUES ('1', '2', 'সাধারন সংস্হাপন', '0.00');
INSERT INTO `exphead` (`id`, `fund`, `title`, `balance`) VALUES ('2', '1', 'যোগাযোগ', '0.00');
INSERT INTO `exphead` (`id`, `fund`, `title`, `balance`) VALUES ('3', '2', 'স্বাস্থ্য', '0.00');
INSERT INTO `exphead` (`id`, `fund`, `title`, `balance`) VALUES ('4', '1', 'পানি সরবরাহ', '0.00');
INSERT INTO `exphead` (`id`, `fund`, `title`, `balance`) VALUES ('5', '1', 'শিক্ষা', '0.00');
INSERT INTO `exphead` (`id`, `fund`, `title`, `balance`) VALUES ('6', '1', 'প্রাকৃতিক সম্পদ ব্যবস্হাপনা', '0.00');
INSERT INTO `exphead` (`id`, `fund`, `title`, `balance`) VALUES ('7', '1', 'কৃষি ও বাজার', '0.00');
INSERT INTO `exphead` (`id`, `fund`, `title`, `balance`) VALUES ('8', '1', 'পয়নিষ্কাশন এবং বর্জ্য ব্যবস্থাপনা', '0.00');
INSERT INTO `exphead` (`id`, `fund`, `title`, `balance`) VALUES ('9', '1', 'মানব সম্পদ উন্নয়ন', '0.00');
INSERT INTO `exphead` (`id`, `fund`, `title`, `balance`) VALUES ('10', '1', 'অন্যান্য', '0.00');
INSERT INTO `exphead` (`id`, `fund`, `title`, `balance`) VALUES ('11', '1', 'এলজিএসপি ফান্ড ফেরত হইতে ব্যয়', '0.00');
INSERT INTO `exphead` (`id`, `fund`, `title`, `balance`) VALUES ('12', '1', 'অন্যা্ন্য ফান্ড ফেরত হইতে ব্যয়', '0.00');
INSERT INTO `exphead` (`id`, `fund`, `title`, `balance`) VALUES ('13', '2', 'অডিট', '0.00');
INSERT INTO `exphead` (`id`, `fund`, `title`, `balance`) VALUES ('14', '1', 'অগ্রিম', '0.00');


#
# TABLE STRUCTURE FOR: expurpose
#

DROP TABLE IF EXISTS `expurpose`;

CREATE TABLE `expurpose` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `pname` varchar(255) NOT NULL,
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `expurpose` (`id`, `pid`, `pname`, `balance`) VALUES ('1', '1', 'চেয়ারম্যান ও সদস্যদের ভাতা', '0.00');
INSERT INTO `expurpose` (`id`, `pid`, `pname`, `balance`) VALUES ('2', '1', 'সেক্রেটারী ও অন্যান্য কর্মচারীদের বেতন', '0.00');
INSERT INTO `expurpose` (`id`, `pid`, `pname`, `balance`) VALUES ('3', '5', 'কাবিখা', '0.00');
INSERT INTO `expurpose` (`id`, `pid`, `pname`, `balance`) VALUES ('4', '5', 'টি আর', '0.00');
INSERT INTO `expurpose` (`id`, `pid`, `pname`, `balance`) VALUES ('5', '3', 'এডিপি', '0.00');
INSERT INTO `expurpose` (`id`, `pid`, `pname`, `balance`) VALUES ('6', '3', 'অতিদরিদ্র কর্মসূচি', '0.00');


#
# TABLE STRUCTURE FOR: fund_sub_ctg
#

DROP TABLE IF EXISTS `fund_sub_ctg`;

CREATE TABLE `fund_sub_ctg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mc_id` smallint(6) NOT NULL,
  `subid` smallint(6) NOT NULL,
  `fund_id` tinyint(4) NOT NULL,
  `trno` bigint(20) NOT NULL,
  `voucherno` bigint(20) NOT NULL,
  `vtype` enum('C','D') NOT NULL DEFAULT 'C',
  `sub_title` varchar(255) NOT NULL,
  `dr` decimal(10,2) NOT NULL,
  `cr` decimal(10,2) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `payment_date` date NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;

INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('1', '3', '2', '2', '1', '1', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '575.00', '575.00', '2017-03-15', '2017-03-15 15:36:59');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('2', '1', '4', '2', '2', '2', 'C', 'ব্যবসা,পেশা ও জীবিকার উপর কর', '0.00', '1000.00', '1000.00', '2017-03-15', '2017-03-15 15:58:57');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('3', '1', '3', '2', '3', '3', 'C', 'বসতভিটার উপর কর', '0.00', '1500.00', '1500.00', '2017-03-15', '2017-03-15 15:59:32');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('4', '6', '1', '2', '4', '4', 'C', 'অন্যান্য ফি', '0.00', '100.00', '100.00', '2017-03-15', '2017-03-15 16:00:57');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('5', '3', '2', '2', '5', '5', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '2875.00', '3450.00', '2017-03-15', '2017-03-15 19:43:26');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('6', '1', '4', '2', '6', '6', 'C', 'ব্যবসা,পেশা ও জীবিকার উপর কর', '0.00', '1000.00', '2000.00', '2017-03-15', '2017-03-15 19:49:15');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('7', '1', '3', '2', '7', '7', 'C', 'বসতভিটার উপর কর', '0.00', '1500.00', '3000.00', '2017-03-15', '2017-03-15 19:49:31');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('8', '6', '1', '2', '8', '8', 'C', 'অন্যান্য ফি', '0.00', '150.00', '250.00', '2017-03-15', '2017-03-15 19:52:08');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('9', '6', '1', '2', '10', '9', 'C', 'অন্যান্য ফি', '0.00', '0.00', '250.00', '2017-03-20', '2017-03-20 14:02:43');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('10', '1', '3', '2', '12', '10', 'C', 'বসতভিটার উপর কর', '0.00', '500.00', '3500.00', '2017-04-08', '2017-04-08 16:32:49');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('11', '1', '3', '2', '13', '11', 'C', 'বসতভিটার উপর কর', '0.00', '500.00', '4000.00', '2017-04-08', '2017-04-08 16:34:24');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('12', '1', '3', '2', '14', '12', 'C', 'বসতভিটার উপর কর', '0.00', '500.00', '4500.00', '2017-04-09', '2017-04-09 12:30:43');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('13', '6', '1', '2', '15', '13', 'C', 'অন্যান্য ফি', '0.00', '0.00', '250.00', '2017-04-12', '2017-04-12 21:07:24');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('14', '6', '1', '2', '16', '14', 'C', 'অন্যান্য ফি', '0.00', '111.00', '361.00', '2017-04-12', '2017-04-12 21:10:56');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('15', '6', '1', '2', '17', '15', 'C', 'অন্যান্য ফি', '0.00', '111.00', '472.00', '2017-04-12', '2017-04-12 21:10:56');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('16', '6', '1', '2', '18', '16', 'C', 'অন্যান্য ফি', '0.00', '120.00', '592.00', '2017-04-12', '2017-04-12 21:13:43');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('17', '6', '1', '2', '19', '17', 'C', 'অন্যান্য ফি', '0.00', '120.00', '712.00', '2017-04-13', '2017-04-13 13:42:52');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('18', '6', '1', '2', '20', '18', 'C', 'অন্যান্য ফি', '0.00', '50.00', '762.00', '2017-04-13', '2017-04-13 20:31:58');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('19', '6', '1', '2', '21', '19', 'C', 'অন্যান্য ফি', '0.00', '0.00', '762.00', '2017-04-13', '2017-04-13 22:20:02');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('20', '6', '1', '2', '22', '20', 'C', 'অন্যান্য ফি', '0.00', '0.00', '762.00', '2017-04-13', '2017-04-13 22:23:20');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('21', '6', '1', '2', '23', '21', 'C', 'অন্যান্য ফি', '0.00', '0.00', '762.00', '2017-04-13', '2017-04-13 22:28:17');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('22', '6', '1', '2', '24', '22', 'C', 'অন্যান্য ফি', '0.00', '0.00', '762.00', '2017-04-14', '2017-04-14 14:34:56');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('23', '6', '1', '2', '25', '23', 'C', 'অন্যান্য ফি', '0.00', '0.00', '762.00', '2017-04-14', '2017-04-14 14:35:51');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('24', '6', '1', '2', '26', '24', 'C', 'অন্যান্য ফি', '0.00', '0.00', '762.00', '2017-04-14', '2017-04-14 14:37:35');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('25', '6', '1', '2', '27', '25', 'C', 'অন্যান্য ফি', '0.00', '0.00', '762.00', '2017-04-14', '2017-04-14 15:24:43');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('26', '6', '1', '2', '28', '26', 'C', 'অন্যান্য ফি', '0.00', '0.00', '762.00', '2017-04-14', '2017-04-14 15:28:15');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('27', '6', '1', '2', '29', '27', 'C', 'অন্যান্য ফি', '0.00', '0.00', '762.00', '2017-04-14', '2017-04-14 15:31:10');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('28', '6', '1', '2', '30', '28', 'C', 'অন্যান্য ফি', '0.00', '0.00', '762.00', '2017-04-14', '2017-04-14 15:34:18');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('30', '6', '1', '2', '31', '29', 'C', 'অন্যান্য ফি', '0.00', '0.00', '762.00', '2017-04-14', '2017-04-14 15:35:23');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('31', '6', '1', '2', '32', '30', 'C', 'অন্যান্য ফি', '0.00', '0.00', '762.00', '2017-04-14', '2017-04-14 15:38:54');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('32', '6', '1', '2', '33', '31', 'C', 'অন্যান্য ফি', '0.00', '0.00', '762.00', '2017-04-14', '2017-04-14 15:40:42');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('33', '6', '1', '2', '34', '32', 'C', 'অন্যান্য ফি', '0.00', '0.00', '762.00', '2017-04-14', '2017-04-14 18:02:36');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('34', '1', '3', '2', '35', '33', 'C', 'বসতভিটার উপর কর', '0.00', '300.00', '4800.00', '2017-04-14', '2017-04-14 18:07:04');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('37', '3', '2', '2', '36', '34', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '294.50', '3744.50', '2017-04-14', '2017-04-14 18:14:15');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('38', '6', '1', '2', '37', '35', 'C', 'অন্যান্য ফি', '0.00', '0.00', '762.00', '2017-04-14', '2017-04-14 21:19:33');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('39', '14', '22', '10', '38', '36', 'C', 'udc fee', '0.00', '500.00', '500.00', '2017-04-18', '2017-04-18 18:29:26');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('40', '14', '22', '10', '39', '37', 'C', 'udc fee', '0.00', '0.00', '500.00', '2017-05-01', '2017-05-01 01:45:08');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('41', '1', '4', '2', '41', '38', 'C', 'ব্যবসা,পেশা ও জীবিকার উপর কর', '0.00', '34.00', '2034.00', '2017-06-08', '2017-06-08 17:06:16');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('42', '3', '2', '2', '42', '39', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '6050.00', '9794.50', '2017-12-02', '2017-12-02 16:11:59');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('43', '3', '2', '2', '43', '40', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '230.00', '10024.50', '2017-12-10', '2017-12-10 22:53:21');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('44', '3', '2', '2', '44', '41', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '230.00', '10254.50', '2017-12-10', '2017-12-10 22:55:37');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('49', '3', '2', '2', '45', '42', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '345.00', '10599.50', '2017-12-10', '2017-12-10 22:59:01');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('54', '3', '2', '2', '46', '43', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '2300.00', '12899.50', '2017-12-10', '2017-12-10 23:02:27');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('60', '3', '2', '2', '47', '44', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '138.00', '13037.50', '2017-12-10', '2017-12-10 23:13:04');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('61', '3', '2', '2', '48', '45', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '1380.00', '14417.50', '2017-12-10', '2017-12-10 23:15:26');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('62', '3', '2', '2', '49', '46', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '1380.00', '15797.50', '2017-12-10', '2017-12-10 23:15:27');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('63', '3', '2', '2', '50', '47', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '575.00', '16372.50', '2017-12-10', '2017-12-10 23:17:48');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('64', '3', '2', '2', '51', '48', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '690.00', '17062.50', '2017-12-10', '2017-12-10 23:19:48');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('65', '3', '2', '2', '52', '49', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '460.00', '17522.50', '2017-12-10', '2017-12-10 23:24:38');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('66', '3', '2', '2', '53', '50', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '530.70', '18053.20', '2017-12-10', '2017-12-10 23:26:41');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('67', '3', '2', '2', '54', '51', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '34.50', '18087.70', '2017-12-10', '2017-12-10 23:28:29');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('68', '3', '2', '2', '55', '52', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '345.00', '18432.70', '2017-12-10', '2017-12-10 23:34:19');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('69', '3', '2', '2', '56', '53', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '368.00', '18800.70', '2017-12-10', '2017-12-10 23:45:01');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('70', '3', '2', '2', '57', '54', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '115.00', '18915.70', '2017-12-10', '2017-12-10 23:46:37');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('71', '3', '2', '2', '58', '55', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '138.00', '19053.70', '2017-12-10', '2017-12-10 23:49:31');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('74', '3', '2', '2', '59', '56', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '264.50', '19318.20', '2017-12-10', '2017-12-10 23:54:33');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('78', '3', '2', '2', '60', '57', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '264.50', '19582.70', '2017-12-10', '2017-12-10 23:56:58');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('79', '3', '2', '2', '61', '58', 'C', 'ট্রেড লাইসেন্স ফি', '0.00', '264.50', '19847.20', '2017-12-10', '2017-12-10 23:57:00');
INSERT INTO `fund_sub_ctg` (`id`, `mc_id`, `subid`, `fund_id`, `trno`, `voucherno`, `vtype`, `sub_title`, `dr`, `cr`, `balance`, `payment_date`, `utime`) VALUES ('80', '6', '1', '2', '62', '59', 'C', 'অন্যান্য ফি', '0.00', '0.00', '762.00', '2018-01-22', '2018-01-22 13:08:19');


#
# TABLE STRUCTURE FOR: fund_transfer
#

DROP TABLE IF EXISTS `fund_transfer`;

CREATE TABLE `fund_transfer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `sub_cat` int(11) NOT NULL,
  `transid` bigint(20) NOT NULL,
  `voucherno` bigint(20) NOT NULL,
  `accounts` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `paytype` varchar(50) NOT NULL,
  `slipno` varchar(120) NOT NULL,
  `chno` varchar(120) NOT NULL,
  `bank` varchar(120) NOT NULL,
  `issue` date NOT NULL,
  `pono` varchar(120) NOT NULL,
  `ddno` varchar(120) NOT NULL,
  `ttno` varchar(120) NOT NULL,
  `fid2` int(11) NOT NULL,
  `catid2` int(11) NOT NULL,
  `sub_cat2` smallint(6) NOT NULL,
  `transid2` bigint(20) NOT NULL,
  `voucherno2` bigint(20) NOT NULL,
  `accounts2` varchar(255) NOT NULL,
  `paytype2` varchar(50) NOT NULL,
  `slipno2` varchar(120) NOT NULL,
  `chno2` varchar(120) NOT NULL,
  `bank2` varchar(120) NOT NULL,
  `issue2` date NOT NULL,
  `pono2` varchar(120) NOT NULL,
  `ddno2` varchar(120) NOT NULL,
  `ttno2` varchar(120) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `des` text NOT NULL,
  `update_by` varchar(40) NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: getlicense
#

DROP TABLE IF EXISTS `getlicense`;

CREATE TABLE `getlicense` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trackid` varchar(8) NOT NULL,
  `bno` int(11) NOT NULL,
  `fiscal_year` varchar(40) NOT NULL,
  `trno` bigint(20) NOT NULL,
  `vno` bigint(20) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  `due` decimal(10,2) NOT NULL DEFAULT '0.00',
  `scharge` decimal(10,2) NOT NULL DEFAULT '0.00',
  `sbfee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vat` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payment_date` date NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `update_by` varchar(40) NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('1', '425464', '2', '2016-2017', '1', '1', '500.00', '0.00', '0.00', '0.00', '0.00', '75.00', '575.00', '2017-03-15', '1', 'abs_rana', '2017-03-15 15:36:59');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('2', '486068', '3', '2016-2017', '5', '5', '2500.00', '0.00', '0.00', '0.00', '0.00', '375.00', '2875.00', '2017-03-15', '1', 'abs_rana', '2017-03-15 19:43:25');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('5', '043852', '4', '2016-2017', '36', '34', '200.00', '30.00', '30.00', '200.00', '0.00', '34.50', '294.50', '2017-04-14', '1', 'zia', '2017-04-14 18:14:15');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('6', '171298', '5', '2017-2018', '42', '39', '5000.00', '0.00', '300.00', '0.00', '0.00', '750.00', '6050.00', '2017-12-02', '1', 'abs_rana', '2017-12-02 16:11:59');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('7', '323250', '6', '2017-2018', '43', '40', '200.00', '0.00', '0.00', '0.00', '0.00', '30.00', '230.00', '2017-12-10', '1', 'abs_rana', '2017-12-10 22:53:21');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('8', '958390', '7', '2017-2018', '44', '41', '200.00', '0.00', '0.00', '0.00', '0.00', '30.00', '230.00', '2017-12-10', '1', 'abs_rana', '2017-12-10 22:55:37');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('13', '126339', '13', '2017-2018', '45', '42', '300.00', '0.00', '0.00', '0.00', '0.00', '45.00', '345.00', '2017-12-10', '1', 'abs_rana', '2017-12-10 22:59:01');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('18', '211830', '14', '2017-2018', '46', '43', '2000.00', '0.00', '0.00', '0.00', '0.00', '300.00', '2300.00', '2017-12-10', '1', 'abs_rana', '2017-12-10 23:02:27');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('24', '625696', '15', '2017-2018', '47', '44', '120.00', '0.00', '0.00', '0.00', '0.00', '18.00', '138.00', '2017-12-10', '1', 'abs_rana', '2017-12-10 23:13:04');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('25', '812617', '16', '2017-2018', '48', '45', '1200.00', '0.00', '0.00', '0.00', '0.00', '180.00', '1380.00', '2017-12-10', '1', 'abs_rana', '2017-12-10 23:15:26');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('26', '812617', '16', '2017-2018', '49', '46', '1200.00', '0.00', '0.00', '0.00', '0.00', '180.00', '1380.00', '2017-12-10', '1', 'abs_rana', '2017-12-10 23:15:27');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('27', '780019', '17', '2017-2018', '50', '47', '500.00', '0.00', '0.00', '0.00', '0.00', '75.00', '575.00', '2017-12-10', '1', 'abs_rana', '2017-12-10 23:17:48');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('28', '564239', '18', '2017-2018', '51', '48', '600.00', '0.00', '0.00', '0.00', '0.00', '90.00', '690.00', '2017-12-10', '1', 'abs_rana', '2017-12-10 23:19:48');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('29', '371734', '18', '2017-2018', '52', '49', '200.00', '200.00', '0.00', '0.00', '0.00', '60.00', '460.00', '2017-12-10', '1', 'abs_rana', '2017-12-10 23:24:38');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('30', '580293', '19', '2017-2018', '53', '50', '454.00', '4.00', '4.00', '0.00', '0.00', '68.70', '530.70', '2017-12-10', '1', 'abs_rana', '2017-12-10 23:26:41');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('31', '324714', '19', '2017-2018', '54', '51', '30.00', '0.00', '0.00', '0.00', '0.00', '4.50', '34.50', '2017-12-10', '1', 'abs_rana', '2017-12-10 23:28:29');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('32', '942343', '19', '2017-2018', '55', '52', '300.00', '0.00', '0.00', '0.00', '0.00', '45.00', '345.00', '2017-12-10', '1', 'abs_rana', '2017-12-10 23:34:19');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('33', '767930', '19', '2017-2018', '56', '53', '320.00', '0.00', '0.00', '0.00', '0.00', '48.00', '368.00', '2017-12-10', '1', 'abs_rana', '2017-12-10 23:45:01');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('34', '898083', '20', '2017-2018', '57', '54', '100.00', '0.00', '0.00', '0.00', '0.00', '15.00', '115.00', '2017-12-10', '1', 'abs_rana', '2017-12-10 23:46:37');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('35', '192690', '20', '2017-2018', '58', '55', '120.00', '0.00', '0.00', '0.00', '0.00', '18.00', '138.00', '2017-12-10', '1', 'abs_rana', '2017-12-10 23:49:31');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('38', '142753', '20', '2017-2018', '59', '56', '230.00', '0.00', '0.00', '0.00', '0.00', '34.50', '264.50', '2017-12-10', '1', 'abs_rana', '2017-12-10 23:54:33');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('42', '842728', '21', '2017-2018', '60', '57', '230.00', '0.00', '0.00', '0.00', '0.00', '34.50', '264.50', '2017-12-10', '1', 'abs_rana', '2017-12-10 23:56:58');
INSERT INTO `getlicense` (`id`, `trackid`, `bno`, `fiscal_year`, `trno`, `vno`, `fee`, `due`, `scharge`, `sbfee`, `discount`, `vat`, `total`, `payment_date`, `status`, `update_by`, `utime`) VALUES ('43', '842728', '21', '2017-2018', '61', '58', '230.00', '0.00', '0.00', '0.00', '0.00', '34.50', '264.50', '2017-12-10', '1', 'abs_rana', '2017-12-10 23:57:00');


#
# TABLE STRUCTURE FOR: holding_rate_sheet
#

DROP TABLE IF EXISTS `holding_rate_sheet`;

CREATE TABLE `holding_rate_sheet` (
  `hrid` int(11) NOT NULL AUTO_INCREMENT,
  `holding_type` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ins_user` varchar(60) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`hrid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `holding_rate_sheet` (`hrid`, `holding_type`, `amount`, `up_date`, `ins_user`, `status`) VALUES ('1', 'টিনের ঘর', '575.00', '2017-04-08 12:52:07', 'abs_rana', '1');
INSERT INTO `holding_rate_sheet` (`hrid`, `holding_type`, `amount`, `up_date`, `ins_user`, `status`) VALUES ('2', 'মাটির ঘর', '375.00', '2017-04-08 12:52:25', 'abs_rana', '1');
INSERT INTO `holding_rate_sheet` (`hrid`, `holding_type`, `amount`, `up_date`, `ins_user`, `status`) VALUES ('3', 'পাকা বাড়ি', '1000.00', '2017-04-09 13:07:52', 'abs_rana', '1');


#
# TABLE STRUCTURE FOR: holding_ratesheet_history
#

DROP TABLE IF EXISTS `holding_ratesheet_history`;

CREATE TABLE `holding_ratesheet_history` (
  `hhid` int(11) NOT NULL AUTO_INCREMENT,
  `hrid` int(11) NOT NULL,
  `old_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `new_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ins_date` date NOT NULL,
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `up_user` varchar(60) NOT NULL,
  `status` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`hhid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `holding_ratesheet_history` (`hhid`, `hrid`, `old_amount`, `new_amount`, `ins_date`, `up_date`, `up_user`, `status`) VALUES ('1', '1', '575.00', '575.00', '2017-04-08', '2017-04-08 12:52:07', 'abs_rana', '1');
INSERT INTO `holding_ratesheet_history` (`hhid`, `hrid`, `old_amount`, `new_amount`, `ins_date`, `up_date`, `up_user`, `status`) VALUES ('2', '2', '375.00', '375.00', '2017-04-08', '2017-04-08 12:52:25', 'abs_rana', '1');
INSERT INTO `holding_ratesheet_history` (`hhid`, `hrid`, `old_amount`, `new_amount`, `ins_date`, `up_date`, `up_user`, `status`) VALUES ('3', '3', '1000.00', '1000.00', '2017-04-09', '2017-04-09 13:07:53', 'abs_rana', '1');


#
# TABLE STRUCTURE FOR: holdingclientinfo
#

DROP TABLE IF EXISTS `holdingclientinfo`;

CREATE TABLE `holdingclientinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `fathername` varchar(60) NOT NULL,
  `nid` varchar(20) NOT NULL COMMENT 'national id',
  `bid` varchar(20) NOT NULL COMMENT 'birth certificate id',
  `village` varchar(40) NOT NULL,
  `wordno` smallint(6) unsigned NOT NULL COMMENT 'word number',
  `holdingno` varchar(10) NOT NULL,
  `dagno` varchar(10) NOT NULL,
  `mobileno` varchar(11) NOT NULL,
  `pdate` date NOT NULL,
  `status` enum('1','2') NOT NULL DEFAULT '1',
  `update_by` varchar(40) NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `holdingclientinfo` (`id`, `name`, `fathername`, `nid`, `bid`, `village`, `wordno`, `holdingno`, `dagno`, `mobileno`, `pdate`, `status`, `update_by`, `utime`) VALUES ('1', 'মফিজুর রহমান', 'রহমান সাহেব', '124791284791234871', '234234523452345', 'মাতুয়াইল', '2', '2323', '1212', '01825292980', '2017-04-08', '1', 'abs_rana', '2017-04-08 16:32:49');
INSERT INTO `holdingclientinfo` (`id`, `name`, `fathername`, `nid`, `bid`, `village`, `wordno`, `holdingno`, `dagno`, `mobileno`, `pdate`, `status`, `update_by`, `utime`) VALUES ('2', 'খান সাহেব', 'মো: খান', '8698565', '23423465655', 'মাতুয়াইল', '7', '1515', '3312', '01825292980', '2017-04-08', '1', 'abs_rana', '2017-04-08 16:34:24');
INSERT INTO `holdingclientinfo` (`id`, `name`, `fathername`, `nid`, `bid`, `village`, `wordno`, `holdingno`, `dagno`, `mobileno`, `pdate`, `status`, `update_by`, `utime`) VALUES ('3', 'Rohim', 'Karim', '1298471984719284', '98749182472918', 'matuail', '7', '4578', '12365', '01825292980', '2017-04-09', '1', 'abs_rana', '2017-04-09 12:30:43');
INSERT INTO `holdingclientinfo` (`id`, `name`, `fathername`, `nid`, `bid`, `village`, `wordno`, `holdingno`, `dagno`, `mobileno`, `pdate`, `status`, `update_by`, `utime`) VALUES ('4', 'আকাশ', 'সাগর', '৫১৪৫৬৪৬৪৫৬৪৬৪৫', '৫৪৫৬৬৫৫৬৬৬৫', 'কুতুব', '1', '', '56', '০১৫১৫১৫১৫১১', '2017-04-14', '1', 'zia', '2017-04-14 18:07:04');


#
# TABLE STRUCTURE FOR: inbox
#

DROP TABLE IF EXISTS `inbox`;

CREATE TABLE `inbox` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trackid` varchar(8) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `msg` text NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO `inbox` (`id`, `trackid`, `mobile`, `msg`, `utime`) VALUES ('3', '958390', '01825292984', 'আপনার  ট্র্যাকিং নং : 958390 অনলাইনে ট্র্যাকিং নং টি দিয়ে  আপনার  আবেদনের অবস্থান যাছাই করুন', '2017-03-16 13:03:19');
INSERT INTO `inbox` (`id`, `trackid`, `mobile`, `msg`, `utime`) VALUES ('4', '323250', '01825292987', 'আপনার  ট্র্যাকিং নং : 323250 অনলাইনে ট্র্যাকিং নং টি দিয়ে  আপনার  আবেদনের অবস্থান যাছাই করুন', '2017-03-16 13:34:30');
INSERT INTO `inbox` (`id`, `trackid`, `mobile`, `msg`, `utime`) VALUES ('5', '916051', '01825292950', 'আপনার  ট্র্যাকিং নং : 916051 অনলাইনে ট্র্যাকিং নং টি দিয়ে  আপনার  আবেদনের অবস্থান যাছাই করুন', '2017-03-16 13:35:36');
INSERT INTO `inbox` (`id`, `trackid`, `mobile`, `msg`, `utime`) VALUES ('6', '171298', '01825292987', 'আপনার  ট্র্যাকিং নং : 171298 অনলাইনে ট্র্যাকিং নং টি দিয়ে  আপনার  আবেদনের অবস্থান যাছাই করুন', '2017-03-21 17:28:47');
INSERT INTO `inbox` (`id`, `trackid`, `mobile`, `msg`, `utime`) VALUES ('7', '836258', '01825292950', 'আপনার  ট্র্যাকিং নং : 836258 অনলাইনে ট্র্যাকিং নং টি দিয়ে  আপনার  আবেদনের অবস্থান যাছাই করুন', '2017-03-21 18:09:31');
INSERT INTO `inbox` (`id`, `trackid`, `mobile`, `msg`, `utime`) VALUES ('8', '546400', '01825292987', 'আপনার  ট্র্যাকিং নং : 546400 অনলাইনে ট্র্যাকিং নং টি দিয়ে  আপনার  আবেদনের অবস্থান যাছাই করুন', '2017-03-21 18:16:05');
INSERT INTO `inbox` (`id`, `trackid`, `mobile`, `msg`, `utime`) VALUES ('9', '596573', '01825292911', 'আপনার  ট্র্যাকিং নং : 596573 অনলাইনে ট্র্যাকিং নং টি দিয়ে  আপনার  আবেদনের অবস্থান যাছাই করুন', '2017-03-21 18:17:33');
INSERT INTO `inbox` (`id`, `trackid`, `mobile`, `msg`, `utime`) VALUES ('10', '629169', '01825292987', 'আপনার  ট্র্যাকিং নং : 629169 অনলাইনে ট্র্যাকিং নং টি দিয়ে  আপনার  আবেদনের অবস্থান যাছাই করুন', '2017-03-21 18:34:23');
INSERT INTO `inbox` (`id`, `trackid`, `mobile`, `msg`, `utime`) VALUES ('11', '898083', '01825292960', 'আপনার  ট্র্যাকিং নং : 898083 অনলাইনে ট্র্যাকিং নং টি দিয়ে  আপনার  আবেদনের অবস্থান যাছাই করুন', '2017-12-10 23:43:25');
INSERT INTO `inbox` (`id`, `trackid`, `mobile`, `msg`, `utime`) VALUES ('12', '767930', '01825292961', 'আপনার  ট্র্যাকিং নং : 767930 অনলাইনে ট্র্যাকিং নং টি দিয়ে  আপনার  আবেদনের অবস্থান যাছাই করুন', '2017-12-10 23:44:31');
INSERT INTO `inbox` (`id`, `trackid`, `mobile`, `msg`, `utime`) VALUES ('13', '860038', '01825292964', 'আপনার  ট্র্যাকিং নং : 860038 অনলাইনে ট্র্যাকিং নং টি দিয়ে  আপনার  আবেদনের অবস্থান যাছাই করুন', '2017-12-10 23:50:57');
INSERT INTO `inbox` (`id`, `trackid`, `mobile`, `msg`, `utime`) VALUES ('14', '083808', '01825292945', 'আপনার  ট্র্যাকিং নং : 083808 অনলাইনে ট্র্যাকিং নং টি দিয়ে  আপনার  আবেদনের অবস্থান যাছাই করুন', '2017-12-10 23:51:31');
INSERT INTO `inbox` (`id`, `trackid`, `mobile`, `msg`, `utime`) VALUES ('15', '842728', '01825292974', 'আপনার  ট্র্যাকিং নং : 842728 অনলাইনে ট্র্যাকিং নং টি দিয়ে  আপনার  আবেদনের অবস্থান যাছাই করুন', '2017-12-10 23:52:04');
INSERT INTO `inbox` (`id`, `trackid`, `mobile`, `msg`, `utime`) VALUES ('16', '142753', '01825292963', 'আপনার  ট্র্যাকিং নং : 142753 অনলাইনে ট্র্যাকিং নং টি দিয়ে  আপনার  আবেদনের অবস্থান যাছাই করুন', '2017-12-10 23:52:38');


#
# TABLE STRUCTURE FOR: ledger
#

DROP TABLE IF EXISTS `ledger`;

CREATE TABLE `ledger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` bigint(20) NOT NULL,
  `voucherno` bigint(20) NOT NULL,
  `vtype` enum('C','D') NOT NULL DEFAULT 'C',
  `catid` int(11) NOT NULL,
  `subid` int(11) NOT NULL,
  `fundtype` smallint(6) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `ac` varchar(255) NOT NULL,
  `dr` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cr` decimal(10,2) NOT NULL DEFAULT '0.00',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payment_date` date NOT NULL,
  `inby` varchar(40) NOT NULL,
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8;

INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('1', '1', '1', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '575.00', '575.00', '2017-03-15', 'abs_rana', '2017-03-15 15:36:59');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('2', '2', '2', 'C', '1', '4', '2', 'ব্যবসা,পেশা ও জীবিকার উপর কর', '0000-0000-0000-0000', '0.00', '1000.00', '1575.00', '2017-03-15', 'abs_rana', '2017-03-15 15:58:57');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('3', '3', '3', 'C', '1', '3', '2', 'বসতভিটার উপর কর', '0000-0000-0000-0000', '0.00', '1500.00', '3075.00', '2017-03-15', 'abs_rana', '2017-03-15 15:59:32');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('4', '4', '4', 'C', '6', '1', '2', 'নাগরিক সনদ', '0000-0000-0000-0000', '0.00', '100.00', '3175.00', '2017-03-15', 'abs_rana', '2017-03-15 16:00:57');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('5', '5', '5', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '2875.00', '6050.00', '2017-03-15', 'abs_rana', '2017-03-15 19:43:26');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('6', '6', '6', 'C', '1', '4', '2', 'ব্যবসা,পেশা ও জীবিকার উপর কর', '0000-0000-0000-0000', '0.00', '1000.00', '7050.00', '2017-03-15', 'abs_rana', '2017-03-15 19:49:15');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('7', '7', '7', 'C', '1', '3', '2', 'বসতভিটার উপর কর', '0000-0000-0000-0000', '0.00', '1500.00', '8550.00', '2017-03-15', 'abs_rana', '2017-03-15 19:49:31');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('8', '8', '8', 'C', '6', '1', '2', 'নাগরিক সনদ', '0000-0000-0000-0000', '0.00', '150.00', '8700.00', '2017-03-15', 'abs_rana', '2017-03-15 19:52:08');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('12', '9', '1', 'D', '0', '0', '0', 'Balance Transfer From', '0000-0000-0000-0000', '8000.00', '0.00', '700.00', '2017-03-15', 'abs_rana', '2017-03-15 21:14:20');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('13', '10', '9', 'C', '6', '1', '2', 'ওয়ারিশ সনদ', '0000-0000-0000-0000', '0.00', '0.00', '700.00', '2017-03-20', 'abs_rana', '2017-03-20 14:02:43');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('14', '11', '1', 'D', '0', '0', '0', 'Balance Transfer From', '0000-0000-0000-0000', '50.00', '0.00', '650.00', '2017-04-10', 'abs_rana', '2017-04-01 13:59:40');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('15', '12', '10', 'C', '1', '3', '2', 'বসতভিটার উপর কর', '0000-0000-0000-0000', '0.00', '500.00', '1150.00', '2017-04-08', 'abs_rana', '2017-04-08 16:32:49');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('16', '13', '11', 'C', '1', '3', '2', 'বসতভিটার উপর কর', '0000-0000-0000-0000', '0.00', '500.00', '1650.00', '2017-04-08', 'abs_rana', '2017-04-08 16:34:24');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('17', '14', '12', 'C', '1', '3', '2', 'বসতভিটার উপর কর', '0000-0000-0000-0000', '0.00', '500.00', '2150.00', '2017-04-09', 'abs_rana', '2017-04-09 12:30:43');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('18', '15', '13', 'C', '6', '1', '2', 'মৃত্যু সনদ', '0000-0000-0000-0000', '0.00', '0.00', '2150.00', '2017-04-12', 'abs_rana', '2017-04-12 21:07:24');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('19', '16', '14', 'C', '6', '1', '2', 'চারিত্রিক সনদ', '0000-0000-0000-0000', '0.00', '111.00', '2261.00', '2017-04-12', 'abs_rana', '2017-04-12 21:10:56');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('20', '17', '15', 'C', '6', '1', '2', 'চারিত্রিক সনদ', '0000-0000-0000-0000', '0.00', '111.00', '2372.00', '2017-04-12', 'abs_rana', '2017-04-12 21:10:56');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('21', '18', '16', 'C', '6', '1', '2', 'অনুমতি পত্র', '0000-0000-0000-0000', '0.00', '120.00', '2492.00', '2017-04-12', 'abs_rana', '2017-04-12 21:13:43');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('22', '19', '17', 'C', '6', '1', '2', 'চারিত্রিক সনদ', '0000-0000-0000-0000', '0.00', '120.00', '2612.00', '2017-04-13', 'abs_rana', '2017-04-13 13:42:52');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('23', '20', '18', 'C', '6', '1', '2', 'চারিত্রিক সনদ', '0000-0000-0000-0000', '0.00', '50.00', '2662.00', '2017-04-13', 'abs_rana', '2017-04-13 20:31:58');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('24', '21', '19', 'C', '6', '1', '2', 'মৃত্যু সনদ', '0000-0000-0000-0000', '0.00', '0.00', '2662.00', '2017-04-13', 'zia', '2017-04-13 22:20:02');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('25', '22', '20', 'C', '6', '1', '2', 'চারিত্রিক সনদ', '0000-0000-0000-0000', '0.00', '0.00', '2662.00', '2017-04-13', 'zia', '2017-04-13 22:23:20');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('26', '23', '21', 'C', '6', '1', '2', 'অবিবাহিত সনদ', '0000-0000-0000-0000', '0.00', '0.00', '2662.00', '2017-04-13', 'zia', '2017-04-13 22:28:17');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('27', '24', '22', 'C', '6', '1', '2', 'বার্ষিক আয়ের প্রত্যয়ন', '0000-0000-0000-0000', '0.00', '0.00', '2662.00', '2017-04-14', 'zia', '2017-04-14 14:34:56');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('28', '25', '23', 'C', '6', '1', '2', 'পুনঃ বিবাহ না হওয়া সনদ ', '0000-0000-0000-0000', '0.00', '0.00', '2662.00', '2017-04-14', 'zia', '2017-04-14 14:35:51');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('29', '26', '24', 'C', '6', '1', '2', 'ভূমিহীন সনদ', '0000-0000-0000-0000', '0.00', '0.00', '2662.00', '2017-04-14', 'zia', '2017-04-14 14:37:35');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('30', '27', '25', 'C', '6', '1', '2', 'একই নামের প্রত্যয়ন', '0000-0000-0000-0000', '0.00', '0.00', '2662.00', '2017-04-14', 'zia', '2017-04-14 15:24:43');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('31', '28', '26', 'C', '6', '1', '2', 'প্রকৃত বাকঁ ও শ্রবন প্রতিবন্ধী', '0000-0000-0000-0000', '0.00', '0.00', '2662.00', '2017-04-14', 'zia', '2017-04-14 15:28:15');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('32', '29', '27', 'C', '6', '1', '2', 'সনাতন ধর্ম  অবলম্বী', '0000-0000-0000-0000', '0.00', '0.00', '2662.00', '2017-04-14', 'zia', '2017-04-14 15:31:10');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('33', '30', '28', 'C', '6', '1', '2', 'অনুমতি পত্র', '0000-0000-0000-0000', '0.00', '0.00', '2662.00', '2017-04-14', 'zia', '2017-04-14 15:34:18');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('34', '31', '29', 'C', '6', '1', '2', 'অনুমতি পত্র', '0000-0000-0000-0000', '0.00', '0.00', '2662.00', '2017-04-14', 'zia', '2017-04-14 15:35:23');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('35', '32', '30', 'C', '6', '1', '2', 'প্রত্যয়ন পত্র', '0000-0000-0000-0000', '0.00', '0.00', '2662.00', '2017-04-14', 'zia', '2017-04-14 15:38:54');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('36', '33', '31', 'C', '6', '1', '2', 'অনুমতি পত্র', '0000-0000-0000-0000', '0.00', '0.00', '2662.00', '2017-04-14', 'zia', '2017-04-14 15:40:42');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('37', '34', '32', 'C', '6', '1', '2', 'নাগরিক সনদ', '0000-0000-0000-0000', '0.00', '0.00', '2662.00', '2017-04-14', 'zia', '2017-04-14 18:02:36');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('38', '35', '33', 'C', '1', '3', '2', 'বসতভিটার উপর কর', '0000-0000-0000-0000', '0.00', '300.00', '2962.00', '2017-04-14', 'zia', '2017-04-14 18:07:04');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('41', '36', '34', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '294.50', '3256.50', '2017-04-14', 'zia', '2017-04-14 18:14:15');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('42', '37', '35', 'C', '6', '1', '2', 'নাগরিক সনদ', '0000-0000-0000-0000', '0.00', '0.00', '3256.50', '2017-04-14', 'abs_rana', '2017-04-14 21:19:33');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('43', '38', '36', 'C', '14', '22', '10', 'অবিবাহিত সনদ', '0000-0000-0000-0000', '0.00', '500.00', '3756.50', '2017-04-18', 'abs_rana', '2017-04-18 18:29:26');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('44', '39', '37', 'C', '14', '22', '10', 'মৃত্যু সনদ', '0000-0000-0000-0000', '0.00', '0.00', '3756.50', '2017-05-01', 'abs_rana', '2017-05-01 01:45:08');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('45', '40', '2', 'D', '0', '0', '0', 'Balance Transfer From', '0000-0000-0000-0000', '100.00', '0.00', '3656.50', '2017-05-06', 'abs_rana', '2017-05-06 17:44:01');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('46', '41', '38', 'C', '1', '4', '2', 'ব্যবসা,পেশা ও জীবিকার উপর কর', '0000-0000-0000-0000', '0.00', '34.00', '3690.50', '2017-06-08', 'abs_rana', '2017-06-08 17:06:16');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('47', '42', '39', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '6050.00', '9740.50', '2017-12-02', 'abs_rana', '2017-12-02 16:11:59');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('48', '43', '40', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '230.00', '9970.50', '2017-12-10', 'abs_rana', '2017-12-10 22:53:21');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('49', '44', '41', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '230.00', '10200.50', '2017-12-10', 'abs_rana', '2017-12-10 22:55:37');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('54', '45', '42', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '345.00', '10545.50', '2017-12-10', 'abs_rana', '2017-12-10 22:59:01');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('59', '46', '43', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '2300.00', '12845.50', '2017-12-10', 'abs_rana', '2017-12-10 23:02:27');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('65', '47', '44', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '138.00', '12983.50', '2017-12-10', 'abs_rana', '2017-12-10 23:13:04');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('66', '48', '45', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '1380.00', '14363.50', '2017-12-10', 'abs_rana', '2017-12-10 23:15:26');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('67', '49', '46', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '1380.00', '15743.50', '2017-12-10', 'abs_rana', '2017-12-10 23:15:27');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('68', '50', '47', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '575.00', '16318.50', '2017-12-10', 'abs_rana', '2017-12-10 23:17:48');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('69', '51', '48', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '690.00', '17008.50', '2017-12-10', 'abs_rana', '2017-12-10 23:19:48');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('70', '52', '49', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '460.00', '17468.50', '2017-12-10', 'abs_rana', '2017-12-10 23:24:38');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('71', '53', '50', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '530.70', '17999.20', '2017-12-10', 'abs_rana', '2017-12-10 23:26:41');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('72', '54', '51', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '34.50', '18033.70', '2017-12-10', 'abs_rana', '2017-12-10 23:28:29');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('73', '55', '52', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '345.00', '18378.70', '2017-12-10', 'abs_rana', '2017-12-10 23:34:19');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('74', '56', '53', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '368.00', '18746.70', '2017-12-10', 'abs_rana', '2017-12-10 23:45:01');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('75', '57', '54', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '115.00', '18861.70', '2017-12-10', 'abs_rana', '2017-12-10 23:46:37');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('76', '58', '55', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '138.00', '18999.70', '2017-12-10', 'abs_rana', '2017-12-10 23:49:31');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('79', '59', '56', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '264.50', '19264.20', '2017-12-10', 'abs_rana', '2017-12-10 23:54:33');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('83', '60', '57', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '264.50', '19528.70', '2017-12-10', 'abs_rana', '2017-12-10 23:56:58');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('84', '61', '58', 'C', '3', '2', '2', 'ট্রেড লাইসেন্স ফি', '0000-0000-0000-0000', '0.00', '264.50', '19793.20', '2017-12-10', 'abs_rana', '2017-12-10 23:57:00');
INSERT INTO `ledger` (`id`, `tid`, `voucherno`, `vtype`, `catid`, `subid`, `fundtype`, `purpose`, `ac`, `dr`, `cr`, `balance`, `payment_date`, `inby`, `up_date`) VALUES ('85', '62', '59', 'C', '6', '1', '2', 'নাগরিক সনদ', '0000-0000-0000-0000', '0.00', '0.00', '19793.20', '2018-01-22', 'abs_rana', '2018-01-22 13:08:19');


#
# TABLE STRUCTURE FOR: license_hostory
#

DROP TABLE IF EXISTS `license_hostory`;

CREATE TABLE `license_hostory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sno` varchar(17) NOT NULL,
  `issue_date` date NOT NULL,
  `expire_date` date NOT NULL,
  `status` enum('1','2') NOT NULL,
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('1', '20171234567845739', '2017-03-15', '2017-06-30', '1', '2017-03-15 15:36:59');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('2', '20171234567858453', '2017-03-15', '2017-06-30', '1', '2017-03-15 19:43:25');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('5', '20176112385094942', '2017-04-14', '2017-06-30', '1', '2017-04-14 18:14:15');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('6', '20176112385504207', '2017-12-02', '2018-06-30', '1', '2017-12-02 16:11:59');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('7', '20176112385389921', '2017-12-10', '2018-06-30', '1', '2017-12-10 22:53:21');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('8', '20176112385105329', '2017-12-10', '2018-06-30', '1', '2017-12-10 22:55:37');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('13', '20176112385375872', '2017-12-10', '2018-06-30', '1', '2017-12-10 22:59:01');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('18', '20176112385578164', '2017-12-10', '2018-06-30', '1', '2017-12-10 23:02:27');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('24', '20176112385802527', '2017-12-10', '2018-06-30', '1', '2017-12-10 23:13:04');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('25', '20176112385758413', '2017-12-10', '2018-06-30', '1', '2017-12-10 23:15:26');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('26', '20176112385235576', '2017-12-10', '2018-06-30', '1', '2017-12-10 23:15:27');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('27', '20176112385884697', '2017-12-10', '2018-06-30', '1', '2017-12-10 23:17:47');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('28', '20176112385197104', '2017-12-10', '2018-06-30', '1', '2017-12-10 23:19:48');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('29', '20176112385476269', '2017-12-10', '2018-06-30', '1', '2017-12-10 23:24:38');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('30', '20176112385924711', '2017-12-10', '2018-06-30', '1', '2017-12-10 23:26:41');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('31', '20176112385257814', '2017-12-10', '2018-06-30', '1', '2017-12-10 23:28:29');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('32', '20176112385816403', '2017-12-10', '2018-06-30', '1', '2017-12-10 23:34:19');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('33', '20176112385272992', '2017-12-10', '2018-06-30', '1', '2017-12-10 23:45:01');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('34', '20176112385619127', '2017-12-10', '2018-06-30', '1', '2017-12-10 23:46:37');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('35', '20176112385247095', '2017-12-10', '2018-06-30', '1', '2017-12-10 23:49:31');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('38', '20176112385062039', '2017-12-10', '2018-06-30', '1', '2017-12-10 23:54:33');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('42', '20176112385678418', '2017-12-10', '2018-06-30', '1', '2017-12-10 23:56:58');
INSERT INTO `license_hostory` (`id`, `sno`, `issue_date`, `expire_date`, `status`, `up_date`) VALUES ('43', '20176112385285843', '2017-12-10', '2018-06-30', '1', '2017-12-10 23:57:00');


#
# TABLE STRUCTURE FOR: license_notification
#

DROP TABLE IF EXISTS `license_notification`;

CREATE TABLE `license_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notifydate` date NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mainctg
#

DROP TABLE IF EXISTS `mainctg`;

CREATE TABLE `mainctg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fund_id` int(11) NOT NULL COMMENT '1=development, 2= personal',
  `category` varchar(255) NOT NULL,
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `insert_by` varchar(40) NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO `mainctg` (`id`, `fund_id`, `category`, `balance`, `insert_by`, `utime`) VALUES ('1', '2', 'কর ও রেট', '6834.00', 'abs_rana', '2017-06-08 17:06:16');
INSERT INTO `mainctg` (`id`, `fund_id`, `category`, `balance`, `insert_by`, `utime`) VALUES ('2', '1', 'ইজারা', '0.00', 'abs_rana', '2016-11-29 19:00:14');
INSERT INTO `mainctg` (`id`, `fund_id`, `category`, `balance`, `insert_by`, `utime`) VALUES ('3', '2', 'লাইসেন্স ফি', '19847.20', 'abs_rana', '2017-12-10 23:57:00');
INSERT INTO `mainctg` (`id`, `fund_id`, `category`, `balance`, `insert_by`, `utime`) VALUES ('4', '2', 'যানবাহন (মটরযান ব্যতীত)', '0.00', 'abs_rana', '2016-11-29 19:00:26');
INSERT INTO `mainctg` (`id`, `fund_id`, `category`, `balance`, `insert_by`, `utime`) VALUES ('5', '1', 'বিনিযোগের আয়', '0.00', 'abs_rana', '2016-11-27 13:14:34');
INSERT INTO `mainctg` (`id`, `fund_id`, `category`, `balance`, `insert_by`, `utime`) VALUES ('6', '2', 'জন্ম নিবন্ধন ফি', '762.00', 'abs_rana', '2017-04-13 20:31:58');
INSERT INTO `mainctg` (`id`, `fund_id`, `category`, `balance`, `insert_by`, `utime`) VALUES ('7', '1', 'সরকারী অনুদান-ভূমি হস্তান্তর কর (১%)', '0.00', 'abs_rana', '2016-11-27 13:20:48');
INSERT INTO `mainctg` (`id`, `fund_id`, `category`, `balance`, `insert_by`, `utime`) VALUES ('8', '1', 'সরকরী অনুদান-সংস্থাপন', '0.00', 'abs_rana', '2016-11-27 13:20:48');
INSERT INTO `mainctg` (`id`, `fund_id`, `category`, `balance`, `insert_by`, `utime`) VALUES ('9', '1', 'সরকরী অনুদান-উন্নয়ন', '0.00', 'abs_rana', '2016-11-27 13:20:48');
INSERT INTO `mainctg` (`id`, `fund_id`, `category`, `balance`, `insert_by`, `utime`) VALUES ('10', '1', 'স্থানীয় সরকার-জেলা পরিষদ অনুদান', '0.00', 'abs_rana', '2016-11-27 13:20:48');
INSERT INTO `mainctg` (`id`, `fund_id`, `category`, `balance`, `insert_by`, `utime`) VALUES ('11', '1', 'স্থানীয় সরকার-উপজেলা পরিষদ অনুদান', '0.00', 'abs_rana', '2016-11-27 13:24:26');
INSERT INTO `mainctg` (`id`, `fund_id`, `category`, `balance`, `insert_by`, `utime`) VALUES ('12', '1', 'এলজিএসপি ফান্ড ফেরত', '0.00', 'abs_rana', '2016-11-27 13:24:26');
INSERT INTO `mainctg` (`id`, `fund_id`, `category`, `balance`, `insert_by`, `utime`) VALUES ('13', '2', 'অন্যান্য প্রাপ্তি', '0.00', 'abs_rana', '2016-11-29 19:00:39');
INSERT INTO `mainctg` (`id`, `fund_id`, `category`, `balance`, `insert_by`, `utime`) VALUES ('14', '10', 'UDC fund', '500.00', 'abs_rana', '2017-04-18 18:31:12');


#
# TABLE STRUCTURE FOR: mainctg_in_budget
#

DROP TABLE IF EXISTS `mainctg_in_budget`;

CREATE TABLE `mainctg_in_budget` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL,
  `actual_budget` decimal(10,2) NOT NULL,
  `budget_year` varchar(50) NOT NULL,
  `status` enum('1','2') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mamla_badi
#

DROP TABLE IF EXISTS `mamla_badi`;

CREATE TABLE `mamla_badi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mamla_id` int(11) NOT NULL,
  `badi_name` varchar(60) NOT NULL,
  `badi_father_name` varchar(60) NOT NULL,
  `gram` varchar(120) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `mamla_badi` (`id`, `mamla_id`, `badi_name`, `badi_father_name`, `gram`, `status`) VALUES ('1', '1', 'রানাh', 'মুমনh', '', '1');
INSERT INTO `mamla_badi` (`id`, `mamla_id`, `badi_name`, `badi_father_name`, `gram`, `status`) VALUES ('2', '1', 'koly', 'MOMIN', '', '1');
INSERT INTO `mamla_badi` (`id`, `mamla_id`, `badi_name`, `badi_father_name`, `gram`, `status`) VALUES ('3', '1', 'poly', 'momin', '', '1');


#
# TABLE STRUCTURE FOR: mamla_bibadi
#

DROP TABLE IF EXISTS `mamla_bibadi`;

CREATE TABLE `mamla_bibadi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mamla_id` int(11) NOT NULL,
  `bibadi_name` varchar(60) NOT NULL,
  `bibadi_father_name` varchar(60) NOT NULL,
  `gram` varchar(120) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `mamla_bibadi` (`id`, `mamla_id`, `bibadi_name`, `bibadi_father_name`, `gram`, `status`) VALUES ('1', '1', 'তাহের', 'মম', '', '1');
INSERT INTO `mamla_bibadi` (`id`, `mamla_id`, `bibadi_name`, `bibadi_father_name`, `gram`, `status`) VALUES ('2', '1', 'ওসামান', 'তাহের', '', '1');
INSERT INTO `mamla_bibadi` (`id`, `mamla_id`, `bibadi_name`, `bibadi_father_name`, `gram`, `status`) VALUES ('3', '1', 'সৈকতh', 'তাহেরh', '', '1');


#
# TABLE STRUCTURE FOR: mamla_tbl
#

DROP TABLE IF EXISTS `mamla_tbl`;

CREATE TABLE `mamla_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mamla_no` int(11) NOT NULL,
  `mamla_sonod` varchar(20) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `mamla_date` date NOT NULL,
  `sunani_date` date NOT NULL,
  `badi_gram` varchar(120) NOT NULL,
  `bibadi_gram` varchar(120) NOT NULL,
  `status` enum('1','2','3') NOT NULL,
  `comments` text NOT NULL,
  `ins_user` varchar(40) NOT NULL,
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `mamla_tbl` (`id`, `mamla_no`, `mamla_sonod`, `subject`, `mamla_date`, `sunani_date`, `badi_gram`, `bibadi_gram`, `status`, `comments`, `ins_user`, `up_date`) VALUES ('1', '1', '20176112385072655', 'বিয়ে সংক্রান্ত hh', '2017-05-31', '2017-05-31', 'জায়লস্কর', 'hhhhhhh', '3', 'success', 'abs_rana', '2017-05-16 19:48:03');


#
# TABLE STRUCTURE FOR: money
#

DROP TABLE IF EXISTS `money`;

CREATE TABLE `money` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trackid` varchar(17) NOT NULL,
  `bno` int(11) NOT NULL,
  `inno` int(11) NOT NULL,
  `fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `due` decimal(10,2) NOT NULL DEFAULT '0.00',
  `scharge` decimal(10,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vat` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payment_date` date NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1=tradelicense,2=tradeBosotbitaKor, 3= tradepesKor, 4=dagBosotKor, 5=nagorick, 6= warish, 7= dailycollection, 8=dailyexpensive',
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;

INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('1', '425464', '2', '1', '500.00', '0.00', '0.00', '0.00', '75.00', '575.00', '2017-03-15', '1', '2017-03-15 15:36:59');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('2', '425464', '0', '2', '1000.00', '0.00', '0.00', '0.00', '0.00', '1000.00', '2017-03-15', '3', '2017-03-15 15:58:57');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('3', '425464', '0', '3', '1500.00', '0.00', '0.00', '0.00', '0.00', '1500.00', '2017-03-15', '2', '2017-03-15 15:59:32');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('4', '113917', '0', '4', '100.00', '0.00', '0.00', '0.00', '0.00', '100.00', '2017-03-15', '5', '2017-03-15 16:00:57');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('5', '486068', '3', '5', '2500.00', '0.00', '0.00', '0.00', '375.00', '2875.00', '2017-03-15', '1', '2017-03-15 19:43:26');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('6', '486068', '0', '6', '1000.00', '0.00', '0.00', '0.00', '0.00', '1000.00', '2017-03-15', '3', '2017-03-15 19:49:15');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('7', '486068', '0', '7', '1500.00', '0.00', '0.00', '0.00', '0.00', '1500.00', '2017-03-15', '2', '2017-03-15 19:49:31');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('8', '933846', '0', '8', '150.00', '0.00', '0.00', '0.00', '0.00', '150.00', '2017-03-15', '5', '2017-03-15 19:52:08');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('9', '774205', '0', '9', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-03-20', '6', '2017-03-20 14:02:43');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('10', '1212', '0', '10', '500.00', '0.00', '0.00', '0.00', '0.00', '500.00', '2017-04-08', '4', '2017-04-08 16:32:49');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('11', '3312', '0', '11', '500.00', '0.00', '0.00', '0.00', '0.00', '500.00', '2017-04-08', '4', '2017-04-08 16:34:24');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('12', '12365', '0', '12', '500.00', '0.00', '0.00', '0.00', '0.00', '500.00', '2017-04-09', '4', '2017-04-09 12:30:43');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('13', '482712', '0', '13', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-04-12', '5', '2017-04-12 21:07:24');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('14', '380966', '0', '14', '111.00', '0.00', '0.00', '0.00', '0.00', '111.00', '2017-04-12', '5', '2017-04-12 21:10:56');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('15', '380966', '0', '15', '111.00', '0.00', '0.00', '0.00', '0.00', '111.00', '2017-04-12', '5', '2017-04-12 21:10:56');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('16', '752086', '0', '16', '120.00', '0.00', '0.00', '0.00', '0.00', '120.00', '2017-04-12', '5', '2017-04-12 21:13:43');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('17', '924576', '0', '17', '120.00', '0.00', '0.00', '0.00', '0.00', '120.00', '2017-04-13', '5', '2017-04-13 13:42:52');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('18', '099405', '0', '18', '50.00', '0.00', '0.00', '0.00', '0.00', '50.00', '2017-04-13', '5', '2017-04-13 20:31:58');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('19', '611092', '0', '19', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-04-13', '5', '2017-04-13 22:20:02');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('20', '451431', '0', '20', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-04-13', '5', '2017-04-13 22:23:20');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('21', '964360', '0', '21', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-04-13', '5', '2017-04-13 22:28:17');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('22', '878895', '0', '22', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-04-14', '5', '2017-04-14 14:34:56');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('23', '088711', '0', '23', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-04-14', '5', '2017-04-14 14:35:51');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('24', '279293', '0', '24', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-04-14', '5', '2017-04-14 14:37:35');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('25', '102755', '0', '25', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-04-14', '5', '2017-04-14 15:24:43');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('26', '521140', '0', '26', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-04-14', '5', '2017-04-14 15:28:15');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('27', '781763', '0', '27', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-04-14', '5', '2017-04-14 15:31:10');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('28', '601895', '0', '28', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-04-14', '5', '2017-04-14 15:34:18');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('30', '601895', '0', '29', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-04-14', '5', '2017-04-14 15:35:23');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('31', '890857', '0', '30', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-04-14', '5', '2017-04-14 15:38:54');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('32', '084345', '0', '31', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-04-14', '5', '2017-04-14 15:40:42');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('33', '167991', '0', '32', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-04-14', '5', '2017-04-14 18:02:36');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('34', '56', '0', '33', '300.00', '0.00', '0.00', '0.00', '0.00', '300.00', '2017-04-14', '4', '2017-04-14 18:07:04');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('37', '043852', '4', '34', '200.00', '30.00', '30.00', '0.00', '34.50', '294.50', '2017-04-14', '1', '2017-04-14 18:14:15');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('38', '831143', '0', '35', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-04-14', '5', '2017-04-14 21:19:33');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('39', '071256', '0', '36', '500.00', '0.00', '0.00', '0.00', '0.00', '500.00', '2017-04-18', '5', '2017-04-18 18:29:26');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('40', '968655', '0', '37', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2017-05-01', '5', '2017-05-01 01:45:07');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('41', '043852', '0', '38', '34.00', '0.00', '0.00', '0.00', '0.00', '34.00', '2017-06-08', '3', '2017-06-08 17:06:16');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('42', '171298', '5', '39', '5000.00', '0.00', '300.00', '0.00', '750.00', '6050.00', '2017-12-02', '1', '2017-12-02 16:11:59');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('43', '323250', '6', '40', '200.00', '0.00', '0.00', '0.00', '30.00', '230.00', '2017-12-10', '1', '2017-12-10 22:53:21');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('44', '958390', '7', '41', '200.00', '0.00', '0.00', '0.00', '30.00', '230.00', '2017-12-10', '1', '2017-12-10 22:55:37');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('49', '126339', '13', '42', '300.00', '0.00', '0.00', '0.00', '45.00', '345.00', '2017-12-10', '1', '2017-12-10 22:59:01');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('54', '211830', '14', '43', '2000.00', '0.00', '0.00', '0.00', '300.00', '2300.00', '2017-12-10', '1', '2017-12-10 23:02:27');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('60', '625696', '15', '44', '120.00', '0.00', '0.00', '0.00', '18.00', '138.00', '2017-12-10', '1', '2017-12-10 23:13:04');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('61', '812617', '16', '45', '1200.00', '0.00', '0.00', '0.00', '180.00', '1380.00', '2017-12-10', '1', '2017-12-10 23:15:26');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('62', '812617', '16', '46', '1200.00', '0.00', '0.00', '0.00', '180.00', '1380.00', '2017-12-10', '1', '2017-12-10 23:15:27');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('63', '780019', '17', '47', '500.00', '0.00', '0.00', '0.00', '75.00', '575.00', '2017-12-10', '1', '2017-12-10 23:17:48');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('64', '564239', '18', '48', '600.00', '0.00', '0.00', '0.00', '90.00', '690.00', '2017-12-10', '1', '2017-12-10 23:19:48');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('65', '371734', '18', '49', '200.00', '200.00', '0.00', '0.00', '60.00', '460.00', '2017-12-10', '1', '2017-12-10 23:24:38');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('66', '580293', '19', '50', '454.00', '4.00', '4.00', '0.00', '68.70', '530.70', '2017-12-10', '1', '2017-12-10 23:26:41');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('67', '324714', '19', '51', '30.00', '0.00', '0.00', '0.00', '4.50', '34.50', '2017-12-10', '1', '2017-12-10 23:28:29');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('68', '942343', '19', '52', '300.00', '0.00', '0.00', '0.00', '45.00', '345.00', '2017-12-10', '1', '2017-12-10 23:34:19');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('69', '767930', '19', '53', '320.00', '0.00', '0.00', '0.00', '48.00', '368.00', '2017-12-10', '1', '2017-12-10 23:45:01');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('70', '898083', '20', '54', '100.00', '0.00', '0.00', '0.00', '15.00', '115.00', '2017-12-10', '1', '2017-12-10 23:46:37');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('71', '192690', '20', '55', '120.00', '0.00', '0.00', '0.00', '18.00', '138.00', '2017-12-10', '1', '2017-12-10 23:49:31');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('74', '142753', '20', '56', '230.00', '0.00', '0.00', '0.00', '34.50', '264.50', '2017-12-10', '1', '2017-12-10 23:54:33');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('78', '842728', '21', '57', '230.00', '0.00', '0.00', '0.00', '34.50', '264.50', '2017-12-10', '1', '2017-12-10 23:56:58');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('79', '842728', '21', '58', '230.00', '0.00', '0.00', '0.00', '34.50', '264.50', '2017-12-10', '1', '2017-12-10 23:57:00');
INSERT INTO `money` (`id`, `trackid`, `bno`, `inno`, `fee`, `due`, `scharge`, `discount`, `vat`, `total`, `payment_date`, `status`, `utime`) VALUES ('80', '161129', '0', '59', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2018-01-22', '5', '2018-01-22 13:08:19');


#
# TABLE STRUCTURE FOR: onnanoseba
#

DROP TABLE IF EXISTS `onnanoseba`;

CREATE TABLE `onnanoseba` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trackid` varchar(8) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `trno` bigint(20) NOT NULL,
  `vno` bigint(20) NOT NULL,
  `acno` varchar(255) NOT NULL,
  `fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payment_date` date NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO `onnanoseba` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('1', '099405', '1', '20', '18', '0000-0000-0000-0000', '50.00', '2017-04-13', '2017-04-13 20:31:58');
INSERT INTO `onnanoseba` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('2', '611092', '2', '21', '19', '0000-0000-0000-0000', '0.00', '2017-04-13', '2017-04-13 22:20:02');
INSERT INTO `onnanoseba` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('3', '451431', '3', '22', '20', '0000-0000-0000-0000', '0.00', '2017-04-13', '2017-04-13 22:23:20');
INSERT INTO `onnanoseba` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('4', '964360', '4', '23', '21', '0000-0000-0000-0000', '0.00', '2017-04-13', '2017-04-13 22:28:17');
INSERT INTO `onnanoseba` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('5', '878895', '5', '24', '22', '0000-0000-0000-0000', '0.00', '2017-04-14', '2017-04-14 14:34:56');
INSERT INTO `onnanoseba` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('6', '088711', '6', '25', '23', '0000-0000-0000-0000', '0.00', '2017-04-14', '2017-04-14 14:35:51');
INSERT INTO `onnanoseba` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('7', '279293', '7', '26', '24', '0000-0000-0000-0000', '0.00', '2017-04-14', '2017-04-14 14:37:35');
INSERT INTO `onnanoseba` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('8', '102755', '8', '27', '25', '0000-0000-0000-0000', '0.00', '2017-04-14', '2017-04-14 15:24:43');
INSERT INTO `onnanoseba` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('9', '521140', '9', '28', '26', '0000-0000-0000-0000', '0.00', '2017-04-14', '2017-04-14 15:28:15');
INSERT INTO `onnanoseba` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('10', '781763', '10', '29', '27', '0000-0000-0000-0000', '0.00', '2017-04-14', '2017-04-14 15:31:10');
INSERT INTO `onnanoseba` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('11', '601895', '11', '30', '28', '0000-0000-0000-0000', '0.00', '2017-04-14', '2017-04-14 15:34:18');
INSERT INTO `onnanoseba` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('13', '601895', '12', '31', '29', '0000-0000-0000-0000', '0.00', '2017-04-14', '2017-04-14 15:35:23');
INSERT INTO `onnanoseba` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('14', '890857', '13', '32', '30', '0000-0000-0000-0000', '0.00', '2017-04-14', '2017-04-14 15:38:54');
INSERT INTO `onnanoseba` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('15', '084345', '14', '33', '31', '0000-0000-0000-0000', '0.00', '2017-04-14', '2017-04-14 15:40:42');
INSERT INTO `onnanoseba` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('16', '071256', '15', '38', '36', '0000-0000-0000-0000', '500.00', '2017-04-18', '2017-04-18 18:29:26');
INSERT INTO `onnanoseba` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('17', '968655', '16', '39', '37', '0000-0000-0000-0000', '0.00', '2017-05-01', '2017-05-01 01:45:07');


#
# TABLE STRUCTURE FOR: otherserviceinfo
#

DROP TABLE IF EXISTS `otherserviceinfo`;

CREATE TABLE `otherserviceinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trackid` varchar(8) NOT NULL,
  `sonodno` varchar(17) DEFAULT NULL,
  `delivery_type` tinyint(3) NOT NULL,
  `serviceId` tinyint(3) NOT NULL,
  `mukti_name` varchar(60) NOT NULL,
  `gejet_no` varchar(15) NOT NULL,
  `m_sonshod_sonod` varchar(20) NOT NULL,
  `relation` varchar(60) NOT NULL,
  `short_rel` varchar(30) NOT NULL,
  `sector_no` varchar(10) NOT NULL,
  `mukti_sonod` varchar(20) NOT NULL,
  `incomeAmount` varchar(20) DEFAULT NULL,
  `publishName` varchar(60) DEFAULT NULL,
  `workPlace` varchar(100) DEFAULT NULL,
  `ddfb` date NOT NULL,
  `nationid` varchar(20) DEFAULT NULL,
  `bcno` varchar(20) DEFAULT NULL,
  `pno` varchar(20) DEFAULT NULL,
  `dofb` date NOT NULL,
  `ename` varchar(60) NOT NULL,
  `name` varchar(80) NOT NULL,
  `gender` enum('male','female','others') NOT NULL,
  `mstatus` tinyint(2) NOT NULL,
  `ewname` varchar(60) DEFAULT NULL,
  `bwname` varchar(80) DEFAULT NULL,
  `ehname` varchar(60) DEFAULT NULL,
  `bhname` varchar(80) DEFAULT NULL,
  `efname` varchar(60) NOT NULL,
  `bfname` varchar(80) NOT NULL,
  `emname` varchar(60) NOT NULL,
  `mname` varchar(80) NOT NULL,
  `ocupt` varchar(120) DEFAULT NULL,
  `edustatus` varchar(120) DEFAULT NULL,
  `religion` varchar(30) NOT NULL,
  `bashinda` enum('1','2') NOT NULL,
  `p_gram` varchar(60) DEFAULT NULL,
  `pb_gram` varchar(100) DEFAULT NULL,
  `p_rbs` varchar(60) DEFAULT NULL,
  `pb_rbs` varchar(80) DEFAULT NULL,
  `p_wordno` int(4) DEFAULT NULL,
  `pb_wordno` varchar(10) DEFAULT NULL,
  `p_dis` varchar(60) DEFAULT NULL,
  `pb_dis` varchar(100) DEFAULT NULL,
  `p_thana` varchar(60) DEFAULT NULL,
  `pb_thana` varchar(100) DEFAULT NULL,
  `p_postof` varchar(60) DEFAULT NULL,
  `pb_postof` varchar(100) DEFAULT NULL,
  `per_gram` varchar(60) DEFAULT NULL,
  `perb_gram` varchar(100) DEFAULT NULL,
  `per_rbs` varchar(60) DEFAULT NULL,
  `perb_rbs` varchar(80) DEFAULT NULL,
  `per_wordno` int(4) DEFAULT NULL,
  `perb_wordno` varchar(10) DEFAULT NULL,
  `per_dis` varchar(60) DEFAULT NULL,
  `perb_dis` varchar(100) DEFAULT NULL,
  `per_thana` varchar(60) DEFAULT NULL,
  `perb_thana` varchar(100) DEFAULT NULL,
  `per_postof` varchar(60) DEFAULT NULL,
  `perb_postof` varchar(100) DEFAULT NULL,
  `mobile` varchar(11) NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `attachment` text,
  `profile` varchar(160) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `insert_time` date NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('1', '099405', '20176112385783181', '3', '2', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2016-12-05', 'rana', 'রানা', 'male', '2', '', '', '', '', 'Momin', 'মমিন', 'ff', 'কক', 'asdf', 'asdf', 'ইসলাম', '2', 'asdf', 'adsf', '3', '3', '3', '3', 'a', 'a', 'adsf', 'a', 'a', 'a', 'asdf', 'adsf', '3', '3', '3', '3', 'a', 'a', 'adsf', 'a', 'a', 'a', '01825689784', 'rana.feni.fci@gmail.com', '', 'http://application.smartup.com.bd/img/default/profile.png', '1', '2017-04-13', '2017-04-13 20:31:58');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('2', '611092', '20176112385478623', '3', '1', '', '', '', '', '', '', '', '2000', 'আবুল', 'বাংলাদেশ পুলিশ বাহিনিতে ', '2017-04-12', '44444444444444444', '11111111111111111', '22222222222222', '2017-04-04', 'abol', 'আবুল', 'male', '2', '', '', '', '', 'hbhfd', 'রেরেরে', 'cvcv', 'চচচচচ', '', '', 'ইসলাম', '2', '', 'গোহালাকান্দা', '', '', '0', '০৭', '', 'ময়মনসিংহ', '', 'গৌরীপুর', '', 'সানুড়া', '', 'গোহালাকান্দা', '', '', '0', '০৭', '', 'ময়মনসিংহ', '', 'গৌরীপুর', '', 'সানুড়া', '01919808720', '', '', 'http://application.smartup.com.bd//library/profile/14921001901413394738.jpg', '1', '2017-04-13', '2017-04-13 22:20:02');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('3', '451431', '20176112385499368', '3', '2', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-04-25', 'dfdssdv', 'ুািউািনবকন', 'male', '2', '', '', '', '', 'jlkj', 'kjklj', 'jj;jkj', 'kjklj', '', 'jj;l', 'ইসলাম', '2', '', 'gfhfgh', '', 'fghf', '0', '6', '', 'fgh', '', 'fgh', '', 'fgh', '', 'gfhfgh', '', 'fghf', '0', '6', '', 'fgh', '', 'fgh', '', 'fgh', '01965656565', '', '', 'http://application.smartup.com.bd/img/default/profile.png', '1', '2017-04-13', '2017-04-13 22:23:20');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('4', '964360', '20176112385745799', '3', '3', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-04-26', 'dfgdfg', 'dfgfdg', 'male', '2', '', '', '', '', 'dfgdfg', 'dfgdf', 'dfgdfg', 'dfgdfg', '', '', 'ইসলাম', '2', '', 'dfgfd', '', 'dfg', '0', 'dfg', '', 'dfgfd', '', 'fdgdf', '', 'dfg', '', 'dfgfd', '', 'dfg', '0', 'dfg', '', 'dfgfd', '', 'fdgdf', '', 'dfg', '01965656565', '', '', 'http://application.smartup.com.bd/img/default/profile.png', '1', '2017-04-13', '2017-04-13 22:28:17');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('5', '279293', '20176112385939272', '3', '4', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-03-13', 'kljlkh', 'sdfsd', 'female', '2', '', '', '', '', 'sdfdsf', 'sdfsd', 'sdfsdf', 'sdfsd', 'sdfsdf', 'sdf', 'ইসলাম', '2', '', 'sdfsd', '', 'sdf', '0', 'sdf', '', 'sdf', '', 'sdfsdf', '', 'sdf', '', 'sdfsd', '', 'sdf', '0', 'sdf', '', 'sdf', '', 'sdfsdf', '', 'sdf', '01111111111', '', '', 'http://application.smartup.com.bd/img/default/profile.png', '1', '2017-04-13', '2017-04-14 14:37:35');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('6', '088711', '20176112385678372', '3', '5', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-04-26', 'জ্ঞ', 'হহ', 'female', '2', '', '', '', '', 'হহহ', 'হহ', 'ভহ', 'অহহহ', '', '', 'ইসলাম', '2', 'hh', '', 'yuu', '', '0', '', 'bbh', '', 'vvvg', '', '07', '', 'hh', '', 'yuu', '', '0', '', 'bbh', '', 'vvvg', '', '07', '', '01910807000', '', '', 'http://application.smartup.com.bd/img/default/profile.png', '1', '2017-04-14', '2017-04-14 14:35:51');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('7', '878895', '20176112385895157', '3', '6', '', '', '', '', '', '', '', '20000', '', '', '0000-00-00', '', '', '', '2017-04-26', 'জ্ঞ', 'হহ', 'female', '2', '', '', '', '', 'হহহ', 'হহ', 'ভহ', 'অহহহ', '', '', 'ইসলাম', '2', 'hh', '', 'yuu', '', '0', '', 'bbh', '', 'vvvg', '', '07', '', 'hh', '', 'yuu', '', '0', '', 'bbh', '', 'vvvg', '', '07', '', '01910807000', '', '', 'http://application.smartup.com.bd/img/default/profile.png', '1', '2017-04-14', '2017-04-18 14:00:42');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('8', '102755', '20176112385925601', '3', '7', '', '', '', '', '', '', '', '', 'aksh', '', '0000-00-00', '', '', '', '2017-03-27', 'fff', 'askhhh', 'male', '2', '', '', '', '', 'gg', 'ggg', 'gg', 'gg', '', '', 'ইসলাম', '1', '', 'ggg', '', 'ggg', '0', '07', '', 'gg', '', 'gg', '', 'g', '', '', '', '', '0', '', '', '', '', '', '', '', '01965656565', '', '', 'http://application.smartup.com.bd/img/default/profile.png', '1', '2017-04-14', '2017-04-14 15:24:43');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('9', '521140', '20176112385512864', '3', '8', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-04-18', 'hgj', 'ghj', 'male', '2', '', '', '', '', 'ghj', 'ghj', 'ghj', 'ghj', '', '', 'ইসলাম', '1', '', 'ghj', '', 'hgj', '0', '7', '', 'dfhg', '', 'df', '', 'dfh', '', '', '', '', '0', '', '', '', '', '', '', '', '01965656565', '', '', 'http://application.smartup.com.bd/img/default/profile.png', '1', '2017-04-14', '2017-04-14 15:28:15');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('10', '781763', '20176112385389703', '3', '9', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-05-17', 'gfhg', 'fgh', 'male', '5', '', '', '', '', 'fgh', 'fg', 'fgh', 'fgh', '', '', 'ইসলাম', '1', '', '', '', '', '0', '1', '', 'dfg', '', 'dfg', '', 'dfg', '', '', '', '', '0', '', '', '', '', '', '', '', '01965656565', '', '', 'http://application.smartup.com.bd/img/default/profile.png', '1', '2017-04-14', '2017-04-14 15:31:10');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('11', '601895', '20176112385444361', '3', '10', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-04-19', 'kljlkh', 'ml,k,', 'male', '2', '', '', '', '', 'dsf', 'dfsg', 'dfg', 'fdg', '', '', 'ইসলাম', '1', '', 'fd', '', '', '0', '5', '', 'fd', '', 'fdgdf', '', 'df', '', '', '', '', '0', '', '', '', '', '', '', '', '01965656565', '', '', 'http://application.smartup.com.bd/img/default/profile.png', '1', '2017-04-14', '2017-04-14 15:35:23');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('12', '890857', '20176112385160858', '3', '11', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-04-11', 'lkl', 'lkl', 'male', '2', '', '', '', '', 'klk', 'kl', 'hjhj', 'kl', '', '', 'অন্যান্য', '2', '', 'hj', '', 'hj', '0', '8', '', 'hj', '', 'hj', '', 'hj', '', 'hj', '', 'hj', '0', '8', '', 'hj', '', 'hj', '', 'hj', '01965656565', '', '', 'http://application.smartup.com.bd/img/default/profile.png', '1', '2017-04-14', '2017-04-14 15:38:54');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('13', '084345', '20176112385498049', '3', '10', '', '', '', '', '', '', '', '', '', 'নো-বাহিনী', '0000-00-00', '', '', '', '2017-04-17', 'fgf', 'fg', 'male', '2', '', '', '', '', 'fg', 'fg', 'fg', 'fg', '', '', 'ইসলাম', '1', '', 'fg', '', 'fghf', '0', '6', '', 'fg', '', 'fg', '', 'fg', '', '', '', '', '0', '', '', '', '', '', '', '', '01965656565', '', '', 'http://application.smartup.com.bd/img/default/profile.png', '1', '2017-04-14', '2017-04-18 14:51:25');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('14', '968655', '20176112385887339', '3', '1', '', '', '', '', '', '', '', '', '', '', '2017-04-19', '23423452345234523', '23453245234645654', '34563456346345634', '2017-04-03', 'asdfasdfasf', 'asdfasdf', 'male', '2', '', '', '', '', 'adsfadsf', 'asdfasdf', 'asfdasdf', 'asdfasdf', 'asdfasd', 'asdfasd', 'ইসলাম', '2', 'adsf', 'asdf', 'adsf', 'asdf', '2', '2', 'adf', 'af', 'asdf', 'asfd', 'asdf', 'af', 'adsf', 'asdf', 'adsf', 'asdf', '2', '2', 'adf', 'af', 'asdf', 'asfd', 'asdf', 'af', '01825689784', 'rana.feni.fci@gmail.com', 'asdfasdf', 'http://localhost/db_correction/smartup/img/default/profile.png', '1', '2017-04-18', '2017-05-01 01:45:08');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('15', '071256', '20176112385687741', '3', '3', '', '', '', '', '', '', '', '222', 'aaa', 'aaa', '0000-00-00', '32523452345453667', '34634625252424545', '34676786786586586', '2017-04-04', 'aaaaaaaaaaaa', 'aaaaaaaaaaaaaa', 'male', '1', 'sdfg', 'sg', '', '', 'sdfgfd', 'sdg', 'sdfgfg', 'sdgsdfg', 'sdfgsdf', 'sdfgsdf', 'ইসলাম', '1', 'aaaa', 'aaaaa', 'aaaa', 'aaaa', '1', '1', 'aa', 'aa', 'aa', 'aa', 'aa', 'aa', 'bb', 'bb', 'bb', 'bb', '2', '2', 'bb', 'bb', 'bb', 'bb', 'bb', 'bb', '01825292986', 'rana.feni.fci@gmail.com', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '1', '2017-04-18', '2017-04-18 18:29:26');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('16', '396612', NULL, '3', '0', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '2222222222222222', '3333333333333333', '233333333232323', '2017-05-09', 'vvvvvvvv', 'vvvvvvvv', 'female', '2', '', '', '', '', 'vvvvvvvvv', 'vvvvvvvvvvv', 'vvvvvvvvv', 'vvvvvvvvv', 'vvvvvvv', 'vvvvvvvv', 'ইসলাম', '2', 'vvvvvv', 'vvvvv', 'vvvvv', 'vvvvv', '44', '44', 'vvv', 'vvv', 'vvv', 'vvv', 'vvv', 'vvv', 'vvvvvv', 'vvvvv', 'vvvvv', 'vvvvv', '44', '44', 'vvv', 'vvv', 'vvv', 'vvv', 'vvv', 'vvv', '01743714360', 'rana.feni.fci@gmail.com', '', 'http://localhost/db_correction/smartup//library/profile/149434332814843.jpg', '0', '2017-05-09', '2017-05-09 21:26:51');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('17', '005129', NULL, '3', '12', '', '', '', '', '', '', '2222222222', '', '', '', '0000-00-00', '34253253245345234', '23452345234523453', '23523523523452345', '2017-05-01', 'sdfgdsfg', 'sdgfsdfg', 'male', '2', '', '', '', '', 'sdfgsdfgsd', 'sdfgsdfgs', 'sdgsdgsd', 'sdgsdgsdf', 'sdfgsdfgsdf', 'sdfgsdfg', 'ইসলাম', '2', 'sdfg', 'sdfg', 'sdfg', 'sdgf', '4', '4', 'sdfgsdfg', 'kjgjk', 'hjklhklh', 'hjlkjl', 'lkhjlkhjlkj', 'lllllloooo', 'sdfg', 'sdfg', 'sdfg', 'sdgf', '4', '4', 'sdfgsdfg', 'kjgjk', 'hjklhklh', 'hjlkjl', 'lkhjlkhjlkj', 'lllllloooo', '01743714368', 'rana.feni.fci@gmail.com', 'hgg', 'http://localhost/db_correction/smartup//library/profile/149434414123064.jpg', '0', '2017-05-09', '2017-05-09 21:37:19');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('18', '197136', NULL, '3', '3', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '33643643656465546', '3465464643634643', '34564356346346345', '2017-05-01', 'fdssdfgdsgdsg', 'sdgsdfgsdg', 'male', '2', '', '', '', '', 'sdgsdfgsdfg', 'dfgsdfgsdfs', 'sdgsdgsdg', 'sdfsdfgsdf', 'sdgsdfg', 'sdgsdfg', 'ইসলাম', '2', 'sdfgsdfg', 'sdgsdfg', 'sdfgsdfg', 'sdfgsdfg', '44', '44', 'sdfg', 'sdfg', 'sdfg', 'sdfg', 'sdfg', 'sdfg', 'sdfgsdfg', 'sdgsdfg', 'sdfgsdfg', 'sdfgsdfg', '44', '44', 'sdfg', 'sdfg', 'sdfg', 'sdfg', 'sdfg', 'sdfg', '01825292987', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 21:39:15');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('19', '063838', NULL, '3', '12', '', '', '', '', '', '', '1111111', '', '', '', '0000-00-00', '', '', '', '2017-05-15', 'sdfg', 'sdfgsdf', 'male', '2', '', '', '', '', 'sdfsdfg', 'sdfgsdfg', 'sdfgsdfg', 'sdfgsdfg', 'sdfgsdfg', 'sdfgsdfg', 'ইসলাম', '2', 'sdfg', 'sdfg', 'sdfg', 'sdfg', '4', '4', 'sdfg', 'sdf', 'sdf', 'sdfg', 'sdgf', 'sdfg', 'sdfg', 'sdfg', 'sdfg', 'sdfg', '4', '4', 'sdfg', 'sdf', 'sdf', 'sdfg', 'sdgf', 'sdfg', '01743714367', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 21:41:40');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('20', '559652', NULL, '3', '2', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-05-07', 'sdfgdfg', 'sdfgsdg', 'male', '2', '', '', '', '', 'sdfgsdfg', 'sdfgds', 'sdfgdsfg', 'sdfgdsf', 'sdfgdsfg', 'sdfgsdf', 'ইসলাম', '2', 'sdfgsdf', 'sdg', 'dsfsdgf', 'sdfgsd', '4', '4', 'sdsdf', 'sdfg', 'sdfg', 'sdfg', 'sdfg', 'sdfg', 'sdfgsdf', 'sdg', 'dsfsdgf', 'sdfgsd', '4', '4', 'sdsdf', 'sdfg', 'sdfg', 'sdfg', 'sdfg', 'sdfg', '01743714311', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 21:44:40');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('21', '289246', NULL, '3', '2', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-05-07', 'sdfgdfg', 'sdfgsdg', 'male', '2', '', '', '', '', 'sdfgsdfg', 'sdfgds', 'sdfgdsfg', 'sdfgdsf', 'sdfgdsfg', 'sdfgsdf', 'ইসলাম', '2', 'sdfgsdf', 'sdg', 'dsfsdgf', 'sdfgsd', '4', '4', 'sdsdf', 'sdfg', 'sdfg', 'sdfg', 'sdfg', 'sdfg', 'sdfgsdf', 'sdg', 'dsfsdgf', 'sdfgsd', '4', '4', 'sdsdf', 'sdfg', 'sdfg', 'sdfg', 'sdfg', 'sdfg', '01743714311', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 21:45:19');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('22', '004659', NULL, '3', '2', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-05-07', 'sdfgdfg', 'sdfgsdg', 'male', '2', '', '', '', '', 'sdfgsdfg', 'sdfgds', 'sdfgdsfg', 'sdfgdsf', 'sdfgdsfg', 'sdfgsdf', 'ইসলাম', '2', 'sdfgsdf', 'sdg', 'dsfsdgf', 'sdfgsd', '4', '4', 'sdsdf', 'sdfg', 'sdfg', 'sdfg', 'sdfgr', 'sdfg', 'sdfgsdf', 'sdg', 'dsfsdgf', 'sdfgsd', '4', '4', 'sdsdf', 'sdfg', 'sdfg', 'sdfg', 'sdfgr', 'sdfg', '01743714311', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 21:45:30');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('23', '463621', NULL, '3', '2', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-05-17', 'dfsgsdg', 'sdfgdsfg', 'male', '2', '', '', '', '', 'sdfgsdfg', 'sdfgsdfg', 'sdfgsdfg', 'sdgsdf', 'sdfgsdfg', 'sdfgsdf', 'ইসলাম', '2', '', '', '', '', '0', '', '', '', '', '', 's', '', '', '', '', '', '0', '', '', '', '', '', 's', '', '01743714365', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 21:51:00');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('24', '202539', NULL, '3', '10', '', '', '', '', '', '', '', '', '', 'wwwwwww', '0000-00-00', '', '', '', '2017-04-30', 'zxvczxvc', 'xzvxzvc', 'male', '2', '', '', '', '', ' jfghjgfj', 'gfjgj', 'fgjgfhj', 'fgjfgj', 'jg', 'ghjgj', 'ইসলাম', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '01744578965', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 21:52:40');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('25', '055913', NULL, '3', '10', '', '', '', '', '', '', '', '', '', 'wwwwwww', '0000-00-00', '', '', '', '2017-04-30', 'zxvczxvc', 'xzvxzvc', 'male', '2', '', '', '', '', ' jfghjgfj', 'gfjgj', 'fgjgfhj', 'fgjfgj', 'jg', 'ghjgj', 'ইসলাম', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '01744578965', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 21:52:57');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('26', '588412', NULL, '3', '10', '', '', '', '', '', '', '', '', '', 'wwwwwww', '0000-00-00', '', '', '', '2017-04-30', 'zxvczxvc', 'xzvxzvc', 'male', '2', '', '', '', '', ' jfghjgfj', 'gfjgj', 'fgjgfhj', 'fgjfgj', 'jg', 'ghjgj', 'ইসলাম', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '01744578965', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 21:59:24');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('27', '784686', NULL, '3', '10', '', '', '', '', '', '', '', '', '', 'wwwwwww', '0000-00-00', '', '', '', '2017-04-30', 'zxvczxvc', 'xzvxzvc', 'male', '2', '', '', '', '', ' jfghjgfj', 'gfjgj', 'fgjgfhj', 'fgjfgj', 'jg', 'ghjgj', 'ইসলাম', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '01744578965', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 21:59:39');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('28', '379087', NULL, '3', '10', '', '', '', '', '', '', '', '', '', 'wwwwwww', '0000-00-00', '', '', '', '2017-04-30', 'zxvczxvc', 'xzvxzvc', 'male', '2', '', '', '', '', ' jfghjgfj', 'gfjgj', 'fgjgfhj', 'fgjfgj', 'jg', 'ghjgj', 'ইসলাম', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '01744578965', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 21:59:57');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('29', '812141', NULL, '3', '10', '', '', '', '', '', '', '', '', '', 'wwwwwww', '0000-00-00', '', '', '', '2017-04-30', 'zxvczxvc', 'xzvxzvc', 'male', '2', '', '', '', '', ' jfghjgfj', 'gfjgj', 'fgjgfhj', 'fgjfgj', 'jg', 'ghjgj', 'ইসলাম', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '01744578965', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 22:00:14');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('30', '324713', NULL, '3', '2', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-05-08', 'sdfgsdfg', 'sdfgs', 'male', '2', '', '', '', '', 'sdfg', 'sdfg', 'sdfg', 'sdfg', '', '', 'ইসলাম', '2', 'sdgf', 'sdgf', 'sdg', 'sdgf', '4', '4', 'fghfdh', 'dhg', 'dfh', 'dgh', 'dfhg', 'dfhg', 'sdgf', 'sdgf', 'sdg', 'sdgf', '4', '4', 'fghfdh', 'dhg', 'dfh', 'dgh', 'dfhg', 'dfhg', '01744578961', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 22:01:24');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('31', '433196', NULL, '3', '2', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-05-08', 'sdfgsdfg', 'sdfgs', 'male', '2', '', '', '', '', 'sdfg', 'sdfg', 'sdfg', 'sdfg', '', '', 'ইসলাম', '2', 'sdgf', 'sdgf', 'sdg', 'sdgf', '4', '4', 'fghfdh', 'dhg', 'dfh', 'dgh', 'dfhg', 'dfhg', 'sdgf', 'sdgf', 'sdg', 'sdgf', '4', '4', 'fghfdh', 'dhg', 'dfh', 'dgh', 'dfhg', 'dfhg', '01744578960', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 22:02:56');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('32', '139110', NULL, '3', '11', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-05-08', 'zxvzxc', 'zxv', 'male', '2', '', '', '', '', 'zxv', 'zxv', 'zxv', 'zxvc', 'zx', 'zxvc', 'ইসলাম', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '01744578967', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 22:03:42');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('33', '216073', NULL, '3', '2', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-05-08', 'fgsdfg', 'sdfgsdfg', 'male', '2', '', '', '', '', 'sdfg', 'sdfg', 'sdf', 'sdfg', 'sdf', 'sdfg', 'ইসলাম', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '01744578963', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 22:05:24');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('34', '876717', NULL, '3', '2', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-05-02', 'rana', 'asas', 'male', '2', '', '', '', '', 'asdfsadf', 'asdfsadf', 'sadf', 'asdf', '', '', 'ইসলাম', '2', 'asdf', 'asdf', 'asdf', 'asd', '3', '3', 'asd', 'fdh', 'dfhg', 'dfhg', 'dgh', 'fdhgf', 'asdf', 'asdf', 'asdf', 'asd', '3', '3', 'asd', 'fdh', 'dfhg', 'dfhg', 'dgh', 'fdhgf', '01965874156', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 22:08:00');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('35', '463982', NULL, '3', '2', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-05-02', 'rana', 'asas', 'male', '2', '', '', '', '', 'asdfsadf', 'asdfsadf', 'sadf', 'asdf', '', '', 'ইসলাম', '2', 'asdf', 'asdf', 'asdf', 'asd', '3', '3', 'asd', 'fdh', 'dfhg', 'dfhg', 'dgh', 'fdhgf', 'asdf', 'asdf', 'asdf', 'asd', '3', '3', 'asd', 'fdh', 'dfhg', 'dfhg', 'dgh', 'fdhgf', '01965874156', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-05-09', '2017-05-09 22:40:00');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('36', '678061', NULL, '3', '2', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '1234567777777777', '7765432111111111', '213234344554656', '2017-05-01', 'ruji', 'ruji', 'female', '2', '', '', '', '', 'as', 'as', 'sd', 'sd', 'df', 'df', 'ইসলাম', '2', 'as', 'as', 'as', 'as', '2', '2', 'as', 'as', 'as', 'as', 'as', 'as', 'as', 'as', 'as', 'as', '2', '2', 'as', 'as', 'as', 'as', 'as', 'as', '01825926003', 'rana@gmali.com', '', 'http://localhost/db_correction/smartup//library/profile/149434826126879.jpg', '0', '2017-05-09', '2017-05-09 22:47:20');
INSERT INTO `otherserviceinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `serviceId`, `mukti_name`, `gejet_no`, `m_sonshod_sonod`, `relation`, `short_rel`, `sector_no`, `mukti_sonod`, `incomeAmount`, `publishName`, `workPlace`, `ddfb`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('37', '744122', NULL, '3', '2', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '2017-05-10', 'asasas', 'asasasa', 'male', '2', '', '', '', '', 'asas', 'asas', 'asasas', 'asas', 'asasas', 'asasas', 'ইসলাম', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '01744578966', '', '', 'http://localhost/db_correction/smartup//library/profile/14943484765836.jpg', '0', '2017-05-09', '2017-05-09 22:48:24');


#
# TABLE STRUCTURE FOR: otherservicelist
#

DROP TABLE IF EXISTS `otherservicelist`;

CREATE TABLE `otherservicelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `listName` varchar(120) NOT NULL,
  `insdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ins_user` varchar(60) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `otherservicelist` (`id`, `listName`, `insdate`, `ins_user`, `status`) VALUES ('1', 'মৃত্যু সনদ', '2017-04-11 19:58:18', 'abs_rana', '1');
INSERT INTO `otherservicelist` (`id`, `listName`, `insdate`, `ins_user`, `status`) VALUES ('2', 'চারিত্রিক সনদ', '2017-04-11 19:58:18', 'abs_rana', '1');
INSERT INTO `otherservicelist` (`id`, `listName`, `insdate`, `ins_user`, `status`) VALUES ('3', 'অবিবাহিত সনদ', '2017-04-11 19:58:18', 'abs_rana', '1');
INSERT INTO `otherservicelist` (`id`, `listName`, `insdate`, `ins_user`, `status`) VALUES ('4', 'ভূমিহীন সনদ', '2017-04-11 19:58:18', 'abs_rana', '1');
INSERT INTO `otherservicelist` (`id`, `listName`, `insdate`, `ins_user`, `status`) VALUES ('5', 'পুনঃ বিবাহ না হওয়া সনদ ', '2017-04-11 19:58:18', 'abs_rana', '1');
INSERT INTO `otherservicelist` (`id`, `listName`, `insdate`, `ins_user`, `status`) VALUES ('6', 'বার্ষিক আয়ের প্রত্যয়ন', '2017-04-11 19:58:18', 'abs_rana', '1');
INSERT INTO `otherservicelist` (`id`, `listName`, `insdate`, `ins_user`, `status`) VALUES ('7', 'একই নামের প্রত্যয়ন', '2017-04-11 19:58:18', 'abs_rana', '1');
INSERT INTO `otherservicelist` (`id`, `listName`, `insdate`, `ins_user`, `status`) VALUES ('8', 'প্রতিবন্ধী প্রত্যয়ন পত্র', '2017-04-18 12:20:37', 'abs_rana', '1');
INSERT INTO `otherservicelist` (`id`, `listName`, `insdate`, `ins_user`, `status`) VALUES ('9', 'সনাতন ধর্ম  অবলম্বী', '2017-04-11 19:58:18', 'abs_rana', '1');
INSERT INTO `otherservicelist` (`id`, `listName`, `insdate`, `ins_user`, `status`) VALUES ('10', 'অনুমতি পত্র', '2017-04-11 19:58:18', 'abs_rana', '1');
INSERT INTO `otherservicelist` (`id`, `listName`, `insdate`, `ins_user`, `status`) VALUES ('11', 'প্রত্যয়ন পত্র', '2017-04-11 19:58:18', 'abs_rana', '1');
INSERT INTO `otherservicelist` (`id`, `listName`, `insdate`, `ins_user`, `status`) VALUES ('12', 'মুক্তিযোদ্ধা সনদ', '2017-05-06 12:22:29', 'abs_rana', '1');
INSERT INTO `otherservicelist` (`id`, `listName`, `insdate`, `ins_user`, `status`) VALUES ('13', 'মুক্তিযোদ্ধা পোষ্য সনদ', '2017-05-06 12:22:29', 'abs_rana', '1');


#
# TABLE STRUCTURE FOR: personalinfo
#

DROP TABLE IF EXISTS `personalinfo`;

CREATE TABLE `personalinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trackid` varchar(8) NOT NULL,
  `sonodno` varchar(17) DEFAULT NULL,
  `delivery_type` tinyint(3) NOT NULL,
  `nationid` varchar(20) DEFAULT NULL,
  `bcno` varchar(20) DEFAULT NULL,
  `pno` varchar(20) DEFAULT NULL,
  `dofb` date NOT NULL,
  `ename` varchar(60) NOT NULL,
  `name` varchar(80) NOT NULL,
  `gender` enum('male','female','others') NOT NULL,
  `mstatus` tinyint(2) NOT NULL,
  `ewname` varchar(60) DEFAULT NULL,
  `bwname` varchar(80) DEFAULT NULL,
  `ehname` varchar(60) DEFAULT NULL,
  `bhname` varchar(80) DEFAULT NULL,
  `efname` varchar(60) NOT NULL,
  `bfname` varchar(80) NOT NULL,
  `emname` varchar(60) NOT NULL,
  `mname` varchar(80) NOT NULL,
  `ocupt` varchar(120) DEFAULT NULL,
  `edustatus` varchar(120) DEFAULT NULL,
  `religion` varchar(30) NOT NULL,
  `bashinda` enum('1','2') NOT NULL,
  `p_gram` varchar(60) DEFAULT NULL,
  `pb_gram` varchar(100) DEFAULT NULL,
  `p_rbs` varchar(60) DEFAULT NULL,
  `pb_rbs` varchar(80) DEFAULT NULL,
  `p_wordno` int(4) DEFAULT NULL,
  `pb_wordno` varchar(10) DEFAULT NULL,
  `p_dis` varchar(60) DEFAULT NULL,
  `pb_dis` varchar(100) DEFAULT NULL,
  `p_thana` varchar(60) DEFAULT NULL,
  `pb_thana` varchar(100) DEFAULT NULL,
  `p_postof` varchar(60) DEFAULT NULL,
  `pb_postof` varchar(100) DEFAULT NULL,
  `per_gram` varchar(60) DEFAULT NULL,
  `perb_gram` varchar(100) DEFAULT NULL,
  `per_rbs` varchar(60) DEFAULT NULL,
  `perb_rbs` varchar(80) DEFAULT NULL,
  `per_wordno` int(4) DEFAULT NULL,
  `perb_wordno` varchar(10) DEFAULT NULL,
  `per_dis` varchar(60) DEFAULT NULL,
  `perb_dis` varchar(100) DEFAULT NULL,
  `per_thana` varchar(60) DEFAULT NULL,
  `perb_thana` varchar(100) DEFAULT NULL,
  `per_postof` varchar(60) DEFAULT NULL,
  `perb_postof` varchar(100) DEFAULT NULL,
  `mobile` varchar(11) NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `attachment` text,
  `profile` varchar(160) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `insert_time` date NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trackid` (`trackid`),
  UNIQUE KEY `sonodno` (`sonodno`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO `personalinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('1', '334901', NULL, '3', '199530120080193', '199508301234564', 'aaaa1023654078955', '1995-08-15', 'Abu Baker Siddique', 'আবু বকর ছিদ্দিক', 'male', '2', '', '', '', '', 'Abdul Momin', 'আবদুল মমিন', 'Razia Begum', 'রেজিয়া বেগম', 'ছাত্র', 'ডিপ্লোমা', 'ইসলাম', '1', 'Kunjoban', 'কুণ্জবন', '23', '২৩', '2', '২', 'Dhaka', 'ঢাকা', 'Rampura', 'রামপুরা', 'Rampura', 'রামপুরা', 'Jaylashker', 'জায়লস্কর', '123', '১২৩', '7', '৭', 'Feni', 'ফেনী', 'Dagonbhuyan', 'দাগন ভূঞাঁ', 'Jaylashker', 'জায়লস্কর', '01825292980', 'rana.feni.fci@gmail.com', 'মুক্তিযোদ্ধার সন্তান', 'http://localhost/db_correction/smartup//library/profile/147497141016372.jpg', '0', '2016-09-27', '2016-11-29 20:19:06');
INSERT INTO `personalinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('2', '532217', NULL, '3', '', '', '', '2016-09-05', 'asdfasdf', 'asdfasdf', 'female', '2', '', '', 'hidden sami', 'bangla hidden sami', 'adsfsadf', 'asdf', 'asdf', 'asdf', '', '', 'ইসলাম', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '01285596741', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2016-09-27', '2016-11-29 20:19:10');
INSERT INTO `personalinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('3', '024245', NULL, '3', '', '', '', '2016-09-05', 'aaaaaaaaaaa', 'aaaaaaaaaa', 'female', '1', '', '', '', '', 'aaaaaaa', 'aaaaaaaaa', 'aaaaaaaaaa', 'aaaaaaaaaaaa', '', '', 'ইসলাম', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '01285596700', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2016-09-27', '2016-11-29 20:19:15');
INSERT INTO `personalinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('4', '569345', NULL, '3', '', '', '', '2016-09-05', 'asdfasf', 'asdasdf', 'female', '2', '', '', '', '', 'asdf', 'asdf', 'asdf', 'asdf', '', '', 'হিন্দু', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '01285596000', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2016-09-27', '2016-11-29 20:19:18');
INSERT INTO `personalinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('5', '170409', NULL, '3', '', '', '', '2016-09-05', 'asdfasf', 'asdasdf', 'female', '1', '', '', 'third hidden', 'third hidden', 'asdf', 'asdf', 'asdf', 'asdf', '', '', 'হিন্দু', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '01285596000', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2016-09-27', '2016-09-27 18:40:26');
INSERT INTO `personalinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('6', '546207', NULL, '3', '', '', '', '2016-09-05', 'asdfasf', 'asdasdf', 'female', '1', '', '', 'third hidden', 'third hidden', 'asdf', 'asdf', 'asdf', 'asdf', '', '', 'হিন্দু', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '01285596000', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2016-09-27', '2016-09-27 18:41:19');
INSERT INTO `personalinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('7', '051334', NULL, '3', '', '', '', '2016-09-15', 'qwer', 'qwer', 'male', '2', '', '', '', '', 'qwe', 'qwer', 'qwer', 'qwer', '', '', 'ইসলাম', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '01285596000', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2016-09-27', '2016-11-29 20:19:23');
INSERT INTO `personalinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('8', '647854', NULL, '3', '', '', '', '2016-09-05', 'asdf', 'asdf', 'female', '1', '', '', 'third hidden', 'third hiddne bang', 'asdf', 'asdf', 'ads', 'asdf', '', '', 'বৌদ্ধ ধর্ম', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '04567687989', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2016-09-27', '2016-11-29 20:19:26');
INSERT INTO `personalinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('9', '267550', NULL, '3', '23423523453245342', '23523453245342532', '564353434435646', '2016-10-17', 'sdfgdsfg', 'sdgsgd', 'male', '2', '', '', '', '', 'sdfg', 'sdfgdsfg', 'sdg', 'sdfg', '', '', 'ইসলাম', '2', 'sdfg', 'sdfg', 'sdfg', 'sfg', '45', '4', 'sfdg', 'sfg', 'sdg', 'sdg', 'sdfg', 'sg', 'sdfg', 'sdfg', 'sdfg', 'sfg', '45', '4', 'sfdg', 'sfg', 'sdg', 'sdg', 'sdfg', 'sg', '01685596741', 'rana.feni.fci@gmail.com', 'sdfgdsfgf', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2016-10-01', '2016-11-29 20:19:31');
INSERT INTO `personalinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('10', '933846', '20171234567803702', '3', '25234235234523523', '23452345234523453', '23453245234523', '2016-10-04', 'asdfsadfa', 'asdf', 'female', '2', '', '', '', '', 'asdf', 'asdf', 'asdf', 'asdf', 'asdf', 'asdf', 'ইসলাম', '2', 'sadfasdf', 'afadf', ' asdf', 'asf', '7', '৭', 'ad', 'ad', 'asd', 'afd', 'a', 'a', 'sadfasdf', 'afadf', ' asdf', 'asf', '7', '৭', 'ad', 'ad', 'asd', 'afd', 'a', 'a', '01685596740', 'rana.feni.fci@gmail.com', '', 'http://localhost/db_correction/smartup//library/profile/149018696615092.jpg', '1', '2016-10-02', '2017-03-22 18:50:00');
INSERT INTO `personalinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('11', '113917', '20171234567872713', '3', '2345234567777777', '777777777777777', '3465346456436346', '2016-10-03', 'Borhan Uddin', 'বোরহান উদ্দিন', 'male', '2', '', '', '', '', 'Abul Hasam', 'আবুল হাসেম', 'Dil are Begum', 'দিলয়ারা বেগম', 'শিক্ষক', 'বি. এস . ‍সি', 'ইসলাম', '2', 'Jaylashker', 'জায়লস্কর', '34', '৩৪', '12', '১২', 'Feni', 'ফেনী', 'Jaylashker', 'জায়লস্কর', 'Jaylashker', 'জায়লস্কর', 'Jaylashker', 'জায়লস্কর', '34', '৩৪', '12', '১২', 'Feni', 'ফেনী', 'Jaylashker', 'জায়লস্কর', 'Jaylashker', 'জায়লস্কর', '01828087369', 'rana.feni.fci@gmail.com', 'osman', 'http://localhost/db_correction/smartup//library/profile/147575956126617.jpg', '1', '2016-10-06', '2017-03-15 16:00:57');
INSERT INTO `personalinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('12', '212261', NULL, '3', '', '', '', '2017-04-04', 'asdfas', 'asdfasd', 'male', '2', '', '', '', '', 'asdf', 'asdf', 'asdfasdf', 'adfasd', '', '', 'ইসলাম', '2', 'asdf', '', '', '', '0', '', '', '', '', '', '', '', 'asdf', '', '', '', '0', '', '', '', '', '', '', '', '01825292987', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0', '2017-03-16', '2017-03-16 12:55:32');
INSERT INTO `personalinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('13', '161129', '20186112385824693', '3', '23452352345234523', '43635634634562352', '34637667846234523', '2017-06-02', 'wretwert', 'wertrwe', 'male', '2', '', '', '', '', 'ewrtewrt', 'wertwer', 'wertwer', 'wert', 'wtwer', 'wererw', 'ইসলাম', '2', 'wert', 'wert', 'wert', 'wer', '3', '4', 'wert', 'wert', 'wert', 'wer', 'wet', 'wert', 'wert', 'wert', 'wert', 'wer', '3', '4', 'wert', 'wert', 'wert', 'wer', 'wet', 'wert', '01821292950', 'rana.feni.fci@gmail.com', 'wertwert', 'http://localhost/db_correction/smartup//library/profile/14900849261436.jpg', '1', '2017-03-21', '2018-01-22 13:08:19');
INSERT INTO `personalinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('14', '167991', '20176112385998134', '3', '34564363466436356', '35634563635634634', '33443346346345635', '2017-03-30', 'sdfgsdfg', 'sdfgsdfg', 'male', '2', '', '', '', '', 'sdfgsdfg', 'sdfgsdf', 'sdfgsdfg', 'sdfgsdfsdf', 'wretwert', 'wertwert', 'ইসলাম', '2', 'wert', 'wer', 'wert', 'wert', '5', '4', 'sdfgsdfg', 'sdfg', 'sfdg', 'sdf', 'sdfg', 'sdf', 'wert', 'wer', 'wert', 'wert', '5', '4', 'sdfgsdfg', 'sdfg', 'sfdg', 'sdf', 'sdfg', 'sdf', '01825292987', 'rana.feni.fci@gmail.com', 'sdgsdg', 'http://localhost/db_correction/smartup/img/default/profile.png', '1', '2017-04-12', '2017-04-14 18:02:36');
INSERT INTO `personalinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `name`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `mname`, `ocupt`, `edustatus`, `religion`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `mobile`, `email`, `attachment`, `profile`, `status`, `insert_time`, `utime`) VALUES ('15', '831143', '20176112385655674', '3', '23452345324523452', '23343434343000000', '234523452345234', '2017-04-04', 'aaaaaaaaaa', 'aaaaaaaaaaaaaa', 'male', '1', 'sdfg', 'sg', '', '', 'sdfgfd', 'sdg', 'sdfgfg', 'sdgsdfg', 'sdfgsdf', 'sdfgsdf', 'ইসলাম', '1', 'aaaa', 'aaaaa', 'aaaa', 'aaaa', '1', '1', 'aa', 'aa', 'aa', 'aa', 'aa', 'aa', 'bb', 'bb', 'bb', 'bb', '2', '2', 'bb', 'bb', 'bb', 'bb', 'bb', 'bb', '01825292986', 'rana.feni.fci@gmail.com', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '1', '2017-04-14', '2017-04-18 17:32:01');


#
# TABLE STRUCTURE FOR: porichoprotro
#

DROP TABLE IF EXISTS `porichoprotro`;

CREATE TABLE `porichoprotro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trackid` varchar(8) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `trno` bigint(20) NOT NULL,
  `vno` bigint(20) NOT NULL,
  `acno` varchar(255) NOT NULL,
  `fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payment_date` date NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `porichoprotro` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('1', '113917', '1', '4', '4', '0000-0000-0000-0000', '100.00', '2017-03-15', '2017-03-15 16:00:57');
INSERT INTO `porichoprotro` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('2', '933846', '2', '8', '8', '0000-0000-0000-0000', '150.00', '2017-03-15', '2017-03-15 19:52:08');
INSERT INTO `porichoprotro` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('3', '167991', '3', '34', '32', '0000-0000-0000-0000', '0.00', '2017-04-14', '2017-04-14 18:02:36');
INSERT INTO `porichoprotro` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('4', '831143', '4', '37', '35', '0000-0000-0000-0000', '0.00', '2017-04-14', '2017-04-14 21:19:33');
INSERT INTO `porichoprotro` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('5', '161129', '5', '62', '59', '0000-0000-0000-0000', '0.00', '2018-01-22', '2018-01-22 13:08:19');


#
# TABLE STRUCTURE FOR: rate_sheet
#

DROP TABLE IF EXISTS `rate_sheet`;

CREATE TABLE `rate_sheet` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `licence_type` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ins_user` varchar(60) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1' COMMENT '1=active, 0= inactive',
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `rate_sheet` (`rid`, `licence_type`, `amount`, `up_date`, `ins_user`, `status`) VALUES ('1', 'চায়ের দোকান', '500.00', '2017-04-06 15:34:42', 'abs_rana', '1');
INSERT INTO `rate_sheet` (`rid`, `licence_type`, `amount`, `up_date`, `ins_user`, `status`) VALUES ('2', 'ঔষধের দোকান', '2000.00', '2017-04-06 15:35:04', 'abs_rana', '1');


#
# TABLE STRUCTURE FOR: rate_sheet_history
#

DROP TABLE IF EXISTS `rate_sheet_history`;

CREATE TABLE `rate_sheet_history` (
  `hid` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) NOT NULL,
  `old_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `new_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ins_date` date NOT NULL,
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `up_user` varchar(60) NOT NULL,
  `status` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`hid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `rate_sheet_history` (`hid`, `rid`, `old_amount`, `new_amount`, `ins_date`, `up_date`, `up_user`, `status`) VALUES ('1', '1', '500.00', '500.00', '2017-04-06', '2017-04-06 15:34:42', 'abs_rana', '1');
INSERT INTO `rate_sheet_history` (`hid`, `rid`, `old_amount`, `new_amount`, `ins_date`, `up_date`, `up_user`, `status`) VALUES ('2', '2', '2000.00', '2000.00', '2017-04-06', '2017-04-06 15:35:04', 'abs_rana', '1');


#
# TABLE STRUCTURE FOR: renew_req
#

DROP TABLE IF EXISTS `renew_req`;

CREATE TABLE `renew_req` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sno` varchar(17) NOT NULL,
  `dtype` tinyint(3) NOT NULL,
  `renew_utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: setup_tbl
#

DROP TABLE IF EXISTS `setup_tbl`;

CREATE TABLE `setup_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `full_name_english` varchar(255) NOT NULL,
  `gram` varchar(60) NOT NULL,
  `thana` varchar(60) NOT NULL,
  `district` varchar(60) NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `union_code` varchar(10) NOT NULL,
  `upazila_code` varchar(10) NOT NULL,
  `email` varchar(60) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `web_link` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `setup_tbl` (`id`, `full_name`, `full_name_english`, `gram`, `thana`, `district`, `postal_code`, `union_code`, `upazila_code`, `email`, `mobile`, `phone`, `web_link`) VALUES ('1', '১০ নং সিধলা ইউনিয়ন পরিষদ', 'Sidhla Union Parishad', 'সিধলা', 'গৌরীপুর', 'ময়মনসিংহ', 'সানুড়া-২২০০', '6112385', '61123', 'sidhlauic10@gmail.com', '০১৯১৯৮০৮৭২০', '০১৯১৯৮০৮৭২০', 'www.localhost');


#
# TABLE STRUCTURE FOR: slide_setting
#

DROP TABLE IF EXISTS `slide_setting`;

CREATE TABLE `slide_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_name` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `sequence` smallint(5) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `slide_setting` (`id`, `image_name`, `title`, `description`, `sequence`, `status`) VALUES ('1', 'Comp_training.jpg', 'Sidhla union parishad', 'Digital union parishad', '2', '1');
INSERT INTO `slide_setting` (`id`, `image_name`, `title`, `description`, `sequence`, `status`) VALUES ('2', '10407321_1582787961933805_816617609461902714_n.jpg', 'Sidhla union parishad', 'Digital union parishad', '1', '1');


#
# TABLE STRUCTURE FOR: subctg
#

DROP TABLE IF EXISTS `subctg`;

CREATE TABLE `subctg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mc_id` int(11) NOT NULL,
  `sub_title` varchar(255) NOT NULL,
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('1', '6', 'অন্যান্য ফি', '762.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('2', '3', 'ট্রেড লাইসেন্স ফি', '19847.20');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('3', '1', 'বসতভিটার উপর কর', '4800.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('4', '1', 'ব্যবসা,পেশা ও জীবিকার উপর কর', '2034.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('5', '1', 'বিনোদন কর সিনেমা, যাত্রা, নাটক ও অন্যান্য', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('6', '2', 'হাটবাজার', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('7', '2', 'ফেরী ঘাট', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('8', '2', 'জলমহল', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('9', '2', 'অন্যান্য', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('10', '7', '১ম কিস্তি', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('11', '7', 'তৃতীয় কিস্তি', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('12', '8', 'চেয়ারম্যান ও সদস্যদের ভাতা', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('13', '8', 'সেক্রেটারী ও অন্যান্য কর্মচারীদের বেতন ও ভাতা', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('14', '9', 'কাবিখা', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('15', '9', 'টি আর', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('16', '9', 'এলজিএসপি', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('17', '9', 'অতিদরিদ্র কর্মসূচি', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('18', '9', 'থোক', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('19', '13', 'ভিজিডিও ভিজিএফ', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('20', '13', 'ব্যাংক জমা (এলজিএসপি)', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('21', '13', 'অন্যান্য', '0.00');
INSERT INTO `subctg` (`id`, `mc_id`, `sub_title`, `balance`) VALUES ('22', '14', 'udc fee', '500.00');


#
# TABLE STRUCTURE FOR: subctg_in_budget
#

DROP TABLE IF EXISTS `subctg_in_budget`;

CREATE TABLE `subctg_in_budget` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `actual_budget` decimal(10,2) NOT NULL DEFAULT '0.00',
  `budget_year` varchar(50) NOT NULL,
  `status` enum('1','2') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_assesment
#

DROP TABLE IF EXISTS `tbl_assesment`;

CREATE TABLE `tbl_assesment` (
  `assid` int(11) NOT NULL AUTO_INCREMENT,
  `hinfoid` int(11) NOT NULL,
  `htype_rate_id` int(11) NOT NULL,
  `ins_date` date NOT NULL,
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ins_user` varchar(60) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '0',
  PRIMARY KEY (`assid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_assesment` (`assid`, `hinfoid`, `htype_rate_id`, `ins_date`, `up_date`, `ins_user`, `status`) VALUES ('1', '1', '2', '2017-04-10', '2018-03-24 00:56:09', 'abs_rana', '1');
INSERT INTO `tbl_assesment` (`assid`, `hinfoid`, `htype_rate_id`, `ins_date`, `up_date`, `ins_user`, `status`) VALUES ('2', '2', '1', '2017-04-10', '2017-04-10 17:05:00', 'abs_rana', '1');
INSERT INTO `tbl_assesment` (`assid`, `hinfoid`, `htype_rate_id`, `ins_date`, `up_date`, `ins_user`, `status`) VALUES ('4', '3', '2', '2017-04-10', '2017-04-14 18:07:46', 'zia', '1');
INSERT INTO `tbl_assesment` (`assid`, `hinfoid`, `htype_rate_id`, `ins_date`, `up_date`, `ins_user`, `status`) VALUES ('5', '4', '1', '2017-04-14', '2017-04-14 18:07:37', 'zia', '1');


#
# TABLE STRUCTURE FOR: tbl_autistic
#

DROP TABLE IF EXISTS `tbl_autistic`;

CREATE TABLE `tbl_autistic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `national_id` varchar(20) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `insert_by` varchar(40) NOT NULL,
  `insert_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `national_id` (`national_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_autistic` (`id`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('1', '19950815000000006', '1', 'abs_rana', '2017-04-27 16:13:07');
INSERT INTO `tbl_autistic` (`id`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('2', '19950815000000007', '1', 'abs_rana', '2017-04-27 16:13:07');


#
# TABLE STRUCTURE FOR: tbl_autisticstudent
#

DROP TABLE IF EXISTS `tbl_autisticstudent`;

CREATE TABLE `tbl_autisticstudent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_name` varchar(60) NOT NULL,
  `national_id` varchar(20) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `insert_by` varchar(40) NOT NULL,
  `insert_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `national_id` (`national_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_autisticstudent` (`id`, `student_name`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('1', 'shikat', '19950815000000000', '1', 'abs_rana', '2017-04-27 16:13:52');
INSERT INTO `tbl_autisticstudent` (`id`, `student_name`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('4', 'ooo', '19950815000000007', '1', 'abs_rana', '2017-04-27 16:16:17');
INSERT INTO `tbl_autisticstudent` (`id`, `student_name`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('5', 'uuuuuu', '19950815000000005', '1', 'abs_rana', '2017-04-27 16:16:17');
INSERT INTO `tbl_autisticstudent` (`id`, `student_name`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('6', 'hhh', '19950815000000006', '1', 'abs_rana', '2017-04-27 16:49:22');


#
# TABLE STRUCTURE FOR: tbl_books
#

DROP TABLE IF EXISTS `tbl_books`;

CREATE TABLE `tbl_books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bno` int(11) NOT NULL DEFAULT '1',
  `fiscal_year` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('1', '1', '2016-2017');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('2', '2', '2016-2017');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('3', '3', '2016-2017');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('6', '4', '2016-2017');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('7', '5', '2017-2018');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('8', '6', '2017-2018');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('9', '12', '2017-2018');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('10', '13', '2017-2018');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('11', '14', '2017-2018');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('14', '15', '2017-2018');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('15', '16', '2017-2018');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('16', '16', '2017-2018');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('17', '17', '2017-2018');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('18', '18', '2017-2018');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('19', '0', '2017-2018');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('20', '19', '2017-2018');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('21', '20', '2017-2018');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('25', '21', '2017-2018');
INSERT INTO `tbl_books` (`id`, `bno`, `fiscal_year`) VALUES ('26', '21', '2017-2018');


#
# TABLE STRUCTURE FOR: tbl_fighters
#

DROP TABLE IF EXISTS `tbl_fighters`;

CREATE TABLE `tbl_fighters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `national_id` varchar(20) NOT NULL,
  `sector_no` varchar(10) NOT NULL,
  `life_history` text NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `insert_by` varchar(40) NOT NULL,
  `insert_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `national_id` (`national_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_fighters` (`id`, `national_id`, `sector_no`, `life_history`, `status`, `insert_by`, `insert_date`) VALUES ('1', '19950815000000000', '07', '<p>কবতকতবব</p>', '1', 'abs_rana', '2017-04-27 14:43:12');
INSERT INTO `tbl_fighters` (`id`, `national_id`, `sector_no`, `life_history`, `status`, `insert_by`, `insert_date`) VALUES ('2', '19950815000000004', '', '', '1', 'abs_rana', '2017-04-27 16:07:45');
INSERT INTO `tbl_fighters` (`id`, `national_id`, `sector_no`, `life_history`, `status`, `insert_by`, `insert_date`) VALUES ('3', '19950815000000001', '', '', '1', 'abs_rana', '2017-04-27 16:07:45');
INSERT INTO `tbl_fighters` (`id`, `national_id`, `sector_no`, `life_history`, `status`, `insert_by`, `insert_date`) VALUES ('4', '19950815000000002', '', '', '1', 'abs_rana', '2017-04-27 16:07:45');


#
# TABLE STRUCTURE FOR: tbl_foreignman
#

DROP TABLE IF EXISTS `tbl_foreignman`;

CREATE TABLE `tbl_foreignman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `national_id` varchar(20) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `insert_by` varchar(40) NOT NULL,
  `insert_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `national_id` (`national_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_foreignman` (`id`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('1', '19950815000000002', '1', 'abs_rana', '2017-04-27 16:12:24');
INSERT INTO `tbl_foreignman` (`id`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('2', '19950815000000000', '1', 'abs_rana', '2017-04-27 16:12:24');
INSERT INTO `tbl_foreignman` (`id`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('3', '19950815000000001', '1', 'abs_rana', '2017-04-27 16:12:24');


#
# TABLE STRUCTURE FOR: tbl_mother_vata
#

DROP TABLE IF EXISTS `tbl_mother_vata`;

CREATE TABLE `tbl_mother_vata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `national_id` varchar(20) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `insert_by` varchar(40) NOT NULL,
  `insert_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `national_id` (`national_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_mother_vata` (`id`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('1', '19950815000000009', '1', 'abs_rana', '2017-04-27 16:12:51');
INSERT INTO `tbl_mother_vata` (`id`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('2', '19950815000000005', '1', 'abs_rana', '2017-04-27 16:12:51');


#
# TABLE STRUCTURE FOR: tbl_news
#

DROP TABLE IF EXISTS `tbl_news`;

CREATE TABLE `tbl_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `descrip` text NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `entry_user` varchar(40) NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_news` (`id`, `title`, `descrip`, `status`, `entry_user`, `entry_date`) VALUES ('1', 'আজ ভিজিডি কার্ড বিতরণ করা হয়েছে ১০ নং সিধলা ইউনিয়ন', '<p><!-- [if gte mso 9]><xml>\r\n <w:WordDocument>\r\n  <w:View>Normal</w:View>\r\n  <w:Zoom>0</w:Zoom>\r\n  <w:PunctuationKerning/>\r\n  <w:ValidateAgainstSchemas/>\r\n  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>\r\n  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>\r\n  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>\r\n  <w:Compatibility>\r\n   <w:BreakWrappedTables/>\r\n   <w:SnapToGridInCell/>\r\n   <w:WrapTextWithPunct/>\r\n   <w:UseAsianBreakRules/>\r\n   <w:DontGrowAutofit/>\r\n  </w:Compatibility>\r\n  <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel>\r\n </w:WordDocument>\r\n</xml><![endif]--></p>\r\n<p><!-- [if gte mso 9]><xml>\r\n <w:LatentStyles DefLockedState=\"false\" LatentStyleCount=\"156\">\r\n </w:LatentStyles>\r\n</xml><![endif]--><!-- [if gte mso 10]>\r\n<style>\r\n /* Style Definitions */\r\n table.MsoNormalTable\r\n	{mso-style-name:\"Table Normal\";\r\n	mso-tstyle-rowband-size:0;\r\n	mso-tstyle-colband-size:0;\r\n	mso-style-noshow:yes;\r\n	mso-style-parent:\"\";\r\n	mso-padding-alt:0in 5.4pt 0in 5.4pt;\r\n	mso-para-margin:0in;\r\n	mso-para-margin-bottom:.0001pt;\r\n	mso-pagination:widow-orphan;\r\n	font-size:10.0pt;\r\n	font-family:\"Times New Roman\";\r\n	mso-ansi-language:#0400;\r\n	mso-fareast-language:#0400;\r\n	mso-bidi-language:#0400;}\r\ntable.MsoTableGrid\r\n	{mso-style-name:\"Table Grid\";\r\n	mso-tstyle-rowband-size:0;\r\n	mso-tstyle-colband-size:0;\r\n	border:solid windowtext 1.0pt;\r\n	mso-border-alt:solid windowtext .5pt;\r\n	mso-padding-alt:0in 5.4pt 0in 5.4pt;\r\n	mso-border-insideh:.5pt solid windowtext;\r\n	mso-border-insidev:.5pt solid windowtext;\r\n	mso-para-margin:0in;\r\n	mso-para-margin-bottom:.0001pt;\r\n	mso-pagination:widow-orphan;\r\n	font-size:10.0pt;\r\n	font-family:\"Times New Roman\";\r\n	mso-ansi-language:#0400;\r\n	mso-fareast-language:#0400;\r\n	mso-bidi-language:#0400;}\r\n</style>\r\n<![endif]--></p>\r\n<p class=\"MsoNormal\" style=\"text-align: center;\" align=\"center\"><span style=\"font-size: 14.0pt; font-family: SutonnyMJ;\">wfwRwW Kg©m~wPi Rb¨ DcKvi‡fvMx gwnjv wbe©vP‡bi ZvwjKvi PzovšÍ QK</span></p>\r\n<p class=\"MsoNormal\" style=\"text-align: center;\" align=\"center\"><span style=\"font-family: SutonnyMJ;\">wfwRwW Pµ-2017-2018</span></p>\r\n<p class=\"MsoNormal\" style=\"text-align: center;\" align=\"center\"><span style=\"font-family: SutonnyMJ;\">BDwbqb t 10bs wmajv Dc‡Rjv-‡MŠixcyi,‡Rjv-gqgbwmsn</span></p>\r\n<table class=\"MsoTableGrid\" style=\"border-collapse: collapse; mso-table-layout-alt: fixed; border: none; mso-border-alt: solid windowtext .5pt; mso-yfti-tbllook: 480; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext;\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr style=\"mso-yfti-irow: 0; mso-yfti-firstrow: yes;\">\r\n<td style=\"width: .7in; border: solid windowtext 1.0pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"67\">\r\n<p class=\"MsoNormal\" style=\"text-align: center;\" align=\"center\"><span style=\"font-family: SutonnyMJ;\">µwgK bs</span></p>\r\n</td>\r\n<td style=\"width: 117.0pt; border: solid windowtext 1.0pt; border-left: none; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\" style=\"text-align: center;\" align=\"center\"><span style=\"font-family: SutonnyMJ;\">wfwRwW gwnjvi bvg</span></p>\r\n</td>\r\n<td style=\"width: 70.15pt; border: solid windowtext 1.0pt; border-left: none; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"94\">\r\n<p class=\"MsoNormal\" style=\"text-align: center;\" align=\"center\"><span style=\"font-family: SutonnyMJ;\">eqm</span></p>\r\n</td>\r\n<td style=\"width: 117.0pt; border: solid windowtext 1.0pt; border-left: none; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\" style=\"text-align: center;\" align=\"center\"><span style=\"font-family: SutonnyMJ;\">RvZxq cwiPq cÎ b¤^i</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border: solid windowtext 1.0pt; border-left: none; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\" style=\"text-align: center;\" align=\"center\"><span style=\"font-family: SutonnyMJ;\">wcZv,¯^vgx A_ev Awffve‡Ki bvg</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border: solid windowtext 1.0pt; border-left: none; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\" style=\"text-align: center;\" align=\"center\"><span style=\"font-family: SutonnyMJ;\">gvZvi bvg</span></p>\r\n</td>\r\n<td style=\"width: 63.85pt; border: solid windowtext 1.0pt; border-left: none; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"85\">\r\n<p class=\"MsoNormal\" style=\"text-align: center;\" align=\"center\"><span style=\"font-family: SutonnyMJ;\">cwiev‡i m`m¨ msL¨v</span></p>\r\n</td>\r\n<td style=\"width: 45.0pt; border: solid windowtext 1.0pt; border-left: none; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"60\">\r\n<p class=\"MsoNormal\" style=\"text-align: center;\" align=\"center\"><span style=\"font-family: SutonnyMJ;\">IqvW© bs </span></p>\r\n</td>\r\n<td style=\"width: 71.15pt; border: solid windowtext 1.0pt; border-left: none; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"95\">\r\n<p class=\"MsoNormal\" style=\"text-align: center;\" align=\"center\"><span style=\"font-family: SutonnyMJ;\">MÖvg</span></p>\r\n</td>\r\n<td style=\"width: 72.1pt; border: solid windowtext 1.0pt; border-left: none; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"96\">\r\n<p class=\"MsoNormal\" style=\"text-align: center;\" align=\"center\"><span style=\"font-family: SutonnyMJ;\">cvov/gnjøv</span></p>\r\n</td>\r\n<td style=\"width: 62.05pt; border: solid windowtext 1.0pt; border-left: none; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"83\">\r\n<p class=\"MsoNormal\" style=\"text-align: center;\" align=\"center\"><span style=\"font-family: SutonnyMJ;\">gšÍe¨</span></p>\r\n</td>\r\n</tr>\r\n<tr style=\"mso-yfti-irow: 1;\">\r\n<td style=\"width: .7in; border: solid windowtext 1.0pt; border-top: none; mso-border-top-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"67\">\r\n<ol style=\"margin-top: 0in;\" start=\"1\" type=\"1\">\r\n<li class=\"MsoNormal\" style=\"text-align: center; mso-list: l1 level1 lfo2; tab-stops: list .5in;\"><span style=\"font-family: SutonnyMJ;\"> </span></li>\r\n</ol>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gvQv t nv‡Riv LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 70.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"94\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">05/06/1980</span></p>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">6112385876756</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">Avjx AvKivg gÛj</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gvQv t Qv‡jgv LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 63.85pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"85\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">5</span></p>\r\n</td>\r\n<td style=\"width: 45.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"60\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">1</span></p>\r\n</td>\r\n<td style=\"width: 71.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"95\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">KvKzivKv›`v</span></p>\r\n</td>\r\n<td style=\"width: 72.1pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"96\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n<td style=\"width: 62.05pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"83\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n</tr>\r\n<tr style=\"mso-yfti-irow: 2;\">\r\n<td style=\"width: .7in; border: solid windowtext 1.0pt; border-top: none; mso-border-top-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"67\">\r\n<ol style=\"margin-top: 0in;\" start=\"2\" type=\"1\">\r\n<li class=\"MsoNormal\" style=\"text-align: center; mso-list: l1 level1 lfo2; tab-stops: list .5in;\"><span style=\"font-family: SutonnyMJ;\"> </span></li>\r\n</ol>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gvQv: mv‡R`v LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 70.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"94\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">2/2/1983</span></p>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">6112385875397</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gv: Ry‡qj wgqv</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gvQv: mwLbv LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 63.85pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"85\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">5</span></p>\r\n</td>\r\n<td style=\"width: 45.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"60\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">1</span></p>\r\n</td>\r\n<td style=\"width: 71.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"95\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">cybywiqv</span></p>\r\n</td>\r\n<td style=\"width: 72.1pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"96\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n<td style=\"width: 62.05pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"83\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n</tr>\r\n<tr style=\"mso-yfti-irow: 3;\">\r\n<td style=\"width: .7in; border: solid windowtext 1.0pt; border-top: none; mso-border-top-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"67\">\r\n<ol style=\"margin-top: 0in;\" start=\"3\" type=\"1\">\r\n<li class=\"MsoNormal\" style=\"text-align: center; mso-list: l1 level1 lfo2; tab-stops: list .5in;\"><span style=\"font-family: SutonnyMJ;\"> </span></li>\r\n</ol>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gvQv t gw`bv LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 70.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"94\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">03/03/1984</span></p>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">6112385875393</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gv t nvweeyi ingvb</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">AvwQqv LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 63.85pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"85\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">4</span></p>\r\n</td>\r\n<td style=\"width: 45.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"60\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">1</span></p>\r\n</td>\r\n<td style=\"width: 71.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"95\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">cybywiqv</span></p>\r\n</td>\r\n<td style=\"width: 72.1pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"96\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n<td style=\"width: 62.05pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"83\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n</tr>\r\n<tr style=\"mso-yfti-irow: 4;\">\r\n<td style=\"width: .7in; border: solid windowtext 1.0pt; border-top: none; mso-border-top-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"67\">\r\n<ol style=\"margin-top: 0in;\" start=\"4\" type=\"1\">\r\n<li class=\"MsoNormal\" style=\"text-align: center; mso-list: l1 level1 lfo2; tab-stops: list .5in;\"><span style=\"font-family: SutonnyMJ;\"> </span></li>\r\n</ol>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gvQv t Qvwebv LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 70.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"94\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">05/02/1984</span></p>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">6112385875208</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">gy¯Ídv</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">Av‡bvqviv LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 63.85pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"85\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">6</span></p>\r\n</td>\r\n<td style=\"width: 45.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"60\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">1</span></p>\r\n</td>\r\n<td style=\"width: 71.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"95\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">cybywiqv</span></p>\r\n</td>\r\n<td style=\"width: 72.1pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"96\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n<td style=\"width: 62.05pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"83\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n</tr>\r\n<tr style=\"mso-yfti-irow: 5;\">\r\n<td style=\"width: .7in; border: solid windowtext 1.0pt; border-top: none; mso-border-top-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"67\">\r\n<ol style=\"margin-top: 0in;\" start=\"5\" type=\"1\">\r\n<li class=\"MsoNormal\" style=\"text-align: center; mso-list: l1 level1 lfo2; tab-stops: list .5in;\"><span style=\"font-family: SutonnyMJ;\"> </span></li>\r\n</ol>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gvQv: ‡Rvmbv</span></p>\r\n</td>\r\n<td style=\"width: 70.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"94\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">2/2/1974</span></p>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">6112385875403</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gv: nvwmg DwÏb</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">g„Z Ry‡e`v LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 63.85pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"85\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">6</span></p>\r\n</td>\r\n<td style=\"width: 45.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"60\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">1</span></p>\r\n</td>\r\n<td style=\"width: 71.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"95\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">cybyiwqv</span></p>\r\n</td>\r\n<td style=\"width: 72.1pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"96\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n<td style=\"width: 62.05pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"83\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n</tr>\r\n<tr style=\"mso-yfti-irow: 6;\">\r\n<td style=\"width: .7in; border: solid windowtext 1.0pt; border-top: none; mso-border-top-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"67\">\r\n<ol style=\"margin-top: 0in;\" start=\"6\" type=\"1\">\r\n<li class=\"MsoNormal\" style=\"text-align: center; mso-list: l1 level1 lfo2; tab-stops: list .5in;\"><span style=\"font-family: SutonnyMJ;\"> </span></li>\r\n</ol>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gvQv t gv‡R`v LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 70.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"94\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">08/03/1972</span></p>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">6112385876155</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">wmivR DwÏb</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">nv‡Riv LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 63.85pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"85\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">5</span></p>\r\n</td>\r\n<td style=\"width: 45.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"60\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">1</span></p>\r\n</td>\r\n<td style=\"width: 71.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"95\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">axZcyi</span></p>\r\n</td>\r\n<td style=\"width: 72.1pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"96\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n<td style=\"width: 62.05pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"83\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n</tr>\r\n<tr style=\"mso-yfti-irow: 7;\">\r\n<td style=\"width: .7in; border: solid windowtext 1.0pt; border-top: none; mso-border-top-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"67\">\r\n<ol style=\"margin-top: 0in;\" start=\"7\" type=\"1\">\r\n<li class=\"MsoNormal\" style=\"text-align: center; mso-list: l1 level1 lfo2; tab-stops: list .5in;\"><span style=\"font-family: SutonnyMJ;\"> </span></li>\r\n</ol>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gvQv t dviRvbv Av³vi gwb</span></p>\r\n</td>\r\n<td style=\"width: 70.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"94\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">15/04/1990</span></p>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">6112385000212</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">eveyj wgqv</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">wdiæRv LvZz„b</span></p>\r\n</td>\r\n<td style=\"width: 63.85pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"85\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">4</span></p>\r\n</td>\r\n<td style=\"width: 45.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"60\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">1</span></p>\r\n</td>\r\n<td style=\"width: 71.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"95\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">axZcyi</span></p>\r\n</td>\r\n<td style=\"width: 72.1pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"96\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n<td style=\"width: 62.05pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"83\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n</tr>\r\n<tr style=\"mso-yfti-irow: 8;\">\r\n<td style=\"width: .7in; border: solid windowtext 1.0pt; border-top: none; mso-border-top-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"67\">\r\n<ol style=\"margin-top: 0in;\" start=\"8\" type=\"1\">\r\n<li class=\"MsoNormal\" style=\"text-align: center; mso-list: l1 level1 lfo2; tab-stops: list .5in;\"><span style=\"font-family: SutonnyMJ;\"> </span></li>\r\n</ol>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gvQv tD‡¤§ KyjPzg</span></p>\r\n</td>\r\n<td style=\"width: 70.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"94\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">22/09/1976</span></p>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">6112385875668</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">mv‡n` Avjx</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">Av‡qkv LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 63.85pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"85\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">5</span></p>\r\n</td>\r\n<td style=\"width: 45.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"60\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">1</span></p>\r\n</td>\r\n<td style=\"width: 71.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"95\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">axZcyi</span></p>\r\n</td>\r\n<td style=\"width: 72.1pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"96\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n<td style=\"width: 62.05pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"83\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n</tr>\r\n<tr style=\"mso-yfti-irow: 9;\">\r\n<td style=\"width: .7in; border: solid windowtext 1.0pt; border-top: none; mso-border-top-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"67\">\r\n<ol style=\"margin-top: 0in;\" start=\"9\" type=\"1\">\r\n<li class=\"MsoNormal\" style=\"text-align: center; mso-list: l1 level1 lfo2; tab-stops: list .5in;\"><span style=\"font-family: SutonnyMJ;\"> </span></li>\r\n</ol>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gvQv t bvRgv LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 70.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"94\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">04/01/1979</span></p>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">6112385875666</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">kwn` wgqv</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡Lv‡`Rv LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 63.85pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"85\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">5</span></p>\r\n</td>\r\n<td style=\"width: 45.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"60\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">1</span></p>\r\n</td>\r\n<td style=\"width: 71.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"95\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">axZcyi</span></p>\r\n</td>\r\n<td style=\"width: 72.1pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"96\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n<td style=\"width: 62.05pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"83\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n</tr>\r\n<tr style=\"mso-yfti-irow: 10;\">\r\n<td style=\"width: .7in; border: solid windowtext 1.0pt; border-top: none; mso-border-top-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"67\">\r\n<ol style=\"margin-top: 0in;\" start=\"10\" type=\"1\">\r\n<li class=\"MsoNormal\" style=\"text-align: center; mso-list: l1 level1 lfo2; tab-stops: list .5in;\"><span style=\"font-family: SutonnyMJ;\"> </span></li>\r\n</ol>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gvQv t AvQgv</span></p>\r\n</td>\r\n<td style=\"width: 70.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"94\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">27/04/1983</span></p>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">6112385875639</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">Avj Avwgb</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">dv‡Zgv</span></p>\r\n</td>\r\n<td style=\"width: 63.85pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"85\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">5</span></p>\r\n</td>\r\n<td style=\"width: 45.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"60\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">1</span></p>\r\n</td>\r\n<td style=\"width: 71.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"95\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">axZcyi</span></p>\r\n</td>\r\n<td style=\"width: 72.1pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"96\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n<td style=\"width: 62.05pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"83\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n</tr>\r\n<tr style=\"mso-yfti-irow: 11;\">\r\n<td style=\"width: .7in; border: solid windowtext 1.0pt; border-top: none; mso-border-top-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"67\">\r\n<ol style=\"margin-top: 0in;\" start=\"11\" type=\"1\">\r\n<li class=\"MsoNormal\" style=\"text-align: center; mso-list: l1 level1 lfo2; tab-stops: list .5in;\"><span style=\"font-family: SutonnyMJ;\"> </span></li>\r\n</ol>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gvQv t dv‡Zgv LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 70.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"94\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">01/02/1968</span></p>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">6112385877016</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gvt KwQg DwÏb</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">Lywk †eMg</span></p>\r\n</td>\r\n<td style=\"width: 63.85pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"85\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">5</span></p>\r\n</td>\r\n<td style=\"width: 45.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"60\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">2</span></p>\r\n</td>\r\n<td style=\"width: 71.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"95\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">nvmbcyi</span></p>\r\n</td>\r\n<td style=\"width: 72.1pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"96\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n<td style=\"width: 62.05pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"83\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n</tr>\r\n<tr style=\"mso-yfti-irow: 12;\">\r\n<td style=\"width: .7in; border: solid windowtext 1.0pt; border-top: none; mso-border-top-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"67\">\r\n<ol style=\"margin-top: 0in;\" start=\"12\" type=\"1\">\r\n<li class=\"MsoNormal\" style=\"text-align: center; mso-list: l1 level1 lfo2; tab-stops: list .5in;\"><span style=\"font-family: SutonnyMJ;\"> </span></li>\r\n</ol>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gvQv: dwi`v LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 70.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"94\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">3/©8/1975</span></p>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">6112385877496</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gv: Avãyj Mdzi Zvs</span></p>\r\n</td>\r\n<td style=\"width: 1.75in; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"168\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">g„Z nvwj‡ki gv</span></p>\r\n</td>\r\n<td style=\"width: 63.85pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"85\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">4</span></p>\r\n</td>\r\n<td style=\"width: 45.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"60\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">2</span></p>\r\n</td>\r\n<td style=\"width: 71.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"95\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">nvmbcyi</span></p>\r\n</td>\r\n<td style=\"width: 72.1pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"96\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n<td style=\"width: 62.05pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"83\">\r\n<p class=\"MsoNormal\"><span style=\"font-family: SutonnyMJ;\"> </span></p>\r\n</td>\r\n</tr>\r\n<tr style=\"mso-yfti-irow: 13;\">\r\n<td style=\"width: .7in; border: solid windowtext 1.0pt; border-top: none; mso-border-top-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"67\">\r\n<ol style=\"margin-top: 0in;\" start=\"13\" type=\"1\">\r\n<li class=\"MsoNormal\" style=\"text-align: center; mso-list: l1 level1 lfo2; tab-stops: list .5in;\"><span style=\"font-family: SutonnyMJ;\"> </span></li>\r\n</ol>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"156\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">‡gvQv t AvwQqv LvZzb</span></p>\r\n</td>\r\n<td style=\"width: 70.15pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt;\" valign=\"top\" width=\"94\">\r\n<p class=\"MsoNormal\"><span style=\"font-size: 11.0pt; font-family: SutonnyMJ;\">10/02/1972</span></p>\r\n</td>\r\n<td style=\"width: 117.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; mso-border-top-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtex', '0', 'zia1', '2017-03-16 21:17:35');
INSERT INTO `tbl_news` (`id`, `title`, `descrip`, `status`, `entry_user`, `entry_date`) VALUES ('2', '‘উন্নয়নের গণতন্ত্র, শেখ হাসিনার মূলমন্ত্র’’, ‘‘শেখ হাসিনার দর্শন, বাংলাদেশের উন্নয়ন”, ‘‘শেখ হাসিনার', '<h3>&lsquo;&lsquo;উন্নয়নের গণতন্ত্র, শেখ হাসিনার মূলমন্ত্র&rsquo;&rsquo;, &lsquo;&lsquo;শেখ হাসিনার দর্শন, বাংলাদেশের উন্নয়ন&rdquo;, &lsquo;&lsquo;শেখ হাসিনার দর্শন সব মানুষের উন্নয়ন&rdquo; --**--**-- ** সময়মত সিধলা ইউনিয়ন পরিষদের &nbsp;কর পরিশোধ করে ইউনিয়ন&nbsp;উন্নয়নে সহায়তা করুন। --**--**--**-- ** মাদক মুক্ত ইউনিয়ন&nbsp;গড়ি। --**--**-- ** আপনার মালিকানাধীন পুকুর/ডোবা/জলাশয় মশক নিয়ন্ত্রনের বৃহত্তর স্বার্থে কচুরীপানা/আবর্জনা মুক্ত রাখুন। --**--**-- ** নির্ধারিত স্থানে ময়লা ফেলুন ছাড়া যত্রতত্র ময়লা/আবর্জনা ফেলবেন না । --**--**-- ** নির্মান সামগ্রী/রাবিশ/মাটি ইত্যাদি রাস্তা/ফুটপাতে রেখে এলাকা অপরিচ্ছন্ন ও জনসাধারনের চলাচলে অসুবিধা সৃষ্টি করবেন না। --**--**-- ** নর্দমায় আবর্জনা/মাটি/বালু ইত্যাদি ফেলবেন না। --**--**-- ** ধুমপান ও তামাক স্বাস্থ্যের জন্য মারাত্মক ক্ষতিকর, ধুমপান ও তামাক ছাড়ুন,সুস্থ থাকুন। --**--**-- ** মাদক সেবন আপনার, আপনার পরিবার ও সমাজের ক্ষতি করে, মাদককে না বলি ও মাদকমুক্ত সমাজ গড়ি</h3>', '1', 'zia', '2017-03-17 10:09:00');
INSERT INTO `tbl_news` (`id`, `title`, `descrip`, `status`, `entry_user`, `entry_date`) VALUES ('3', 'সিধলা ইউনিয়নের ইতিহাস', '', '1', 'zia', '2017-03-21 17:53:59');
INSERT INTO `tbl_news` (`id`, `title`, `descrip`, `status`, `entry_user`, `entry_date`) VALUES ('4', 'ময়মনসিংহ জেলা প্রশাসনের উদ্দ্যোগে আগামী ৯,১০,১১ ইং তারিখ উন্নয়ন মেলা অনুষ্টিত হবে উক্ত মেলায় স্থানীয় সরকারের পক্ষে স্টল বরাদ্দ থাকবে ।', '<p>ময়মনসিংহ জেলা প্রশাসনের উদ্দ্যোগে আগামী ৯,১০,১১ ইং তারিখ উন্নয়ন মেলা অনুষ্টিত হবে উক্ত মেলায় স্থানীয় সরকারের পক্ষে স্টল বরাদ্দ থাকবে ।স্টল গুলো ইউনিয়ন পরিষদের উদ্দ্যোক্তা ও সচিবদের সহযোগীতায় পরিচালিত হবে ।</p>', '0', 'zia', '2017-03-21 17:57:46');
INSERT INTO `tbl_news` (`id`, `title`, `descrip`, `status`, `entry_user`, `entry_date`) VALUES ('5', 'মো: জয়নাল আবেদীন পরপর তিন বার চেয়ারম্যান নির্বাচিত', '<div>১০ নং সিধলা পরিষদ নির্বাচন ২০১৬ তে পর পর নির্বাচিত হয়েছেন আলহাজ্ব মো: জয়নাল আবেদীন সাহেব ।এলাকার উন্নয়ন মূলক কাজের জন্য সিধলা বাসী থাকে পরপর তিন নির্বাচিত করেছেন ্ তাছাড়া এলাকার ছোট বড় সকল ধরনের সমস্যা সখানীয় ভাবে সমাধান করায় এলাকায তার বিশেষ সুনাম আছে ।</div>\r\n<p>&nbsp;</p>', '0', 'zia', '2017-03-21 17:56:11');
INSERT INTO `tbl_news` (`id`, `title`, `descrip`, `status`, `entry_user`, `entry_date`) VALUES ('6', '‘‘উন্নয়নের গণতন্ত্র, শেখ হাসিনার মূলমন্ত্র’’, ‘‘শেখ হাসিনার দর্শন, বাংলাদেশের উন্নয়ন”, ‘‘শেখ হাসিনার', '<h3 style=\"text-align: left;\">&lsquo;&lsquo;উন্নয়নের গণতন্ত্র, শেখ হাসিনার মূলমন্ত্র&rsquo;&rsquo;, &lsquo;&lsquo;শেখ হাসিনার দর্শন, বাংলাদেশের উন্নয়ন&rdquo;, &lsquo;&lsquo;শেখ হাসিনার দর্শন সব মানুষের উন্নয়ন&rdquo; --**--**-- ** সময়মত দনিয়া ইউনিয়ন পরিষদের &nbsp;কর পরিশোধ করে ইউনিয়ন&nbsp;উন্নয়নে সহায়তা করুন। --**--**--**-- ** মশক মুক্ত ইউনিয়ন&nbsp;গড়ি। --**--**-- ** আপনার মালিকানাধীন পুকুর/ডোবা/জলাশয় মশক নিয়ন্ত্রনের বৃহত্তর স্বার্থে কচুরীপানা/আবর্জনা মুক্ত রাখুন। --**--**-- ** নির্ধারিত স্থানে ময়লা ফেলুন ছাড়া যত্রতত্র ময়লা/আবর্জনা ফেলবেন না । --**--**-- ** নির্মান সামগ্রী/রাবিশ/মাটি ইত্যাদি রাস্তা/ফুটপাতে রেখে এলাকা অপরিচ্ছন্ন ও জনসাধারনের চলাচলে অসুবিধা সৃষ্টি করবেন না। --**--**-- ** নর্দমায় আবর্জনা/মাটি/বালু ইত্যাদি ফেলবেন না। --**--**-- ** ধুমপান ও তামাক স্বাস্থ্যের জন্য মারাত্মক ক্ষতিকর, ধুমপান ও তামাক ছাড়ুন,সুস্থ থাকুন। --**--**-- ** মাদক সেবন আপনার, আপনার পরিবার ও সমাজের ক্ষতি করে, মাদককে না বলি ও মাদকমুক্ত সমাজ গড়ি</h3>', '1', 'zia', '2017-03-21 18:01:46');


#
# TABLE STRUCTURE FOR: tbl_oldmanstipend
#

DROP TABLE IF EXISTS `tbl_oldmanstipend`;

CREATE TABLE `tbl_oldmanstipend` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `national_id` varchar(20) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `insert_by` varchar(40) NOT NULL,
  `insert_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `national_id` (`national_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_oldmanstipend` (`id`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('1', '19950815000000008', '1', 'abs_rana', '2017-04-27 16:12:35');


#
# TABLE STRUCTURE FOR: tbl_poormans
#

DROP TABLE IF EXISTS `tbl_poormans`;

CREATE TABLE `tbl_poormans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `national_id` varchar(20) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `insert_by` varchar(40) NOT NULL,
  `insert_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `national_id` (`national_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_poormans` (`id`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('1', '19950815000000004', '1', 'abs_rana', '2017-04-27 16:08:31');
INSERT INTO `tbl_poormans` (`id`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('2', '19950815000000001', '1', 'abs_rana', '2017-04-27 16:08:31');
INSERT INTO `tbl_poormans` (`id`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('3', '19950815000000006', '1', 'abs_rana', '2017-04-27 16:08:32');
INSERT INTO `tbl_poormans` (`id`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('4', '19950815000000007', '1', 'abs_rana', '2017-04-27 16:08:32');


#
# TABLE STRUCTURE FOR: tbl_tracking
#

DROP TABLE IF EXISTS `tbl_tracking`;

CREATE TABLE `tbl_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trackid` varchar(8) NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trackid` (`trackid`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('1', '113917', '2017-03-15 15:42:20');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('2', '933846', '2017-03-15 15:42:20');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('3', '267550', '2017-03-15 15:42:20');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('4', '647854', '2017-03-15 15:42:20');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('5', '051334', '2017-03-15 15:42:20');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('6', '546207', '2017-03-15 15:42:20');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('7', '170409', '2017-03-15 15:42:20');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('8', '569345', '2017-03-15 15:42:20');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('9', '024245', '2017-03-15 15:42:20');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('10', '532217', '2017-03-15 15:42:20');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('11', '126339', '2017-03-15 15:42:20');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('12', '211830', '2017-03-15 15:42:20');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('13', '625696', '2017-03-15 15:42:20');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('14', '812617', '2017-03-15 15:42:20');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('15', '780019', '2017-03-15 15:42:20');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('16', '564239', '2017-03-15 15:44:21');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('17', '486068', '2017-03-15 15:44:21');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('18', '043852', '2017-03-15 15:44:21');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('19', '371734', '2017-03-15 15:44:21');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('20', '580293', '2017-03-15 15:44:21');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('21', '425464', '2017-03-15 15:44:21');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('22', '774205', '2017-03-15 15:44:21');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('23', '085840', '2017-03-15 15:44:21');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('24', '287205', '2017-03-15 15:44:21');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('25', '334901', '2017-03-15 15:52:23');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('26', '324714', '2017-03-15 15:53:50');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('27', '942343', '2017-03-15 15:53:50');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('28', '192690', '2017-03-15 15:54:08');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('29', '212261', '2017-03-16 12:55:32');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('32', '958390', '2017-03-16 13:03:19');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('33', '323250', '2017-03-16 13:34:29');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('34', '916051', '2017-03-16 13:35:35');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('35', '161129', '2017-03-21 14:29:47');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('36', '171298', '2017-03-21 17:28:46');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('37', '836258', '2017-03-21 18:09:31');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('38', '546400', '2017-03-21 18:16:05');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('39', '596573', '2017-03-21 18:17:33');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('40', '629169', '2017-03-21 18:34:23');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('41', '167991', '2017-04-12 16:51:02');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('42', '957297', '2017-04-12 17:45:43');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('43', '106145', '2017-04-12 17:47:26');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('44', '746597', '2017-04-12 17:49:09');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('45', '515677', '2017-04-12 17:53:15');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('46', '360038', '2017-04-12 18:00:50');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('47', '482712', '2017-04-12 19:57:31');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('48', '380966', '2017-04-12 21:10:30');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('49', '752086', '2017-04-12 21:13:18');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('50', '114422', '2017-04-13 13:35:42');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('51', '924576', '2017-04-13 13:38:04');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('52', '099405', '2017-04-13 20:31:27');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('53', '611092', '2017-04-13 22:16:43');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('54', '451431', '2017-04-13 22:22:29');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('55', '964360', '2017-04-13 22:27:34');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('56', '279293', '2017-04-13 22:32:55');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('57', '088711', '2017-04-14 13:47:16');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('58', '878895', '2017-04-14 13:47:50');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('59', '102755', '2017-04-14 14:58:21');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('60', '521140', '2017-04-14 15:27:44');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('61', '781763', '2017-04-14 15:30:31');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('62', '601895', '2017-04-14 15:32:38');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('63', '890857', '2017-04-14 15:36:52');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('64', '084345', '2017-04-14 15:39:43');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('65', '831143', '2017-04-14 21:17:29');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('66', '968655', '2017-04-18 16:02:10');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('67', '071256', '2017-04-18 16:25:18');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('68', '396612', '2017-05-09 21:26:50');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('69', '005129', '2017-05-09 21:37:19');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('70', '197136', '2017-05-09 21:39:15');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('71', '063838', '2017-05-09 21:41:40');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('72', '559652', '2017-05-09 21:44:39');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('73', '289246', '2017-05-09 21:45:19');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('74', '004659', '2017-05-09 21:45:29');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('75', '463621', '2017-05-09 21:51:00');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('76', '202539', '2017-05-09 21:52:40');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('77', '055913', '2017-05-09 21:52:57');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('78', '588412', '2017-05-09 21:59:23');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('79', '784686', '2017-05-09 21:59:39');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('80', '379087', '2017-05-09 21:59:57');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('81', '812141', '2017-05-09 22:00:14');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('82', '324713', '2017-05-09 22:01:24');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('83', '433196', '2017-05-09 22:02:56');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('84', '139110', '2017-05-09 22:03:42');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('85', '216073', '2017-05-09 22:05:24');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('86', '876717', '2017-05-09 22:08:00');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('87', '463982', '2017-05-09 22:39:59');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('88', '678061', '2017-05-09 22:47:20');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('89', '744122', '2017-05-09 22:48:24');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('90', '898083', '2017-12-10 23:43:25');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('91', '767930', '2017-12-10 23:44:31');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('92', '860038', '2017-12-10 23:50:56');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('93', '083808', '2017-12-10 23:51:31');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('94', '842728', '2017-12-10 23:52:04');
INSERT INTO `tbl_tracking` (`id`, `trackid`, `utime`) VALUES ('95', '142753', '2017-12-10 23:52:38');


#
# TABLE STRUCTURE FOR: tbl_upmember
#

DROP TABLE IF EXISTS `tbl_upmember`;

CREATE TABLE `tbl_upmember` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(60) NOT NULL,
  `n_id` varchar(20) NOT NULL,
  `designation` tinyint(4) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `mobile` varchar(11) NOT NULL,
  `email` varchar(60) NOT NULL,
  `dofb` date NOT NULL,
  `mstatus` tinyint(3) NOT NULL,
  `district` varchar(60) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `joindate` date NOT NULL,
  `barea` varchar(120) NOT NULL,
  `vno` varchar(10) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `update_by` varchar(40) NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `n_id` (`n_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_upmember` (`id`, `full_name`, `n_id`, `designation`, `status`, `mobile`, `email`, `dofb`, `mstatus`, `district`, `qualification`, `joindate`, `barea`, `vno`, `pic`, `update_by`, `utime`) VALUES ('1', 'মো: জিয়াউর রহমান', '১৯৮৭৬১১২৩৮৫০০০০৪8', '4', '1', '01919808720', 'sidhlauic10@gmail.com', '2017-04-10', '1', 'ময়মনসিংহq', 'এস এস সিq', '2017-04-23', '', '', 'images (2).jpg', '', '2017-04-27 17:51:11');
INSERT INTO `tbl_upmember` (`id`, `full_name`, `n_id`, `designation`, `status`, `mobile`, `email`, `dofb`, `mstatus`, `district`, `qualification`, `joindate`, `barea`, `vno`, `pic`, `update_by`, `utime`) VALUES ('2', 'মো: লিটন মিয়া', '', '2', '1', '01959168743', 'litonmia1@gmail.com', '1970-01-01', '1', 'ময়মনসিংহ', 'এম.এসসি (গণিত) প্রথম শ্রেণি', '1970-01-01', '', '', 'images (5).jpg', '', '2017-04-27 17:52:19');
INSERT INTO `tbl_upmember` (`id`, `full_name`, `n_id`, `designation`, `status`, `mobile`, `email`, `dofb`, `mstatus`, `district`, `qualification`, `joindate`, `barea`, `vno`, `pic`, `update_by`, `utime`) VALUES ('3', 'মো: জয়নাল আবেদীন', '৬১১২৩৮৫৮৮৮৬৭৮', '1', '1', '01712133682', '', '1970-01-01', '1', 'ময়মনসিংহ', '', '1970-01-01', '', '', 'images (6).jpg', '', '2017-04-27 17:52:55');


#
# TABLE STRUCTURE FOR: tbl_voter_list
#

DROP TABLE IF EXISTS `tbl_voter_list`;

CREATE TABLE `tbl_voter_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `national_id` varchar(20) NOT NULL,
  `upazila_code` varchar(10) NOT NULL,
  `union_code` varchar(10) NOT NULL,
  `bangla_name` varchar(100) NOT NULL,
  `english_name` varchar(60) NOT NULL,
  `father_name` varchar(80) NOT NULL,
  `mother_name` varchar(80) NOT NULL,
  `date_of_birth` date NOT NULL,
  `basha` varchar(60) NOT NULL,
  `gram` varchar(60) NOT NULL,
  `word_no` varchar(10) NOT NULL,
  `post_office` varchar(60) NOT NULL,
  `upzilla` varchar(60) NOT NULL,
  `district` varchar(60) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `insert_by` varchar(40) NOT NULL,
  `insert_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `national_id` (`national_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_voter_list` (`id`, `national_id`, `upazila_code`, `union_code`, `bangla_name`, `english_name`, `father_name`, `mother_name`, `date_of_birth`, `basha`, `gram`, `word_no`, `post_office`, `upzilla`, `district`, `mobile`, `pic`, `status`, `insert_by`, `insert_date`) VALUES ('1', '19950815000000000', '', '', 'রানা', 'Rana', 'মমিন', 'রেজিয়া', '2017-04-11', '500', 'জায়লস্কর', '07', 'জায়লস্কর', 'জায়লস্কর', 'ফেনী', '01825292980', 'library/profile/voters/daisy@2x.jpg', '1', 'abs_rana', '2017-04-27 15:42:29');
INSERT INTO `tbl_voter_list` (`id`, `national_id`, `upazila_code`, `union_code`, `bangla_name`, `english_name`, `father_name`, `mother_name`, `date_of_birth`, `basha`, `gram`, `word_no`, `post_office`, `upzilla`, `district`, `mobile`, `pic`, `status`, `insert_by`, `insert_date`) VALUES ('2', '19950815000000001', '', '', 'রহিম', 'Rohim', 'তাহের', 'রাবেয়া', '1988-02-22', '৫৪৫৪', 'জায়লস্কা', '7', 'জায়লস্কা', 'জায়লস্কা', 'ফেনী', '01825292981', 'library/profile/voters/download (1).jpg', '1', 'abs_rana', '2017-04-27 15:44:43');
INSERT INTO `tbl_voter_list` (`id`, `national_id`, `upazila_code`, `union_code`, `bangla_name`, `english_name`, `father_name`, `mother_name`, `date_of_birth`, `basha`, `gram`, `word_no`, `post_office`, `upzilla`, `district`, `mobile`, `pic`, `status`, `insert_by`, `insert_date`) VALUES ('3', '19950815000000002', '', '', 'কামাল', 'Kamal', 'জসিম', 'আমেনা', '1978-04-30', '৪৯৯৯', 'জায়লস্কর', '4', 'জায়লস্কর', 'জায়লস্কর', 'ফেনী', '01825292982', 'library/profile/voters/download.jpg', '1', 'abs_rana', '2017-04-27 15:45:56');
INSERT INTO `tbl_voter_list` (`id`, `national_id`, `upazila_code`, `union_code`, `bangla_name`, `english_name`, `father_name`, `mother_name`, `date_of_birth`, `basha`, `gram`, `word_no`, `post_office`, `upzilla`, `district`, `mobile`, `pic`, `status`, `insert_by`, `insert_date`) VALUES ('4', '19950815000000003', '', '', 'সাদেক', 'Sadek', 'মালেক', 'আশা', '1971-02-22', '৩৩২১', 'জায়লস্কর', '5', 'জায়লস্কর', 'জায়লস্কর', 'ফেনী', '01825292983', 'library/profile/voters/images (1).jpg', '1', 'abs_rana', '2017-04-27 15:47:52');
INSERT INTO `tbl_voter_list` (`id`, `national_id`, `upazila_code`, `union_code`, `bangla_name`, `english_name`, `father_name`, `mother_name`, `date_of_birth`, `basha`, `gram`, `word_no`, `post_office`, `upzilla`, `district`, `mobile`, `pic`, `status`, `insert_by`, `insert_date`) VALUES ('5', '19950815000000004', '', '', 'করিম', 'Karim', 'রফিক', 'পলি', '1989-09-25', '৩৯৯৮', 'জায়লস্কর', '3', 'জায়লস্কর', 'জায়লস্কর', 'ফেনী', '01825292984', 'library/profile/voters/images (2).jpg', '1', 'abs_rana', '2017-04-27 15:49:24');
INSERT INTO `tbl_voter_list` (`id`, `national_id`, `upazila_code`, `union_code`, `bangla_name`, `english_name`, `father_name`, `mother_name`, `date_of_birth`, `basha`, `gram`, `word_no`, `post_office`, `upzilla`, `district`, `mobile`, `pic`, `status`, `insert_by`, `insert_date`) VALUES ('6', '19950815000000005', '', '', 'ঝলি', 'Joly', 'রাকিব', 'মনি', '1989-12-31', '৫৬৬৫', 'জায়লস্কর', '5', 'জায়লস্কর', 'জায়লস্কর', 'ফেনী', '01825292985', 'library/profile/voters/images (3).jpg', '1', 'abs_rana', '2017-04-27 15:50:36');
INSERT INTO `tbl_voter_list` (`id`, `national_id`, `upazila_code`, `union_code`, `bangla_name`, `english_name`, `father_name`, `mother_name`, `date_of_birth`, `basha`, `gram`, `word_no`, `post_office`, `upzilla`, `district`, `mobile`, `pic`, `status`, `insert_by`, `insert_date`) VALUES ('7', '19950815000000006', '', '', 'সাত্তার', 'Sattar', 'জামিল', 'ঝরিনা', '1990-04-05', '৬৭৭৫', 'জায়লস্কর', '2', 'জায়লস্কর', 'জায়লস্কর', 'ফেনী', '01825292986', 'library/profile/voters/images (4).jpg', '1', 'abs_rana', '2017-04-27 15:51:44');
INSERT INTO `tbl_voter_list` (`id`, `national_id`, `upazila_code`, `union_code`, `bangla_name`, `english_name`, `father_name`, `mother_name`, `date_of_birth`, `basha`, `gram`, `word_no`, `post_office`, `upzilla`, `district`, `mobile`, `pic`, `status`, `insert_by`, `insert_date`) VALUES ('8', '19950815000000007', '', '', 'মুন্না', 'Munna', 'সফিক', 'ঝিনিয়া', '1984-09-21', '৫৪৫৪', 'জায়লস্কর', '5', 'জায়লস্কর', 'জায়লস্কর', 'জায়লস্কর', '01825292987', 'library/profile/voters/images (5).jpg', '1', 'abs_rana', '2017-04-27 15:53:05');
INSERT INTO `tbl_voter_list` (`id`, `national_id`, `upazila_code`, `union_code`, `bangla_name`, `english_name`, `father_name`, `mother_name`, `date_of_birth`, `basha`, `gram`, `word_no`, `post_office`, `upzilla`, `district`, `mobile`, `pic`, `status`, `insert_by`, `insert_date`) VALUES ('9', '19950815000000008', '', '', 'মান্নান', 'Manana', 'ককককক', 'তততততত', '1994-06-15', '২২১২', 'জায়লস্কর', '1', 'জায়লস্কর', 'জায়লস্কর', 'ফেনী', '01825292988', 'library/profile/voters/images (6).jpg', '1', 'abs_rana', '2017-04-27 15:54:15');
INSERT INTO `tbl_voter_list` (`id`, `national_id`, `upazila_code`, `union_code`, `bangla_name`, `english_name`, `father_name`, `mother_name`, `date_of_birth`, `basha`, `gram`, `word_no`, `post_office`, `upzilla`, `district`, `mobile`, `pic`, `status`, `insert_by`, `insert_date`) VALUES ('10', '19950815000000009', '', '', 'তানিয়া', 'Tanaia', 'তাহের', 'রেজিয়া', '1994-07-13', '৮৭৭৬', 'জায়লস্করম', '2', 'জায়লস্করম', 'জায়লস্করম', 'জায়লস্করম', '01825292989', 'library/profile/voters/images.jpg', '1', 'abs_rana', '2017-04-27 16:06:50');


#
# TABLE STRUCTURE FOR: tbl_warishesinfo
#

DROP TABLE IF EXISTS `tbl_warishesinfo`;

CREATE TABLE `tbl_warishesinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trackid` varchar(8) NOT NULL,
  `sonodno` varchar(17) DEFAULT NULL,
  `delivery_type` tinyint(3) NOT NULL,
  `nationid` varchar(20) DEFAULT NULL,
  `bcno` varchar(20) DEFAULT NULL,
  `pno` varchar(20) DEFAULT NULL,
  `dofb` date NOT NULL,
  `ename` varchar(60) NOT NULL,
  `bname` varchar(80) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `mstatus` tinyint(2) NOT NULL,
  `ewname` varchar(60) DEFAULT NULL,
  `bwname` varchar(80) DEFAULT NULL,
  `ehname` varchar(60) DEFAULT NULL,
  `bhname` varchar(80) DEFAULT NULL,
  `efname` varchar(60) NOT NULL,
  `bfname` varchar(80) NOT NULL,
  `emname` varchar(60) NOT NULL,
  `bmane` varchar(80) NOT NULL,
  `ocupt` varchar(120) DEFAULT NULL,
  `bashinda` enum('1','2') NOT NULL,
  `p_gram` varchar(60) DEFAULT NULL,
  `pb_gram` varchar(100) DEFAULT NULL,
  `p_rbs` varchar(60) DEFAULT NULL,
  `pb_rbs` varchar(100) DEFAULT NULL,
  `p_wordno` int(4) DEFAULT NULL,
  `pb_wordno` varchar(10) DEFAULT NULL,
  `p_dis` varchar(60) DEFAULT NULL,
  `pb_dis` varchar(100) DEFAULT NULL,
  `p_thana` varchar(60) DEFAULT NULL,
  `pb_thana` varchar(100) DEFAULT NULL,
  `p_postof` varchar(60) DEFAULT NULL,
  `pb_postof` varchar(100) DEFAULT NULL,
  `per_gram` varchar(60) DEFAULT NULL,
  `perb_gram` varchar(100) DEFAULT NULL,
  `per_rbs` varchar(60) DEFAULT NULL,
  `perb_rbs` varchar(100) DEFAULT NULL,
  `per_wordno` int(4) DEFAULT NULL,
  `perb_wordno` varchar(10) DEFAULT NULL,
  `per_dis` varchar(60) DEFAULT NULL,
  `perb_dis` varchar(100) DEFAULT NULL,
  `per_thana` varchar(60) DEFAULT NULL,
  `perb_thana` varchar(100) DEFAULT NULL,
  `per_postof` varchar(60) DEFAULT NULL,
  `perb_postof` varchar(100) DEFAULT NULL,
  `english_applicant_name` varchar(60) NOT NULL,
  `bangla_applicant_name` varchar(80) NOT NULL,
  `english_applicant_father_name` varchar(60) NOT NULL,
  `bangla_applicant_father_name` varchar(80) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `verifier_name` varchar(60) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `ins_time` date NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trackid` (`trackid`),
  UNIQUE KEY `sonodno` (`sonodno`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_warishesinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `bname`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `bmane`, `ocupt`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `english_applicant_name`, `bangla_applicant_name`, `english_applicant_father_name`, `bangla_applicant_father_name`, `mobile`, `email`, `verifier_name`, `status`, `ins_time`, `utime`) VALUES ('1', '287205', NULL, '3', '', '', '', '2016-10-04', 'asdf', 'asdf', 'male', '2', NULL, NULL, NULL, NULL, 'adsf', 'asdf', 'asdf', 'asd', '', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', 'asdfasdf', 'asdfasd', 'asfasd', 'asdfasdf', '01825292980', '', '', '0', '2016-10-06', '2017-05-09 18:37:16');
INSERT INTO `tbl_warishesinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `bname`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `bmane`, `ocupt`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `english_applicant_name`, `bangla_applicant_name`, `english_applicant_father_name`, `bangla_applicant_father_name`, `mobile`, `email`, `verifier_name`, `status`, `ins_time`, `utime`) VALUES ('2', '085840', NULL, '3', '', '', '', '2016-10-04', 'asdf', 'asdf', 'male', '2', NULL, NULL, NULL, NULL, 'adsf', 'asdf', 'asdf', 'asd', '', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', 'asdfasdf', 'asdfasd', 'asfasd', 'asdfasdf', '01825292980', '', 'asdfasdf', '0', '2016-10-06', '2016-11-29 20:21:45');
INSERT INTO `tbl_warishesinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `bname`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `bmane`, `ocupt`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `english_applicant_name`, `bangla_applicant_name`, `english_applicant_father_name`, `bangla_applicant_father_name`, `mobile`, `email`, `verifier_name`, `status`, `ins_time`, `utime`) VALUES ('3', '774205', '20171234567820519', '1', '23432452345234523', '2345324523452345', '2345234523452345', '2016-10-02', 'Abdur rob', 'আবদুর রব', 'male', '1', NULL, NULL, NULL, NULL, 'Mohammad Ismail', 'মো: ইসলাম', 'Mother', 'মা', '', '2', 'Jaylashker', 'জায়লস্কর', '22', '22', '1', '1', 'Feni', 'ফেনী', 'Jaylashker', 'জায়লস্কর', 'Jaylashker', 'জায়লস্কর', 'Jaylashker', 'জায়লস্কর', '22', '22', '1', '1', 'Feni', 'ফেনী', 'Jaylashker', 'জায়লস্কর', 'Jaylashker', 'জায়লস্কর', 'Rana', 'রানা', 'Momin', 'মমিন', '01828087369', 'rana.feni.fci@gmail.com', 'Rana', '1', '2016-10-06', '2017-03-20 14:02:43');
INSERT INTO `tbl_warishesinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `bname`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `bmane`, `ocupt`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `english_applicant_name`, `bangla_applicant_name`, `english_applicant_father_name`, `bangla_applicant_father_name`, `mobile`, `email`, `verifier_name`, `status`, `ins_time`, `utime`) VALUES ('4', '916051', NULL, '3', '', '', '', '2017-03-27', 'asdf', 'asdf', 'male', '2', NULL, NULL, NULL, NULL, 'asdfasdf', 'asdfasd', 'asdfasdf', 'asdfasd', '', '2', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', 'adsfasdf', 'asdfasdf', 'asdfasdf', 'asdfasdf', '01825292950', '', NULL, '0', '2017-03-16', '2017-03-16 13:35:35');
INSERT INTO `tbl_warishesinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `bname`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `bmane`, `ocupt`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `english_applicant_name`, `bangla_applicant_name`, `english_applicant_father_name`, `bangla_applicant_father_name`, `mobile`, `email`, `verifier_name`, `status`, `ins_time`, `utime`) VALUES ('5', '836258', NULL, '3', '34252345235234523', '23452345234523452', '23425235235234532', '2017-03-20', 'asdfasdf', 'asdfasdf', 'male', '1', NULL, NULL, NULL, NULL, 'asd', 'asd', 'adsf', 'asdf', 'ad', '2', 'asdf', 'asdf', 'asfd', 'asdf', '3', '3', 'asdf', 'asdf', 'ad', 'asdf', 'asdf', 'asdf', 'asdf', 'asdf', 'asfd', 'asdf', '3', '3', 'asdf', 'asdf', 'ad', 'asdf', 'asdf', 'asdf', 'aasdfasdfasf', 'asdfasdfasdf', 'asfdasf', 'asdfasd', '01825292950', 'rana.feni.fci@gmail.com', NULL, '0', '2017-03-21', '2017-03-21 18:09:31');
INSERT INTO `tbl_warishesinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `bname`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `bmane`, `ocupt`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `english_applicant_name`, `bangla_applicant_name`, `english_applicant_father_name`, `bangla_applicant_father_name`, `mobile`, `email`, `verifier_name`, `status`, `ins_time`, `utime`) VALUES ('6', '546400', NULL, '3', '34334563463464363', '34636346346356745', '45736346463463463', '2017-03-06', 'aaaaaaaaaaa', 'aaaaaaaaaaaa', 'male', '2', NULL, NULL, NULL, NULL, 'aaaaaaaa', 'aaaaaaaa', 'aaaaaaaaaaaa', 'aaaaaaaaaaaa', 'aaaaaaa', '2', 'aaaaaaaaaa', 'aaaaaaaaa', 'aaaaaaaaaaaa', 'aaaaaaaaa', '2', '2', 'aaaaaaaa', 'aaaaaaa', 'aaaaaa', 'aaaaaaa', 'aaaaaaaaa', 'aaaaaaa', 'aaaaaaaaaa', 'aaaaaaaaa', 'aaaaaaaaaaaa', 'aaaaaaaaa', '2', '2', 'aaaaaaaa', 'aaaaaaa', 'aaaaaa', 'aaaaaaa', 'aaaaaaaaa', 'aaaaaaa', 'aaaaaaaaaaa', 'aaaaaaaa', 'aaaaaaaaaa', 'aaaaaaaaa', '01825292987', 'rana.feni.fci@gmail.com', NULL, '0', '2017-03-21', '2017-03-21 18:16:05');
INSERT INTO `tbl_warishesinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `bname`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `bmane`, `ocupt`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `english_applicant_name`, `bangla_applicant_name`, `english_applicant_father_name`, `bangla_applicant_father_name`, `mobile`, `email`, `verifier_name`, `status`, `ins_time`, `utime`) VALUES ('7', '596573', NULL, '3', '34334563463453456', '34666346346356745', '45736355555563463', '2017-03-06', 'bbbbbb', 'bbbbbb', 'male', '2', NULL, NULL, NULL, NULL, 'aaaaaaaa', 'aaaaaaaa', 'aaaaaaaaaaaa', 'aaaaaaaaaaaa', 'aaaaaaa', '2', 'aaaaaaaaaa', 'aaaaaaaaa', 'aaaaaaaaaaaa', 'aaaaaaaaa', '2', '2', 'aaaaaaaa', 'aaaaaaa', 'aaaaaa', 'aaaaaaa', 'aaaaaaaaa', 'aaaaaaa', 'aaaaaaaaaa', 'aaaaaaaaa', 'aaaaaaaaaaaa', 'aaaaaaaaa', '2', '2', 'aaaaaaaa', 'aaaaaaa', 'aaaaaa', 'aaaaaaa', 'aaaaaaaaa', 'aaaaaaa', 'bbbbbb', 'bbbbbbbbbb', 'b', 'b', '01825292911', 'rana.feni.fci@gmail.com', NULL, '0', '2017-03-21', '2017-03-21 18:17:33');
INSERT INTO `tbl_warishesinfo` (`id`, `trackid`, `sonodno`, `delivery_type`, `nationid`, `bcno`, `pno`, `dofb`, `ename`, `bname`, `gender`, `mstatus`, `ewname`, `bwname`, `ehname`, `bhname`, `efname`, `bfname`, `emname`, `bmane`, `ocupt`, `bashinda`, `p_gram`, `pb_gram`, `p_rbs`, `pb_rbs`, `p_wordno`, `pb_wordno`, `p_dis`, `pb_dis`, `p_thana`, `pb_thana`, `p_postof`, `pb_postof`, `per_gram`, `perb_gram`, `per_rbs`, `perb_rbs`, `per_wordno`, `perb_wordno`, `per_dis`, `perb_dis`, `per_thana`, `perb_thana`, `per_postof`, `perb_postof`, `english_applicant_name`, `bangla_applicant_name`, `english_applicant_father_name`, `bangla_applicant_father_name`, `mobile`, `email`, `verifier_name`, `status`, `ins_time`, `utime`) VALUES ('8', '629169', NULL, '3', '11111111111111111', '11111111111111111', '1111111111111', '2017-03-05', 'aaaaaaaaaaa', 'aaaaaaaaaaaa', 'female', '2', NULL, NULL, NULL, NULL, 'aaaaaaaaa', 'aaaaaaaaaa', 'aaaaaaaaaaa', 'aaaaaaaa', 'wet', '2', 'aaaaa', 'aaaaaaa', 'aaaaa', 'aaaaaaaa', '44', '44', 'aaaaaa', 'aaaaaa', 'aaaaaaaaa', 'aaaaaaa', 'aaaaaaaaa', 'aaaaaaaa', 'aaaaa', 'aaaaaaa', 'aaaaa', 'aaaaaaaa', '44', '44', 'aaaaaa', 'aaaaaa', 'aaaaaaaaa', 'aaaaaaa', 'aaaaaaaaa', 'aaaaaaaa', 'aaaaaaa', 'aaaaaaaaaa', 'aaaaaaaaaaa', 'aaaaaaaaaaaa', '01825292987', 'rana.feni.fci@gmail.com', '', '0', '2017-03-21', '2017-05-09 18:38:48');


#
# TABLE STRUCTURE FOR: tbl_wcc
#

DROP TABLE IF EXISTS `tbl_wcc`;

CREATE TABLE `tbl_wcc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trackid` varchar(8) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `trno` bigint(20) NOT NULL,
  `vno` bigint(20) NOT NULL,
  `acno` varchar(255) NOT NULL,
  `fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payment_date` date NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_wcc` (`id`, `trackid`, `applicant_id`, `trno`, `vno`, `acno`, `fee`, `payment_date`, `utime`) VALUES ('1', '774205', '1', '10', '9', '0000-0000-0000-0000', '0.00', '2017-03-20', '2017-03-20 14:02:43');


#
# TABLE STRUCTURE FOR: tbl_webtools
#

DROP TABLE IF EXISTS `tbl_webtools`;

CREATE TABLE `tbl_webtools` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_no` tinyint(3) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `entry_user` varchar(40) NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_webtools` (`id`, `item_no`, `status`, `entry_user`, `entry_date`) VALUES ('2', '1', '0', 'admin', '2017-04-03 12:47:00');
INSERT INTO `tbl_webtools` (`id`, `item_no`, `status`, `entry_user`, `entry_date`) VALUES ('3', '2', '1', 'admin', '2017-05-10 12:58:11');
INSERT INTO `tbl_webtools` (`id`, `item_no`, `status`, `entry_user`, `entry_date`) VALUES ('4', '3', '1', 'admin', '2017-05-10 12:58:16');
INSERT INTO `tbl_webtools` (`id`, `item_no`, `status`, `entry_user`, `entry_date`) VALUES ('5', '4', '0', 'admin', '2017-05-24 14:47:27');


#
# TABLE STRUCTURE FOR: tbl_widow
#

DROP TABLE IF EXISTS `tbl_widow`;

CREATE TABLE `tbl_widow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `national_id` varchar(20) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `insert_by` varchar(40) NOT NULL,
  `insert_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `national_id` (`national_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_widow` (`id`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('1', '19950815000000008', '1', 'abs_rana', '2017-04-27 16:10:30');
INSERT INTO `tbl_widow` (`id`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('2', '19950815000000000', '1', 'abs_rana', '2017-04-27 16:10:30');
INSERT INTO `tbl_widow` (`id`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('4', '19950815000000005', '1', 'abs_rana', '2017-04-27 16:11:10');
INSERT INTO `tbl_widow` (`id`, `national_id`, `status`, `insert_by`, `insert_date`) VALUES ('5', '19950815000000009', '1', 'abs_rana', '2017-04-27 16:11:11');


#
# TABLE STRUCTURE FOR: tradelicense
#

DROP TABLE IF EXISTS `tradelicense`;

CREATE TABLE `tradelicense` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trackid` varchar(8) NOT NULL,
  `sno` varchar(17) DEFAULT NULL,
  `delivery_type` tinyint(3) NOT NULL,
  `app_type` tinyint(3) NOT NULL,
  `ownertype` tinyint(3) NOT NULL,
  `ecomname` varchar(200) NOT NULL,
  `bcomname` varchar(255) NOT NULL,
  `ewname` varchar(160) NOT NULL,
  `bwname` varchar(200) NOT NULL,
  `gender` varchar(80) NOT NULL,
  `mstatus` varchar(80) NOT NULL,
  `efname` varchar(160) NOT NULL,
  `bfname` varchar(200) NOT NULL,
  `ehname` varchar(100) DEFAULT NULL,
  `bhname` varchar(100) DEFAULT NULL,
  `emname` varchar(160) NOT NULL,
  `bmane` varchar(200) NOT NULL,
  `vatid` varchar(20) DEFAULT NULL,
  `taxid` varchar(20) DEFAULT NULL,
  `btype` varchar(200) NOT NULL,
  `pay_amount` decimal(4,2) NOT NULL,
  `be_gram` varchar(60) DEFAULT NULL,
  `bb_gram` varchar(100) DEFAULT NULL,
  `be_rbs` varchar(60) DEFAULT NULL,
  `bb_rbs` varchar(100) DEFAULT NULL,
  `be_wordno` int(4) DEFAULT NULL,
  `bb_wordno` varchar(10) DEFAULT NULL,
  `be_dis` varchar(60) DEFAULT NULL,
  `bb_dis` varchar(100) DEFAULT NULL,
  `be_thana` varchar(60) DEFAULT NULL,
  `bb_thana` varchar(100) DEFAULT NULL,
  `be_postof` varchar(60) DEFAULT NULL,
  `bb_postof` varchar(100) DEFAULT NULL,
  `mobile` varchar(11) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `profile` varchar(160) DEFAULT NULL,
  `issue_date` date NOT NULL,
  `expire_date` date NOT NULL,
  `status` enum('1','2','3') NOT NULL DEFAULT '1',
  `insert_time` date NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `syn_status` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trackid` (`trackid`),
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('1', '425464', '20171234567845739', '3', '1', '1', 'hello', 'hello bangla', 'rana', 'rana', 'male', 'অবিবাহিত', 'momin', 'momin', '', '', 'razia begum', 'razia begum', '1223', '3443', 'international', '0.00', 'malibag', 'malibag', '12', '2', '1', '1', 'malibag', 'malibag', 'malibag', 'malibag', 'malibag', 'malibag', '01825292980', '32201540', 'rana.feni.fci@gmail.com', 'http://localhost/db_correction/smartup//library/profile/147548197120725.jpg', '2016-03-15', '2016-06-30', '2', '2016-10-03', '2017-06-08 15:00:27', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('2', '192690', '20176112385247095', '3', '1', '2', 'asdfdfg', 'asdfadsff', 'dgsdgdsfg,asdfasdf,sdfgsdfg', 'sdfgdsfg,adsf,sdfgdsfg', 'male,female', 'অবিবাহিত,বিবাহিত', ',asdf', ',asdf', ',sdfgsdf', ',sdfg', 'asdf,asdf,sdfg', 'asdf,asdf,sdfg', '', '', 'sdfgsdfgdsfg', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01825292980', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2016-10-03', '2017-12-10 23:49:31', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('3', '942343', '20176112385816403', '3', '1', '2', 'asdfasdfasdf', 'asdfasdfasdf', 'asdsadf,asdfsadf,asdfasd', 'asdfsadf,asfdasdf,asdfsadf', 'male,male,female', 'অবিবাহিত,অবিবাহিত,অবিবাহিত', 'asdfasdf,asdfasdf,asdf', 'asdsda,asdfasd,asdf', '', '', 'asdfsadf,asdfasdf,asdf', 'asdf,asdfas,asdfa', '', '', 'asdasdfasdf', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01685596000', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2016-10-03', '2017-12-10 23:34:19', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('4', '324714', '20176112385257814', '3', '1', '2', 'asdfasdfasdfdd', 'asdfasdfasdfdd', 'asdsadf,asdfsadf,asdfasd', 'asdfsadf,asfdasdf,asdfsadf', 'male,male,female', 'অবিবাহিত,অবিবাহিত,অবিবাহিত', 'asdfasdf,asdfasdf,asdf', 'asdsda,asdfasd,asdf', '', '', 'asdfsadf,asdfasdf,asdf', 'asdf,asdfas,asdfa', '', '', 'asdasdfasdf', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01685596001', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2016-10-03', '2017-12-10 23:28:29', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('5', '580293', '20176112385924711', '3', '1', '2', 'sdfgdsf', 'sdfgsdfg', 'sdfgdsfg,sdfgsdfg', 'sdfgdsfg,sdgdsg', 'male,male', 'অবিবাহিত,অবিবাহিত', 'sdfg,sdg', 'sdfg,sdfgsdfg', '', '', 'sdgdsf,sdfg', 'sdfg,sdfg', '', '', 'sdfgsdgsdfg', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01615596000', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2016-10-03', '2017-12-10 23:26:41', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('6', '371734', '20176112385476269', '3', '1', '2', 'sdfgdsfg', 'sdfgsdfgsdfg', 'sdgsdfg', 'sdfgsdfg', 'male', 'অবিবাহিত', 'sdfgsdfg', 'sdfgdsf', '', '', 'sdfgdsfg', 'sdsdfgdsf', '', '', 'sdfgsdgsdfg', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01825292980', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2016-10-03', '2017-12-10 23:24:38', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('7', '043852', '20176112385094942', '3', '1', '2', 'sdfgdsfgsdfg', 'sdfgsdfgsdfgsdfg', 'sdfgdsfg,sdgsdfg', 'sdfgsdfg,sdfgsdfg', 'male,male', 'অবিবাহিত,অবিবাহিত', 'sdfgsdfg,sdfgsdfg', 'sdfg,sdfgdsf', '', '', 'sdfgsdf,sdfgdsfg', 'sdfgsdf,sdsdfgdsf', '', '', 'sdfgsdgsdfg', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01825292980', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-04-14', '2017-06-30', '2', '2016-10-03', '2017-04-14 18:14:15', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('8', '564239', '20176112385197104', '3', '1', '1', 'asdfasdf', 'asdf', 'asdf', 'asdf', 'female', 'অবিবাহিত', 'asdf', 'adsf', '', '', 'asdf', 'asdf', '', '', 'asdfasdf', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01985596700', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2016-10-03', '2017-12-10 23:19:48', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('14', '780019', '20176112385884697', '3', '1', '1', 'asdf', 'adfsadf', 'asdf', 'asdfasdf', 'male', 'অবিবাহিত', 'asdf', 'asdf', '', '', 'asdf', 'asdf', '', '', 'asdfasdf', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01685596740', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2016-10-03', '2017-12-10 23:17:48', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('15', '812617', '20176112385235576', '3', '1', '1', 'asdfasdfasdfdf', 'adfsadfasdfsadf', 'asdf', 'asdfasdf', 'male', 'অবিবাহিত', 'asdf', 'asdf', '', '', 'asdf', 'asdf', '', '', 'asdfasdfasf', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01685596740', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2016-10-03', '2017-12-10 23:15:27', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('18', '625696', '20176112385802527', '3', '1', '1', 'sdffsdfasdfdf', 'dfdfsadfasdfsadf', 'asdf', 'asdfasdf', 'male', 'অবিবাহিত', 'asdf', 'asdf', '', '', 'asdf', 'asdf', '', '', 'asdfasdfasf', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01685596745', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2016-10-03', '2017-12-10 23:13:04', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('19', '211830', '20176112385578164', '3', '1', '1', 'sdffdfdfdfdf', 'dfdfsaddfdsdfsadf', 'asdf', 'asdfasdf', 'male', 'অবিবাহিত', 'asdf', 'asdf', '', '', 'asdf', 'asdf', '', '', 'asdfasdfasf', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01685596745', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2016-10-03', '2017-12-10 23:02:27', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('20', '126339', '20176112385375872', '3', '1', '1', 'asdfsad', 'asfdsadf', 'asfsdaf', 'asdfadsf', 'male', 'অবিবাহিত', 'asdfsdf', 'asdfa', '', '', 'asdf', 'asfd', '', '', 'asdfasd', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01826547890', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2016-10-03', '2017-12-10 22:59:01', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('21', '486068', '20171234567858453', '2', '1', '2', 'A A Company', 'এ এ কোম্পানি', 'Osman,Razib', 'ওসমান,রাজিব', 'female,male', 'বিবাহিত,অবিবাহিত', ',Saddam', ',সাদ্দাম', 'Rana', 'রানা', 'Moni,Julekha', 'মনি,জুলেখা', '2344', '4545', 'মাল্টি কোম্পানি', '0.00', 'Jaylashker', 'জায়লস্কর', '2', '২', '1', '১', 'Feni', 'ফেনী', 'Jaylashker', 'জায়লস্কর', 'Jaylashker', 'জায়লস্কর', '01828087369', '01223654', 'rana.feni.fci@gmail.com', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-03-15', '2017-06-30', '2', '2016-10-06', '2017-03-15 19:43:26', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('22', '958390', '20176112385105329', '3', '1', '1', 'wertwert', 'wertwetwert', 'werterwt', 'wert', '', '', 'sdfgsdfg', 'sdfgsdfg', '', '', 'sdfgsdfg', 'sdfgsdfgsdf', '', '', 'sdfgsdfgsgdf', '0.00', 'd', '', '', '', '0', '', '', '', '', '', '', '', '01825292984', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2017-03-16', '2017-12-10 22:55:37', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('23', '323250', '20176112385389921', '3', '1', '1', 'xzv', 'zcxv', 'dsfg', 'xcvb', 'male', 'অবিবাহিত', 'asdf', 'asdfa', '', '', 'asdfasd', 'asdf', '', '', 'adsfsadf', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01825292987', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2017-03-16', '2017-12-10 22:53:21', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('24', '171298', '20176112385504207', '3', '0', '1', 'aaaaaaaaaaaaa', 'aaaaaaaaaaa', 'aaaaaaaaaaaa', 'aaaaaaaaaaaaa', 'male', 'বিবাহিত', 'aaaaaaaaa', 'aaaaaaaaaa', '', '', 'aaaaaaaaa', 'aaaaaaaaaa', '445454', '45454', 'sdgsdf', '0.00', 'aaaaaaaa', 'aaaaaaaaaa', 'aaaaaaaaa', 'aaaaaaaaaa', '4', '4', 'aaaaaaaaaa', 'aaaaaaaa', 'aaaaaaaaa', 'aaaaaaa', 'aaa', 'aaaaaa', '01825292900', '5656', 'arana.feni.fci@gmail.com', 'http://localhost/db_correction/smartup//library/profile/149268755615314.png', '2017-12-02', '2018-06-30', '2', '2017-03-21', '2017-12-02 16:11:59', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('25', '898083', '20176112385619127', '3', '1', '1', 'sdfgsdfgdf', 'sdfg', 'sdgf', 'sdfg', 'male', 'বিবাহিত', 'sdfg', 'sdfg', '', '', 'sdfg', 'sdfg', '', '', 'sdfgsdfgsdfg', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01825292960', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2017-12-10', '2017-12-10 23:46:37', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('26', '767930', '20176112385272992', '3', '1', '1', 'sdfgsdr', 'rtrgdfgsdf', 'sdfgd', 'ggdfsgds', 'male', 'বিবাহিত', 'sdfgsdgsdfg', 'sdfgsdfgsdfg', '', '', 'sdfgsdfg', 'sdfgsdfg', '', '', 'dfshgfdhfdgh', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01825292961', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2017-12-10', '2017-12-10 23:45:01', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('27', '860038', NULL, '3', '1', '1', 'aaaaa', 'aaaa', 'aaa', 'aaa', 'male', 'বিবাহিত', 'asasas', 'asasa', '', '', 'asas', 'asas', '', '', 'sdsdsdsdsd', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01825292964', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0000-00-00', '0000-00-00', '1', '2017-12-10', '2017-12-10 23:50:56', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('28', '083808', NULL, '3', '1', '1', 'sdfgfsdg', 'fgfgf', 'gfgfg', 'fgf', 'male', 'বিবাহিত', 'sdfg', 'sdgf', '', '', 'sdg', 'sdfg', '', '', 'sdfgfg', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01825292945', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '0000-00-00', '0000-00-00', '1', '2017-12-10', '2017-12-10 23:51:31', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('29', '842728', '20176112385285843', '3', '1', '1', 'hhhhh', 'ghghgh', 'ghghgh', 'ghghgh', 'male', 'বিবাহিত', 'ghghgh', 'ghghgh', '', '', 'ghghgh', 'ghghgh', '', '', 'tytytyty', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01825292974', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2017-12-10', '2017-12-10 23:57:00', '1');
INSERT INTO `tradelicense` (`id`, `trackid`, `sno`, `delivery_type`, `app_type`, `ownertype`, `ecomname`, `bcomname`, `ewname`, `bwname`, `gender`, `mstatus`, `efname`, `bfname`, `ehname`, `bhname`, `emname`, `bmane`, `vatid`, `taxid`, `btype`, `pay_amount`, `be_gram`, `bb_gram`, `be_rbs`, `bb_rbs`, `be_wordno`, `bb_wordno`, `be_dis`, `bb_dis`, `be_thana`, `bb_thana`, `be_postof`, `bb_postof`, `mobile`, `phone`, `email`, `profile`, `issue_date`, `expire_date`, `status`, `insert_time`, `utime`, `syn_status`) VALUES ('30', '142753', '20176112385062039', '3', '1', '1', 'sdsgsd', 'sdgsdgsdfg', 'sdfgsdfgsdfg', 'sfdg', 'male', 'বিবাহিত', 'sdfgdfsgdsfg', 'sdgsdfgsdfg', '', '', 'sdgsdfg', 'sdfgsdfgsd', '', '', 'fgsdfgsdfgsdfgs', '0.00', '', '', '', '', '0', '', '', '', '', '', '', '', '01825292963', '', '', 'http://localhost/db_correction/smartup/img/default/profile.png', '2017-12-10', '2018-06-30', '2', '2017-12-10', '2017-12-10 23:54:33', '1');


#
# TABLE STRUCTURE FOR: transaction
#

DROP TABLE IF EXISTS `transaction`;

CREATE TABLE `transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` bigint(20) NOT NULL,
  `up_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;

INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('1', '1', '2017-03-15 15:36:59');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('2', '2', '2017-03-15 15:58:57');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('3', '3', '2017-03-15 15:59:32');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('4', '4', '2017-03-15 16:00:57');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('5', '5', '2017-03-15 19:43:25');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('6', '6', '2017-03-15 19:49:15');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('7', '7', '2017-03-15 19:49:31');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('8', '8', '2017-03-15 19:52:08');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('13', '9', '2017-03-15 21:14:20');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('14', '10', '2017-03-20 14:02:43');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('15', '11', '2017-04-01 13:59:40');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('16', '12', '2017-04-08 16:32:49');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('17', '13', '2017-04-08 16:34:24');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('18', '14', '2017-04-09 12:30:43');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('19', '15', '2017-04-12 21:07:24');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('20', '16', '2017-04-12 21:10:56');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('21', '17', '2017-04-12 21:10:56');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('22', '18', '2017-04-12 21:13:43');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('23', '19', '2017-04-13 13:42:52');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('24', '20', '2017-04-13 20:31:58');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('25', '21', '2017-04-13 22:20:02');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('26', '22', '2017-04-13 22:23:20');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('27', '23', '2017-04-13 22:28:17');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('28', '24', '2017-04-14 14:34:56');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('29', '25', '2017-04-14 14:35:51');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('30', '26', '2017-04-14 14:37:35');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('31', '27', '2017-04-14 15:24:43');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('32', '28', '2017-04-14 15:28:15');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('33', '29', '2017-04-14 15:31:10');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('34', '30', '2017-04-14 15:34:18');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('36', '31', '2017-04-14 15:35:23');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('37', '32', '2017-04-14 15:38:54');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('38', '33', '2017-04-14 15:40:42');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('39', '34', '2017-04-14 18:02:36');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('40', '35', '2017-04-14 18:07:04');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('43', '36', '2017-04-14 18:14:15');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('44', '37', '2017-04-14 21:19:33');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('45', '38', '2017-04-18 18:29:26');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('46', '39', '2017-05-01 01:45:07');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('47', '40', '2017-05-06 17:44:01');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('48', '41', '2017-06-08 17:06:16');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('49', '42', '2017-12-02 16:11:59');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('50', '43', '2017-12-10 22:53:21');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('51', '44', '2017-12-10 22:55:37');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('56', '45', '2017-12-10 22:59:01');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('61', '46', '2017-12-10 23:02:27');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('67', '47', '2017-12-10 23:13:04');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('68', '48', '2017-12-10 23:15:26');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('69', '49', '2017-12-10 23:15:27');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('70', '50', '2017-12-10 23:17:48');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('71', '51', '2017-12-10 23:19:48');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('72', '52', '2017-12-10 23:24:38');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('73', '53', '2017-12-10 23:26:41');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('74', '54', '2017-12-10 23:28:29');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('75', '55', '2017-12-10 23:34:19');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('76', '56', '2017-12-10 23:45:01');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('77', '57', '2017-12-10 23:46:37');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('78', '58', '2017-12-10 23:49:31');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('81', '59', '2017-12-10 23:54:33');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('85', '60', '2017-12-10 23:56:58');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('86', '61', '2017-12-10 23:57:00');
INSERT INTO `transaction` (`id`, `tid`, `up_date`) VALUES ('87', '62', '2018-01-22 13:08:19');


#
# TABLE STRUCTURE FOR: up_map
#

DROP TABLE IF EXISTS `up_map`;

CREATE TABLE `up_map` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `map_link` text NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `update_by` varchar(40) NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `up_map` (`id`, `map_link`, `status`, `update_by`, `utime`) VALUES ('1', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d231872.6367399436!2d90.44994659345117!3d24.76084801834589!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3756f878353790a3%3A0x70791d1cef0adb9b!2sGouripur+Upazila%2C+Bangladesh!5e0!3m2!1sen!2s!4v1489654896668\" width=\"400\" height=\"200\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>', '1', '', '2017-03-16 15:02:32');


#
# TABLE STRUCTURE FOR: up_sonods
#

DROP TABLE IF EXISTS `up_sonods`;

CREATE TABLE `up_sonods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sno` varchar(17) NOT NULL,
  `utime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8;

INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('1', '20171234567845739', '2017-03-15 15:36:59');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('2', '20171234567872713', '2017-03-15 16:00:57');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('3', '20171234567858453', '2017-03-15 19:43:25');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('4', '20171234567803702', '2017-03-15 19:52:08');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('5', '20171234567820519', '2017-03-20 14:02:43');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('6', '20171234567875886', '2017-04-12 21:07:24');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('7', '20171234567806399', '2017-04-12 21:10:56');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('8', '20171234567855709', '2017-04-12 21:10:56');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('9', '20171234567829704', '2017-04-12 21:13:43');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('10', '20171234567860177', '2017-04-13 13:42:52');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('11', '20176112385783181', '2017-04-13 20:31:58');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('12', '20176112385478623', '2017-04-13 22:20:02');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('13', '20176112385499368', '2017-04-13 22:23:20');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('14', '20176112385745799', '2017-04-13 22:28:17');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('15', '20176112385895157', '2017-04-14 14:34:56');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('16', '20176112385678372', '2017-04-14 14:35:51');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('17', '20176112385939272', '2017-04-14 14:37:35');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('18', '20176112385925601', '2017-04-14 15:24:43');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('19', '20176112385512864', '2017-04-14 15:28:15');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('20', '20176112385389703', '2017-04-14 15:31:10');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('21', '20176112385638349', '2017-04-14 15:34:18');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('23', '20176112385444361', '2017-04-14 15:35:23');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('24', '20176112385160858', '2017-04-14 15:38:54');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('25', '20176112385498049', '2017-04-14 15:40:42');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('26', '20176112385998134', '2017-04-14 18:02:36');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('29', '20176112385094942', '2017-04-14 18:14:15');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('30', '20176112385655674', '2017-04-14 21:19:33');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('31', '20176112385687741', '2017-04-18 18:29:26');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('32', '20176112385887339', '2017-05-01 01:45:07');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('33', '20176112385695944', '2017-05-10 17:18:28');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('34', '20176112385049131', '2017-05-10 20:14:01');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('42', '20176112385053185', '2017-05-11 15:38:28');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('43', '20176112385271754', '2017-05-11 15:38:54');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('44', '20176112385176949', '2017-05-11 15:44:30');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('48', '20176112385950095', '2017-05-11 15:49:13');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('49', '20176112385072655', '2017-05-11 18:36:08');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('50', '20176112385504207', '2017-12-02 16:11:59');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('51', '20176112385389921', '2017-12-10 22:53:21');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('52', '20176112385105329', '2017-12-10 22:55:37');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('57', '20176112385375872', '2017-12-10 22:59:01');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('62', '20176112385578164', '2017-12-10 23:02:27');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('68', '20176112385802527', '2017-12-10 23:13:04');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('69', '20176112385758413', '2017-12-10 23:15:26');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('70', '20176112385235576', '2017-12-10 23:15:27');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('71', '20176112385884697', '2017-12-10 23:17:47');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('72', '20176112385197104', '2017-12-10 23:19:48');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('73', '20176112385476269', '2017-12-10 23:24:38');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('74', '20176112385924711', '2017-12-10 23:26:41');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('75', '20176112385257814', '2017-12-10 23:28:29');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('76', '20176112385816403', '2017-12-10 23:34:19');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('77', '20176112385272992', '2017-12-10 23:45:01');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('78', '20176112385619127', '2017-12-10 23:46:37');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('79', '20176112385247095', '2017-12-10 23:49:31');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('82', '20176112385062039', '2017-12-10 23:54:32');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('83', '20176112385678418', '2017-12-10 23:56:57');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('84', '20176112385285843', '2017-12-10 23:57:00');
INSERT INTO `up_sonods` (`id`, `sno`, `utime`) VALUES ('85', '20186112385824693', '2018-01-22 13:08:19');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(60) NOT NULL,
  `last_name` varchar(60) NOT NULL,
  `image` varchar(120) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `first_name`, `last_name`, `image`) VALUES ('1', 'abs', 'rana', '1.jpg');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `image`) VALUES ('2', 'osman', 'goni', '2.jpg');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `image`) VALUES ('3', 'borhan', 'uddin', '3.jpg');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `image`) VALUES ('4', 'al', 'mamun', '4.jpg');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `image`) VALUES ('5', 'hosna', 'poly', '5.jpg');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `image`) VALUES ('6', 'al', 'kowasr', '6.jpg');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `image`) VALUES ('7', 'sumon', 'hanasn', '7.jpg');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `image`) VALUES ('8', 'munna', 'aktar', '8.jpg');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `image`) VALUES ('9', 'asd', 'asdf', '9.jpg');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `image`) VALUES ('10', 'asd', 'asdf', '10.jpg');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `image`) VALUES ('11', 'asdf', 'asdfasd', '11.jpg');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `image`) VALUES ('12', 'asdasd', 'asfsda', '12.jpg');


#
# TABLE STRUCTURE FOR: warishinfo
#

DROP TABLE IF EXISTS `warishinfo`;

CREATE TABLE `warishinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trackid` varchar(8) NOT NULL,
  `w_name` varchar(60) NOT NULL,
  `w_relation` varchar(30) NOT NULL,
  `w_age` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('1', '287205', 'asdf', 'asdf', '4');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('2', '287205', 'asdf', 'sadf', '33');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('3', '287205', 'as', 'asd', '30');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('4', '085840', 'asdf', 'asdf', '4');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('5', '085840', 'asdf', 'sadf', '33');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('6', '085840', 'as', 'asd', '30');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('7', '774205', 'মো: ইসলাম', 'পিতা', '60');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('8', '774205', 'মা', 'মাতা', '50');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('9', '774205', 'রাশেদা', 'মেয়ে', '44');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('10', '774205', 'তাহের', 'ছেলে', '20');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('11', '774205', 'তানিয়া', 'মেয়ে', '12');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('12', '916051', 'asdf', 'asdf', '34');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('13', '916051', 'adf', 'asdf', '34');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('14', '916051', 'asdf', 'asdf', '4');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('15', '546400', '', '', '');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('16', '596573', 'sg', 'sdf', '4');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('17', '629169', 'wwwwwwwwwwww', 'পিতা', '45');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('18', '629169', 'wwwwwwwwww', 'মাতা', '44');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('19', '629169', 'wet', 'wert', '4');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('20', '629169', 'wert', 'wertw', '4');
INSERT INTO `warishinfo` (`id`, `trackid`, `w_name`, `w_relation`, `w_age`) VALUES ('21', '629169', 'sfgfg', 'sdfgg', '4');


#
# TABLE STRUCTURE FOR: word_member
#

DROP TABLE IF EXISTS `word_member`;

CREATE TABLE `word_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word_no` int(11) NOT NULL,
  `member_name` varchar(80) NOT NULL,
  `member_father` varchar(80) NOT NULL,
  `ins_user` varchar(60) NOT NULL,
  `ins_date` date NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `word_member` (`id`, `word_no`, `member_name`, `member_father`, `ins_user`, `ins_date`, `status`) VALUES ('1', '7', 'rana', 'momin', 'abs_rana', '2017-04-08', '1');
INSERT INTO `word_member` (`id`, `word_no`, `member_name`, `member_father`, `ins_user`, `ins_date`, `status`) VALUES ('2', '2', 'osman', 'taher', 'abs_rana', '2017-04-08', '1');
INSERT INTO `word_member` (`id`, `word_no`, `member_name`, `member_father`, `ins_user`, `ins_date`, `status`) VALUES ('3', '1', 'mannan', 'kabir', 'abs_rana', '2017-04-08', '1');
INSERT INTO `word_member` (`id`, `word_no`, `member_name`, `member_father`, `ins_user`, `ins_date`, `status`) VALUES ('4', '23', 'asdfasdasfd', 'asdfasdf', 'abs_rana', '2017-04-08', '1');
INSERT INTO `word_member` (`id`, `word_no`, `member_name`, `member_father`, `ins_user`, `ins_date`, `status`) VALUES ('5', '34', 'asdf', 'asdfaf', 'abs_rana', '2017-04-08', '1');
INSERT INTO `word_member` (`id`, `word_no`, `member_name`, `member_father`, `ins_user`, `ins_date`, `status`) VALUES ('6', '22', 'sad', 'qqwqwqw', 'abs_rana', '2017-04-08', '1');
INSERT INTO `word_member` (`id`, `word_no`, `member_name`, `member_father`, `ins_user`, `ins_date`, `status`) VALUES ('7', '5', 'sdfgdsf', 'sdfgdfs', 'abs_rana', '2017-04-08', '1');


